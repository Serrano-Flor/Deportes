<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['deporte'])) { $deporte = $_POST['deporte']; }
if(isset($_POST['equipo'])) { $equipo = $_POST['equipo']; }
if(isset($_POST['rama'])) { $rama = $_POST['rama']; }
if(isset($_POST['asistencia'])) { $asistencia = $_POST['asistencia']; }
if(isset($_POST['calificacion'])) { $calificacion = $_POST['calificacion']; }
if(isset($_POST['asistencia_id'])) { $asistencia_id = $_POST['asistencia_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
         mysqli_query($con, "insert into Deportes.asistencia (Deporte, Equipo, Rama, Asistencia, Calificacion) values('$deporte', '$equipo', '$rama', '$asistencia', '$calificacion')");
         echo Tabla(); 
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.asistencia set Deporte= '$deporte', Equipo= '$equipo', Rama= '$rama', Asistencia= '$asistencia', Calificacion= '$calificacion' where asistencia_id = '$asistencia_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.asistencia where asistencia_id= '$asistencia_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
    case 'buscar':
        echo Tabla_buscar();    
    break;
}
function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.asistencia");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_asistencia">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Asistencia ID</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Equipo</p></th>
							<th class="col-md-2"><p align="center">Rama</p></th>
							<th class="col-md-2"><p align="center">Asistencia</p></th>
							<th class="col-md-2"><p align="center">Calificaci&oacute;n</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>
                                    ';
                                }
	
						  $regreso.= '</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $asistencia_id = $fila['asistencia_id'];
				  $deporte = $fila['Deporte'];
				  $equipo = $fila['Equipo'];
				  $rama = $fila['Rama'];
				  $asistencia = $fila['Asistencia'];
				  $calificacion = $fila['Calificacion'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $asistencia_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$rama.'</td>
						  <td style="vertical-align:middle;" align="center">'.$asistencia.'</td>
						  <td style="vertical-align:middle;" align="center">'.$calificacion.'</td>';
                            
                           if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$asistencia_id.'" class="btn_modificar btn btn-success" accion="editasistencia">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$asistencia_id.'" class="btn_eliminar btn btn-danger" accion="delasistencia">Eliminar                          </button></td>
                                    ';
                                }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $asistencia_id = $_POST['asistencia_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.asistencia where asistencia_id= '$asistencia_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $asistencia_id = $fila['asistencia_id'];
    $deporte = $fila['Deporte'];
    $equipo = $fila['Equipo'];
	$rama = $fila['Rama'];
	$asistencia = $fila['Asistencia'];
	$calificacion = $fila['Calificacion'];
        
    $regreso= '<label class="col-md-2">Deporte:</label>
			  	<div class="col-md-3">
				  <select class="form-control" id="inp_deporte_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($deporte == 'F&uacute;tbol'){
                          $regreso.= '<option value="F&uacute;tbol" selected>F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      } elseif($deporte == 'Basquetbol'){
                         $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol" selected>Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>'; 
					 } elseif($deporte == 'Voleibol'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol" selected>Voleibol</option>
								   	<option value="Atletismo">Atletismo</option>'; 
					} elseif($deporte == 'Atletismo'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol">Voleibol</option>
								   	<option value="Atletismo" selected>Atletismo</option>';				
												  
                      } else {
                          $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      }
               		$regreso.= '</select>
      			</div>
			  <label class="col-md-2">Equipo:</label>
			  <div class="col-md-5">
				  <select class="form-control" id="inp_equipo_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($equipo == 'Colegio ingles'){
                          $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles">Colegio ingles blanco</option>';
                      } elseif($equipo == 'Colegio ingles verde'){
					 	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde" selected>Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
					  } elseif($equipo == 'Colegio ingles blanco'){
					  	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles</option>
									  <option value="Colegio ingles blanco" selected>Colegio ingles blanco</option>';	
					} else {
                          $regreso.= '<option value="Colegio ingles">Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
                    }
					$regreso.= '</select>				  			  
			  </div>
			  <br><br><br>
			  <label class="col-md-2">Rama:</label>
			  <div class="col-md-3">
				  <select class="form-control" id="inp_rama_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($rama == 'Varonil'){
                          $regreso.= '<option value="Varonil" selected>Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      } elseif($rama == 'Femenil'){
                         $regreso.= '<option value="Varonil">Varonil</option>
					                 <option value="Femenil" selected>Femenil</option>
									 <option value="Mixto">Mixto</option>'; 
					 } elseif($rama == 'Mixto'){
					 	$regreso.= '<option value="Varonil">Varonil</option>
								    <option value="Femenil">Femenil</option>
								    <option value="Mixto" selected>Mixto</option>'; 			  
                      } else {
                          $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      }
               		$regreso.= '</select>
      			</div>
			  <label class="col-md-2">Asistencia:</label>
			  <div class="col-md-2">
				  <input id="inp_asistencia_modal" class="form-control" type="text" value= "'.$asistencia.'">
			  </div> 
			  <br><br><br>
			  <label class="col-md-2">Calificaci&oacute;n:</label>
			  <div class="col-md-2">
				  <input id="inp_calificacion_modal" class="form-control" type="text" value= "'.$calificacion.'">
				 </div>';
    return $regreso;
}
function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.asistencia where Deporte like '%$busqueda%' or Equipo like '%$busqueda%' or Rama like '%$busqueda%' or 
	Asistencia like '%$busqueda%' or Calificacion like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_asistencia">
							<thead>
							  <tr>
								<th class="col-md-1"><p align="center">#</p></th>
								<th class="col-md-1"><p align="center">Asistencia ID</p></th>
								<th class="col-md-2"><p align="center">Deporte</p></th>
								<th class="col-md-2"><p align="center">Equipo</p></th>
								<th class="col-md-2"><p align="center">Rama</p></th>
								<th class="col-md-2"><p align="center">Asistencia</p></th>
								<th class="col-md-2"><p align="center">Calificaci&oacute;n</p></th>';
								if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>
                                    ';
                                }
		
							  $regreso.='</tr>
							</thead>
						<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);
					
					  $asistencia_id = $fila['asistencia_id'];
					  $deporte = $fila['Deporte'];
					  $equipo = $fila['Equipo'];
					  $rama = $fila['Rama'];
					  $asistencia = $fila['Asistencia'];
					  $calificacion = $fila['Calificacion'];
                      $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $asistencia_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$rama.'</td>
						  <td style="vertical-align:middle;" align="center">'.$asistencia.'</td>
						  <td style="vertical-align:middle;" align="center">'.$calificacion.'</td>';
                        
						  if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$asistencia_id.'" class="btn_modificar btn btn-success" accion="editasistencia">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$asistencia_id.'" class="btn_eliminar btn btn-danger" accion="delasistencia">Eliminar                          </button></td>
                                    ';
                                }
						$regreso.='</tr>'; 
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}
?>
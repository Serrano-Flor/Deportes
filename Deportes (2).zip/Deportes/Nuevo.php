<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Visitante') {
      header('Location: Menu.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Nuevo documento</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_nuevo.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
       
	  var titulo_inp = $('#inp_titulo').val();
	  var descripcion_inp = $('#inp_descripcion').val();
	  var foto_inp = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');

	  var campos_insert = {titulo: titulo_inp, descripcion: descripcion_inp, foto: foto_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_nuevo.php',

		  success: function(response){
            swal({   
              type: "success",   
              title: "Se inserto correctamente", 
            });
			$('#div_pri').html(response);
            $("#form")[0].reset();
            $('#inp_titulo').val('');
            $('#inp_descripcion').val('');  
            $('#file-status').html('No se ha seleccionado archivo').fadeIn();
		  },

		  error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {nuevo_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_nuevo.php',

              success: function(response){
                $('#div_modal').html(response);
                  $('#file-status2').html('<p>No se ha seleccionado archivo</p>');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $('.btn-modificar-def').attr('id');
        var titulo_inp = $('#inp_titulo_modal').val();
	    var descripcion_inp = $('#inp_descripcion_modal').val();
	    var foto_inp = $('#upload2').attr('valor');
        
        var campos_modificar = {nuevo_id: id, titulo: titulo_inp, descripcion: descripcion_inp, foto: foto_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_nuevo.php',

              success: function(response){
                $('#div_pri').html(response);
                swal({   
                  type: "success",   
                  title: "¡Se actualizo la información con éxito!", 
                });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar el nuevo documento con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {nuevo_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_nuevo.php',

              success: function(response){
				 swal({   
                  type: "success",   
                  title: "¡Se elimino con éxito!", 
                });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
	 $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_nuevo.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    }); 

	
	var status= $('#upload').val();
	if(!status){
        $('#file-status').html('No se ha seleccionado archivo');    
    }
    
    $(document).on('change', '#upload', function(){
        var status= $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload').removeAttr('disabled');
        }
    });
    
   
    $(document).on('click','#file-upload',(function(e) {
        var formData= new FormData('#form');
        var path = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','insert-img');
        formData.append('foto', path);
        formData.append('file', $('#upload[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_nuevo.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				  swal({   
                  	type: "error",   
                  	title: "Archivo no valido! Intente de nuevo.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				   swal({   
                  	type: "error",   
                  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
                  // view uploaded file.
				  swal({   
				  type: "success",   
				  title: "El archivo se cargo correctamente!", 
				  });
                }
              },
             error: function(e) 
              {
                $("#err").html(e);
              }          
        });
     }));
    
    $(document).on('change', '#upload2', function(){
        var status= $('#upload2[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status2').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload2').removeAttr('disabled');
        }
    });
    
    $(document).on('click','#file-upload2',(function(e) {
        var formData= new FormData(this);
        var path = $('#upload2[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','modificar-img');
        formData.append('foto', path);
        formData.append('file', $('#upload2[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_nuevo.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err2").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				   swal({   
					  type: "error",   
					  title: "Archivo no valido!, Intente de nuevo.", 
					});
                  $("#form2")[0].reset();
                  $('#file-status2').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				  swal({   
				  	type: "error",   
				  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
				  });
                  $("#form2")[0].reset();
                  $('#file-status2').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
				   swal({   
					  type: "success",   
					  title: "El archivo se cargo correctamente!", 
					});
                  $('#div-img').html(data);
                }
              },
             error: function(e) 
              {
                $("#err2").html(e);
              }          
        });
     }));
    
    $(document).on('click','#cambiar-img', function(e) {
        var path = $('#cambiar-img').attr('valor');
        var info = {act: 'cambio-imagen', path: path };
        
        $.ajax({
              data : info,
              type : 'POST',
              url : 'tabla_nuevo.php',

              success: function(response){
                $('#div-img').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
		
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_nuevo{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center" id="titulo"><span class="glyphicon glyphicon-paperclip"></span>&nbsp; Nuevo documento</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right" >
		<strong><p style="text-decoration:underline"><a href="Menu.php" id="menu" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  	<div align="left">
		<span class="glyphicon glyphicon-print" style="color:#FFFFFF"></span>
		<input type="submit" value="Imprimir" id="imprimir" class="btn btn-link" style="color:#003300; font-size:18px" onClick="imprimir();">
	</div>
  <br>
  <div class="form-group row">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente') {
	echo '<label id="lbl_titulo" class="col-md-2">T&iacute;tulo:</label>
	  <div class="col-md-3">
	      <input id="inp_titulo" class="form-control" type="text">
      </div>
  </div>
   <div class="form-group row">
     <label id="lbl_descripcion" class="col-md-2">Descripci&oacute;n:</label>
	  <div class="col-md-3">
		  <input id="inp_descripcion" class="form-control" type="text">
	  </div>
  </div>
  <div class="form-group row"> 
	<label id="lbl_foto" class="col-sm-2">Foto:</label>
		<div class="col-md-3">
			<form id="form" action="tabla_nuevo.php" method="post" enctype="multipart/form-data">
               <label class="btn btn-primary btn-file">
                 Seleccionar Nuevo...<input id="upload" type="file" name="file" style="display:none;"/>
              </label>
             <input class="btn btn-success" type="submit" value="Cargar" id="file-upload" disabled>
          </form>
		</div>	
  </div>
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-10">
        <div id="file-status"></div><div id="err"></div>
    </div>
  </div>
  <div align="center">
     <button class="btn btn-primary" id="btn_nuevo">Nuevo documento</button>
  </div>'; } ?><br>
  <div class="form-group row">
    <label id="lbl_buscar" class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar nuevo documento</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar nuevo documento</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
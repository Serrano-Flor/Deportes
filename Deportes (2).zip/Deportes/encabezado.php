<?php
include("conecta.php");
session_start();

 if(!$_SESSION['iniciada'])
 {
  	header('Location: error.php');
 }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Men&uacute; principal</title>	
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function(){
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
    
	var status= $('#upload').val();
	if(!status){
        $('#file-status').html('No se ha seleccionado archivo');    
    }
    
    $(document).on('change', '#upload', function(){
        var status= $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload').removeAttr('disabled');
        }
    });
    
    $(document).on('click','#file-upload',(function(e) {
        var formData= new FormData('#form');
        var path = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','insert-img');
        formData.append('foto', path);
        formData.append('file', $('#upload[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_encabezado.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				  swal({   
                  	type: "error",   
                  	title: "Archivo no valido! Intente de nuevo.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				   swal({   
                  	type: "error",   
                  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
				   swal({   
                  	type: "success",   
                  	title: "El archivo se cargo correctamente!"+data, 
                    },
                    function(isConfirm){   
                      if (isConfirm) {     
                        location.reload();
                      } 
                   });
                  
                }
              },
             error: function(e) 
              {
                $("#err").html(e);
              }          
        });
     }));
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	  .Contenedor img {
	      width: 100%; 
          position: relative;
      }
	  
	  a {
		  color:#003300;
      }
</style>
</head>
<body style="background-color:#86a286">
    <div class="Contenedor encabezado">
	  <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
    </div> <br>
<div class="container" style="font-size: 16px;">
    <div class="row" align="center">
       <div class="col-md-12" style="color:black; font-size:35px;"><b><span class="glyphicon glyphicon-picture"></span> &nbsp;<label id="objetivo">Encabezado</label></b></div>
    </div>
    <div class="row" align="right">
       <div class="col-md-12" style="font-size:18px;">
       <strong><a href="Menu.php" style="color:#FFFFFF; text-decoration:underline;">Men&uacute; Principal</a></strong>
           </div>
    </div>
    <div class="row img-header" style="margin-top: 50px;">
         <div class="col-md-2">
             <label class="col-form-label">Cambiar Imagen de Encabezado:</label>
          </div>
          <div class="col-md-10">
             <?php 
              if($_SESSION['usua_rol'] != 'Asistente') {
                 echo '<form id="form" action="tabla_BD.php" method="post" enctype="multipart/form-data">
                       <label class="btn btn-primary btn-file">
                         Seleccionar Nuevo...<input id="upload" type="file" name="file" style="display:none;"/>
                      </label>
                     <input class="btn btn-success" type="submit" value="Cargar" id="file-upload" disabled>
                  </form>
                  <div id="file-status"></div><div id="err"></div>';
              } ?>
          </div>
      </div>
</div>	
</body>
</html>

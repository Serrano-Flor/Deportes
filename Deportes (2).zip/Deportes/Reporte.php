<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Reporte semanal</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_reporte.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
	  var deporte_inp = $('#inp_deporte option:selected').val();
	  var colegio_inp = $('#inp_colegio').val();
	  var marcador1_inp = $('#inp_marcador1').val();
	  var marcador2_inp = $('#inp_marcador2').val();
	  var categoria_inp = $('#inp_categoria').val();
	  var fecha_inp = $('#inp_fecha').val();
	  var lugar_inp = $('#inp_lugar').val();
	  var tipo_inp = $('#inp_tipo option:selected').val();
	  var otro_inp = $('#inp_otro').val();
	  
	  var jugadores_inp = $('#inp_jugadores').val();
	  var citado_inp = $('#inp_citado').val();
	  var asistio_inp = $('#inp_asistio').val();
	  var min1_inp = $('#inp_min1').val();
	  var min2_inp = $('#inp_min2').val();
	  var min3_inp = $('#inp_min3').val();
	  var min4_inp = $('#inp_min4').val();
	  var min5_inp = $('#inp_min5').val();
	  var min6_inp = $('#inp_min6').val();
	  var min7_inp = $('#inp_min7').val();
	  
	  var amonestados_inp = $('#inp_amonestados').val();
	  var expulsados_inp = $('#inp_expulsados').val();
	  var insidentes_inp = $('#inp_insidentes').val();
	  var conducta_inp = $('#inp_conducta').val();;

	  var campos_insert = {deporte: deporte_inp, colegio: colegio_inp, marcador1: marcador1_inp, marcador2: marcador2_inp, fecha: fecha_inp, lugar: lugar_inp, tipo: tipo_inp, otro: otro_inp, jugadores: jugadores_inp, citado: citado_inp, asistio: asistio_inp, min1: min1_inp, min2: min2_inp, min3: min3_inp, min4: min4_inp, min5: min5_inp, min6: min6_inp, min7: min7_inp, amonestados: amonestados_inp, expulsados: expulsados_inp, insidentes: insidentes_inp, conducta: conducta_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_reporte.php',

		  success: function(response){
		    swal({   
				type: "success",   
				title: "¡Se inserto correctamente!", 
			  });
			$('#div_pri').html(response);
			$('#inp_deporte').val('');
			$('#inp_colegio').val(''); 
			$('#inp_marcador1').val('');
			$('#inp_marcador2').val('');
			$('#inp_categoria').val('');
			$('#inp_fecha').val('');   
			$('#inp_lugar').val(''); 
			$('#inp_tipo').val('');
			$('#inp_otro').val(''); 
			$('#inp_jugadores').val('');
			$('#inp_citado').val('');
			$('#inp_asistio').val(''); 
			$('#inp_min1').val('');
			$('#inp_min2').val('');
			$('#inp_min3').val('');
			$('#inp_min4').val('');
			$('#inp_min5').val('');
			$('#inp_min6').val('');
			$('#inp_min7').val('');
			$('#inp_amonestados').val('');
			$('#inp_expulsados').val('');
			$('#inp_insidentes').val('');
			$('#inp_conducta').val('');	
		  },

		  error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {reporte_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_reporte.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
        var deporte_inp = $('#inp_deporte_modal option:selected').val();
	    var colegio_inp = $('#inp_colegio_modal').val();
	    var marcador1_inp = $('#inp_marcador1_modal').val();
		var marcador2_inp = $('#inp_marcador2_modal').val();
		var categoria_inp = $('#inp_categoria_modal').val();
	    var fecha_inp = $('#inp_fecha_modal').val();
		var lugar_inp = $('#inp_lugar_modal').val();
	    var tipo_inp = $('#inp_tipo_modal option:selected').val();
	    var otro_inp = $('#inp_otro_modal').val();
		
		var jugadores_inp = $('#inp_jugadores_modal').val();
	    var citado_inp = $('#inp_citado_modal').val();
	    var asistio_inp = $('#inp_asistio_modal').val();
		var min1_inp = $('#inp_min1_modal').val();
	    var min2_inp = $('#inp_min2_modal').val();
	    var min3_inp = $('#inp_min3_modal').val();
		var min4_inp = $('#inp_min4_modal').val();
	    var min5_inp = $('#inp_min5_modal').val();
	    var min6_inp = $('#inp_min6_modal').val();
		var min7_inp = $('#inp_min7_modal').val();
	    
		var amonestados_inp = $('#inp_amonestados_modal').val();
	    var expulsados_inp = $('#inp_expulsados_modal').val();
	    var insidentes_inp = $('#inp_insidentes_modal').val();
	    var conducta_inp = $('#inp_conducta_modal').val();
        
        var campos_modificar = {reporte_id: id, deporte: deporte_inp, colegio: colegio_inp, marcador1: marcador1_inp,  marcador2: marcador2_inp, fecha: fecha_inp, lugar: lugar_inp,  tipo: tipo_inp, otro: otro_inp, jugadores: jugadores_inp, citado: citado_inp, asistio: asistio_inp, min1: min1_inp, min2: min2_inp, min3: min3_inp, min4: min4_inp, min5: min5_inp, min6: min6_inp, min7: min7_inp, amonestados: amonestados_inp, expulsados: expulsados_inp, insidentes: insidentes_inp, conducta: conducta_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_reporte.php',

              success: function(response){
                $('#div_pri').html(response);
				swal({   
					type: "success",   
					title: "¡Se actualizo la información con éxito!", 
			    });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar el reporte con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {reporte_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_reporte.php',

              success: function(response){
				swal({   
					type: "success",   
					title: "¡Se elimino con éxito!", 
			    });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_reporte.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
    
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_reporte{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   
	   #inp_fecha {
   	    border-radius: 5px;
   		border: 1px solid #39c;
		width:165px; 
		height:35px;}	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-file"></span>&nbsp; Reporte semanal</h1>	

<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  	<br>
  <div class="form-group row">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
	echo '<label class="col-md-1">Deporte:</label>
	  <div class="col-md-2">
	  	<select class="form-control" id="inp_deporte" required>
		  <option selected disabled value="">Selecciona:</option>
	      <option value="F&uacute;tbol">F&uacute;tbol</option>
		  <option value="Basquetbol">Basquetbol</option>
          <option value="Voleibol">Voleibol</option>
          <option value="Atletismo">Atletismo</option>
		</select>  
      </div>
      <label class="col-md-1">Colegio ingles vs</label>
	  <div class="col-md-2">
	      <input id="inp_colegio" class="form-control" type="text" placeholder="nombre de escuela">
      </div>
      <label class="col-md-1">Marcador:</label>
	  <div class="col-md-1">
	      <input id="inp_marcador1" class="form-control" type="text">
      </div> 
	  <div class="col-md-1">
	      <input id="inp_marcador2" class="form-control" type="text">
      </div>
	  <label class="col-md-1">Categoria:</label>
	  <div class="col-md-3">
		<select class="form-control" id="inp_categoria"  multiple="multiple" required>
		  <option selected disabled value="">Selecciona:</option>
		  <!-----F&uacute;tbol--->
		  <option value="Biberones">Biberones</option>
		  <option value="Dientes de leche">Dientes de leche</option>
          <option value="Asqueles">Voleibol</option>
          <option value="Convivencia">Convivencia</option>
		  <option value="Juvenil A">Juvenil A</option>
		  <option value="Juvenil B">Juvenil B</option>
          <option value="Juvenil C">Juvenil C</option>
          <option value="Infantil Menor">Infantil Menor</option>
		  <option value="Infantil Mayor">Infantil Mayor</option>
		  <option value="Infantil Menor">Basquetbol</option>
          <option value="Infantil Mayor">Infantil Mayor</option>
		  <!-----Basquetbol--->
          <option value="BabyBasquet">BabyBasquet</option>
		  <option value="Promocional">Promocional</option>
		  <option value="Minibasquet">Minibasquet</option>
          <option value="Pasarela">Pasarela</option>
          <option value="Cadetes">Cadetes</option>
		  <option value="Elite">Elite</option>
		  <!-----Voleibol--->
		  <option value="Primaria">Atletismo</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		  <!-----Atletismo--->
           <option value="Primaria">Primaria</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		</select>
	</div>
   </div>
   <div class="form-group row">
	  <label class="col-sm-1">Fecha del partido:</label>
		 <div class="col-sm-2">
			<input type="date" name="bday" class="form-conrtrol" id="inp_fecha" placerholder="mm/dd/yyyy">
		 </div>
	 	 <label class="col-md-1">Lugar:</label>
	 	 <div class="col-md-2">
	      	<input id="inp_lugar" class="form-control" type="text">
     	 </div>
		 <label class="col-md-1">Tipo de partido:</label>
			 <div class="col-md-2">
			 	<select class="form-control" id="inp_tipo" required>
					<option selected disabled value= "">Selecciona</option>
					<option value="Amistoso">Amistoso</option>
					<option value="Liga">Liga</option>
				</select> 
			 </div>
			 <label class="col-md-1">Otro:</label>
			 <div class="col-md-2">
	      		<input id="inp_otro" class="form-control" type="text">
     		 </div>
  </div>
  <label>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</label>
  <div class="form-group row">
  	<label class="col-md-1">Jugadores:</label>
	  <div class="col-md-2">
	      <input id="inp_jugadores" class="form-control" type="text">
      </div>
      <label class="col-md-1">Citado</label>
	  <div class="col-md-1">
	      <input id="inp_citado" class="form-control" type="text">
      </div>
      <label class="col-md-1">Asisti&oacute;:</label>
	  <div class="col-md-1">
	      <input id="inp_asistio" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">0-5 min:</label></th>
	 	 <div class="col-md-1">
	      	<input id="inp_min1" class="form-control" type="text">
     	 </div>
	  <label class="col-md-1">6-10 min</label>
		 <div class="col-md-1">
	      	<input id="inp_min2" class="form-control" type="text">
     	 </div>
   </div>
   <div class="form-group row">
	 <label class="col-md-1">11-15 min</label>
		 <div class="col-md-1">
	      	<input id="inp_min3" class="form-control" type="text">
     	 </div>
	 <label class="col-md-1">16-20 min</label>
		 <div class="col-md-1">
	      	<input id="inp_min4" class="form-control" type="text">
     	 </div>
	 <label class="col-md-1">26-30 min</label>
		 <div class="col-md-1">
	      	<input id="inp_min5" class="form-control" type="text">
     	 </div>
	 <label class="col-md-1">31-35 min</label>
		 <div class="col-md-1">
	      	<input id="inp_min6" class="form-control" type="text">
     	 </div>
	 <label class="col-md-1">36-20 min</label>
		 <div class="col-md-1">
	      	<input id="inp_min7" class="form-control" type="text">
     	 </div>
	 </div>
	  <label>---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</label>
	 <div class="form-group row">
		<label class="col-md-2">Amonestados:</label>
			<div class="col-md-4">
				<input id="inp_amonestados" class="form-control" type="text">
			 </div>	
		<label class="col-md-2">Expulsados:</label>
			<div class="col-md-4">
				<input id="inp_expulsados" class="form-control" type="text">
			 </div>
	</div>		 
	<div class="form-group row">		 
	 <label class="col-md-2">Insidentes:</label>
	<div class="col-md-4">
		<input id="inp_insidentes" class="form-control" type="text">
	 </div>	
	 <label class="col-md-2">Conducta de los padres de familia:</label>
	<div class="col-md-4">
		<input id="inp_conducta" class="form-control" type="text">
	 </div>	
	</div> 
  <div align="center">
    <button class="btn btn-primary" id="btn_nuevo">Nuevo reporte</button>
  </div>'; } ?>
  <br>
  <div class="form-group row">
    <label class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar reporte</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar reporte</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
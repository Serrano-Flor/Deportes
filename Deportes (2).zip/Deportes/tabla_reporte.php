<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['deporte'])) { $deporte = $_POST['deporte']; }
if(isset($_POST['colegio'])) { $colegio = $_POST['colegio']; }
if(isset($_POST['marcador1'])) { $marcador1 = $_POST['marcador1']; } 
if(isset($_POST['marcador2'])) { $marcador2 = $_POST['marcador2']; }
if(isset($_POST['categoria'])) { $categoria = $_POST['categoria']; }
if(isset($_POST['fecha'])) { $fecha = $_POST['fecha']; }
if(isset($_POST['lugar'])) { $lugar = $_POST['lugar']; }
if(isset($_POST['tipo'])) { $tipo = $_POST['tipo']; }
if(isset($_POST['otro'])) { $otro = $_POST['otro']; }
if(isset($_POST['jugadores'])) { $jugadores = $_POST['jugadores']; } 
if(isset($_POST['citado'])) { $citado = $_POST['citado']; }
if(isset($_POST['asistio'])) { $asistio = $_POST['asistio']; }
if(isset($_POST['min1'])) { $min1 = $_POST['min1']; }
if(isset($_POST['min2'])) { $min2 = $_POST['min2']; }
if(isset($_POST['min3'])) { $min3 = $_POST['min3']; }
if(isset($_POST['min4'])) { $min4 = $_POST['min4']; }
if(isset($_POST['min5'])) { $min5 = $_POST['min5']; }
if(isset($_POST['min6'])) { $min6 = $_POST['min6']; }
if(isset($_POST['min7'])) { $min7 = $_POST['min7']; }
if(isset($_POST['amonestados'])) { $amonestados = $_POST['amonestados']; } 
if(isset($_POST['expulsados'])) { $expulsados = $_POST['expulsados']; }
if(isset($_POST['insidentes'])) { $insidentes = $_POST['insidentes']; }
if(isset($_POST['conducta'])) { $conducta = $_POST['conducta']; }
if(isset($_POST['reporte_id'])) { $reporte_id = $_POST['reporte_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.reporte (Deporte, Colegio, Marcador1, Marcador2, Categoria, Fecha, Lugar, Tipo, Otro, Jugadores, Citado, Asistio, Min1, Min2, Min3, Min4, Min5, Min6, Min7, Amonestados, Expulsados, Insidentes, Conducta) values('$deporte', '$colegio', '$marcador1', '$marcador2', 'categoria', '$fecha', '$lugar', '$tipo', '$otro', '$jugadores', '$citado', '$asistio', '$min1', '$min2', '$min3', '$min4', '$min5', '$min6', '$min7', '$amonestados', '$expulsados', '$insidentes', '$conducta')");
          echo Tabla(); 
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.reporte set Deporte= '$deporte', Colegio= '$colegio', Marcador1= '$marcador1', Marcador2= '$marcador2', Categoria= 'categoria', Fecha= '$fecha', Lugar= '$lugar', Tipo= '$tipo', Otro= '$otro', Jugadores= '$jugadores', Citado= '$citado', Asistio= '$asistio', Min1= '$min1', Min2= '$min2', Min3= '$min3', Min4= '$min4', Min5= '$min5', Min6= '$min6', Min7= '$min7', Amonestados= '$amonestados', Expulsados= '$expulsados', Insidentes= '$insidentes', Conducta= '$conducta' where reporte_id = '$reporte_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.reporte where reporte_id= '$reporte_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}

function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.reporte");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));

		$regreso.= '<table class="table table-striped table-bordered" id="tabla_reporte">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Reporte ID</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Colegio</p></th>
							<th class="col-md-2"><p align="center">Marcador 1</p></th>
							<th class="col-md-2"><p align="center">Marcador 2</p></th>
							<th class="col-md-2"><p align="center">Categoria</p></th>
							<th class="col-md-2"><p align="center">Fecha</p></th>
							<th class="col-md-2"><p align="center">Lugar</p></th>
							<th class="col-md-2"><p align="center">Tipo</p></th>
							<th class="col-md-2"><p align="center">Otro</p></th>
							
							<th class="col-md-2"><p align="center">Jugadores</p></th>
							<th class="col-md-2"><p align="center">Citado</p></th>
							<th class="col-md-2"><p align="center">Asistio</p></th>
							<th class="col-md-2"><p align="center">Min 1</p></th>
							<th class="col-md-2"><p align="center">Min 2</p></th>
							<th class="col-md-2"><p align="center">Min 3</p></th>
							<th class="col-md-2"><p align="center">Min 4</p></th>
							<th class="col-md-2"><p align="center">Min 5</p></th>
							<th class="col-md-2"><p align="center">Min 6</p></th>
							<th class="col-md-2"><p align="center">Min 7</p></th>
							
							<th class="col-md-2"><p align="center">Amonestados</p></th>
							<th class="col-md-2"><p align="center">Expulsados</p></th>
							<th class="col-md-2"><p align="center">Insidentes</p></th>
							<th class="col-md-2"><p align="center">Conducta</p></th>';
                            if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
                                    <th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.= '</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
				  $reporte_id = $fila['reporte_id'];
				  $deporte = $fila['Deporte'];
				  $colegio = $fila['Colegio'];
				  $marcador1 = $fila['Marcador1'];
				  $marcador2 = $fila['Marcador2'];
				  $categoria = $fila['Categoria'];
				  $fecha = $fila['Fecha'];
				  $lugar = $fila['Lugar'];
				  $tipo = $fila['Tipo'];
				  $otro = $fila['Otro'];
				  
				  $jugadores = $fila['Jugadores'];
				  $citado = $fila['Citado'];
				  $asistio = $fila['Asistio'];
				  $min1 = $fila['Min1'];
				  $min2 = $fila['Min2'];
				  $min3 = $fila['Min3'];
				  $min4 = $fila['Min4'];
				  $min5 = $fila['Min5'];
				  $min6 = $fila['Min6'];
				  $min7 = $fila['Min7'];
				  
				  $amonestados = $fila['Amonestados'];
				  $expulsados = $fila['Expulsados'];
				  $insidentes = $fila['Insidentes'];
				  $conducta = $fila['Conducta'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $reporte_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$colegio.'</td>
						  <td style="vertical-align:middle;" align="center">'.$marcador1.'</td>
						  <td style="vertical-align:middle;" align="center">'.$marcador2.'</td>
						  <td style="vertical-align:middle;" align="center">'.$categoria.'</td>
						  <td style="vertical-align:middle;" align="center">'.$fecha.'</td>
						  <td style="vertical-align:middle;" align="center">'.$lugar.'</td>
						  <td style="vertical-align:middle;" align="center">'.$tipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$otro.'</td>
						  
						  <td style="vertical-align:middle;" align="center">'.$jugadores.'</td>
						  <td style="vertical-align:middle;" align="center">'.$citado.'</td>
						  <td style="vertical-align:middle;" align="center">'.$asistio.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min1.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min2.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min3.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min4.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min5.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min6.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min7.'</td>
						  
						  <td style="vertical-align:middle;" align="center">'.$amonestados.'</td>
						  <td style="vertical-align:middle;" align="center">'.$expulsados.'</td>
						  <td style="vertical-align:middle;" align="center">'.$insidentes.'</td>
						  <td style="vertical-align:middle;" align="center">'.$conducta.'</td>';
                          if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$reporte_id.'" class="btn_modificar btn btn-success" accion="editreporte">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$reporte_id.'" class="btn_eliminar btn btn-danger" accion="delreporte">Eliminar                          </button></td>';
                          }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $reporte_id = $_POST['reporte_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.reporte where reporte_id= '$reporte_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $reporte_id = $fila['reporte_id'];
    $deporte = $fila['Deporte'];
    $colegio = $fila['Colegio'];
    $marcador1 = $fila['Marcador1'];
    $marcador2 = $fila['Marcador2'];
	$categoria = $fila['Categoria'];
    $fecha = $fila['Fecha'];
    $lugar = $fila['Lugar'];
    $tipo = $fila['Tipo'];
    $otro = $fila['Otro'];
  
    $jugadores = $fila['Jugadores'];
    $citado = $fila['Citado'];
    $asistio = $fila['Asistio'];
    $min1 = $fila['Min1'];
    $min2 = $fila['Min2'];
    $min3 = $fila['Min3'];
    $min4 = $fila['Min4'];
    $min5 = $fila['Min5'];
    $min6 = $fila['Min6'];
    $min7 = $fila['Min7'];
  
    $amonestados = $fila['Amonestados'];
    $expulsados = $fila['Expulsados'];
    $insidentes = $fila['Insidentes'];
    $conducta = $fila['Conducta'];

        
    $regreso= '<label class="col-md-2">Deporte:</label>
				  <div class="col-md-3">
					<select class="form-control" id="inp_deporte_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($deporte == 'F&uacute;tbol'){
                          $regreso.= '<option value="F&uacute;tbol" selected>F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      } elseif($deporte == 'Basquetbol'){
                         $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol" selected>Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>'; 
					 } elseif($deporte == 'Voleibol'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol" selected>Voleibol</option>
								   	<option value="Atletismo">Atletismo</option>'; 
					} elseif($deporte == 'Atletismo'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol">Voleibol</option>
								   	<option value="Atletismo" selected>Atletismo</option>';				
                      } else {
                          $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      }
               		$regreso.= '</select>
				  </div>
				  <label class="col-md-2">Colegio ingles vs</label>
				  <div class="col-md-4">
					  <input id="inp_colegio_modal" class="form-control" type="text" value= "'.$colegio.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">Marcador:</label>
				  <div class="col-md-2">
					  <input id="inp_marcador1_modal" class="form-control" type="text" value= "'.$marcador1.'">
				  </div>
				  <div class="col-md-2">
					  <input id="inp_marcador2_modal" class="form-control" type="text" value= "'.$marcador2.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">Categoria:</label>
				   <div class="col-md-4">
				  	<select class="form-control" id="inp_categoria_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($categoria == 'selected'){
                          $regreso.= '<option value="Biberones" selected>Biberones</option>
									  <option value="Dientes de leche" selected>Dientes de leche</option>
									  <option value="Asqueles" selected>Voleibol</option>
									  <option value="Convivencia" selected>Convivencia</option>
									  <option value="Juvenil A" selected>Juvenil A</option>
									  <option value="Juvenil B" selected>Juvenil B</option>
									  <option value="Juvenil C" selected>Juvenil C</option>
									  <option value="Infantil Menor" selected>Infantil Menor</option>
									  <option value="Infantil Mayor" selected>Infantil Mayor</option>
									  <option value="Infantil Menor" selected>Basquetbol</option>
									  <option value="Infantil Mayor" selected>Infantil Mayor</option>
									  <!-----Basquetbol--->
									  <option value="BabyBasquet" selected>BabyBasquet</option>
									  <option value="Promocional" selected>Promocional</option>
									  <option value="Minibasquet" selected>Minibasquet</option>
									  <option value="Pasarela" selected>Pasarela</option>
									  <option value="Cadetes" selected>Cadetes</option>
									  <option value="Elite" selected>Elite</option>
									  <!-----Voleibol--->
									  <option value="Primaria" selected>Atletismo</option>
									  <option value="Secundaria" selected>Secundaria</option>
									  <option value="Preparatoria" selected>Preparatoria</option>
									  <!-----Atletismo--->
									   <option value="Primaria" selected>Primaria</option>
									  <option value="Secundaria" selected>Secundaria</option>
									  <option value="Preparatoria" selected>Preparatoria</option>';		  
                      } else {
                          $regreso.= '<option value="Biberones" selected>Biberones</option>
									  <option value="Dientes de leche">Dientes de leche</option>
									  <option value="Asqueles">Voleibol</option>
									  <option value="Convivencia">Convivencia</option>
									  <option value="Juvenil A">Juvenil A</option>
									  <option value="Juvenil B">Juvenil B</option>
									  <option value="Juvenil C">Juvenil C</option>
									  <option value="Infantil Menor">Infantil Menor</option>
									  <option value="Infantil Mayor">Infantil Mayor</option>
									  <option value="Infantil Menor">Basquetbol</option>
									  <option value="Infantil Mayor">Infantil Mayor</option>
									  <!-----Basquetbol--->
									  <option value="BabyBasquet">BabyBasquet</option>
									  <option value="Promocional">Promocional</option>
									  <option value="Minibasquet">Minibasquet</option>
									  <option value="Pasarela">Pasarela</option>
									  <option value="Cadetes">Cadetes</option>
									  <option value="Elite">Elite</option>
									  <!-----Voleibol--->
									  <option value="Primaria">Atletismo</option>
									  <option value="Secundaria">Secundaria</option>
									  <option value="Preparatoria">Preparatoria</option>
									  <!-----Atletismo--->
									   <option value="Primaria">Primaria</option>
									  <option value="Secundaria">Secundaria</option>
									  <option value="Preparatoria">Preparatoria</option>';
                      }
               		$regreso.= '</select></div>
					<br><br><br>
				  <label class="col-sm-2">Fecha del partido:</label>
					 <div class="col-sm-2">
						<input type="date" class="form-conrtrol" id="inp_fecha_modal" style="border-radius: 5px; border: 1px solid #39c; width:165px; height:35px;" placerholder="mm/dd/yyyy" value= "'.$fecha.'">
					 </div></div><br><br><br>		 
					 <label class="col-md-2">Lugar:</label>
					 <div class="col-md-3">
						<input id="inp_lugar_modal" class="form-control" type="text" value= "'.$lugar.'">
					 </div>
					 </div><br><br><br>	
					 <label class="col-md-2">Tipo de partido:</label>
						 <div class="col-md-3">
							<select class="form-control" id="inp_tipo_modal" required>
							  <option selected disabled value = "">Selecciona:</option>';
							  if($tipo == 'Amistoso'){
								  $regreso.= '<option value="Amistoso" selected>Amistoso</option>
											  <option value="Liga">Liga</option>';
							  } elseif($tipo == 'Liga'){
								 $regreso.= '<option value="Amistoso">Amistoso</option>
											  <option value="Liga" selected>Liga</option>'; 
							  } else {
								  $regreso.= '<option value="Amistoso">Amistoso</option>
											  <option value="Liga">Liga</option>';
							  }
							$regreso.= '</select>
						</div>	 
					 <label class="col-md-2">Otro:</label>
						 <div class="col-md-3">
							<input id="inp_otro_modal" class="form-control" type="text" value= "'.$otro.'">
						 </div><br><br><br>
				<label class="col-md-2">Jugadores:</label>
				  <div class="col-md-3">
					  <input id="inp_jugadores_modal" class="form-control" type="text" value= "'.$jugadores.'">
				  </div>
				  </div>
				  <label class="col-md-2">Citado</label>
				  <div class="col-md-2">
					  <input id="inp_citado_modal" class="form-control" type="text" value= "'.$citado.'">
				  </div><br><br><br>
				  <label class="col-md-2">Asisti&oacute;:</label>
				  <div class="col-md-2">
					  <input id="inp_asistio_modal" class="form-control" type="text" value= "'.$asistio.'">
				  </div>
				  <br><br><br> 
				  <label class="col-md-2">0-5 min:</label></th>
					 <div class="col-md-2">
						<input id="inp_min1_modal" class="form-control" type="text" value= "'.$min1.'">
					 </div>
				  <label class="col-md-2">6-10 min</label>
					 <div class="col-md-2">
						<input id="inp_min2_modal" class="form-control" type="text" value= "'.$min2.'">
					 </div>
				 <label class="col-md-2">11-15 min</label>
					 <div class="col-md-2">
						<input id="inp_min3_modal" class="form-control" type="text" value= "'.$min3.'">
					 </div>
				<br><br><br>	 
				 <label class="col-md-2">16-20 min</label>
					 <div class="col-md-2">
						<input id="inp_min4_modal" class="form-control" type="text" value= "'.$min4.'">
					 </div>
				 <label class="col-md-2">26-30 min</label>
					 <div class="col-md-2">
						<input id="inp_min5_modal" class="form-control" type="text" value= "'.$min5.'">
					 </div>
				 <label class="col-md-2">31-35 min</label>
					 <div class="col-md-2">
						<input id="inp_min6_modal" class="form-control" type="text" value= "'.$min6.'">
					 </div>
				<br><br><br>	 
				 <label class="col-md-2">36-20 min</label>
					 <div class="col-md-2">
						<input id="inp_min7_modal" class="form-control" type="text" value= "'.$min7.'">
					 </div>
					<label class="col-md-3">Amonestados:</label>
						<div class="col-md-4">
							<input id="inp_amonestados_modal" class="form-control" type="text" value= "'.$amonestados.'">
						 </div>
				<br><br><br>		 	
					<label class="col-md-2">Expulsados:</label>
						<div class="col-md-3">
							<input id="inp_expulsados_modal" class="form-control" type="text" value= "'.$expulsados.'">
						 </div>		 		 
			 		 <label class="col-md-2">Insidentes:</label>
						<div class="col-md-3">
							<input id="inp_insidentes_modal" class="form-control" type="text" value= "'.$insidentes.'">
						 </div>	
				<br><br><br>		 
					 <label class="col-md-5">Conducta de los padres de familia:</label>
						<div class="col-md-4">
							<input id="inp_conducta_modal" class="form-control" type="text" value= "'.$conducta.'">
						 </div>';
    return $regreso;
}

function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.reporte where Deporte like '%$busqueda%' or Colegio like '%$busqueda%' or Marcador1 like '%$busqueda%' 
	or Marcador2 like '%$busqueda%' or Fecha like '%$busqueda%' or Lugar like '%$busqueda%' or Tipo like '%$busqueda%' or Otro like '%$busqueda%' or Jugadores like '%$busqueda%'
	or Citado like '%$busqueda%' or Asistio like '%$busqueda%' or Min1 like '%$busqueda%' or Min2 like '%$busqueda%' or Min3 like '%$busqueda%' or Min4 like '%$busqueda%' 
	or Min5 like '%$busqueda%' or Min6 like '%$busqueda%' or Min7 like '%$busqueda%' or Amonestados like '%$busqueda%' or Expulsados like '%$busqueda%' 
	or Insidentes like '%$busqueda%' or Conducta like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_reporte">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Reporte ID</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Colegio</p></th>
							<th class="col-md-2"><p align="center">Marcador 1</p></th>
							<th class="col-md-2"><p align="center">Marcador 2</p></th>
							<th class="col-md-2"><p align="center">Fecha</p></th>
							<th class="col-md-2"><p align="center">Lugar</p></th>
							<th class="col-md-2"><p align="center">Tipo</p></th>
							<th class="col-md-2"><p align="center">Otro</p></th>
							
							<th class="col-md-2"><p align="center">Jugadores</p></th>
							<th class="col-md-2"><p align="center">Citado</p></th>
							<th class="col-md-2"><p align="center">Asistio</p></th>
							<th class="col-md-2"><p align="center">Min 1</p></th>
							<th class="col-md-2"><p align="center">Min 2</p></th>
							<th class="col-md-2"><p align="center">Min 3</p></th>
							<th class="col-md-2"><p align="center">Min 4</p></th>
							<th class="col-md-2"><p align="center">Min 5</p></th>
							<th class="col-md-2"><p align="center">Min 6</p></th>
							<th class="col-md-2"><p align="center">Min 7</p></th>
							
							<th class="col-md-2"><p align="center">Amonestados</p></th>
							<th class="col-md-2"><p align="center">Expulsados</p></th>
							<th class="col-md-2"><p align="center">Insidentes</p></th>
							<th class="col-md-2"><p align="center">Conducta</p></th>';
                            if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.=' <th class="col-md-2"><p align="center">Modificar</p></th>
							     <th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
						  $regreso.= '</tr>
						</thead>
					<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);
					  $reporte_id = $fila['reporte_id'];
				      $deporte = $fila['Deporte'];
				      $colegio = $fila['Colegio'];
				      $marcador1 = $fila['Marcador1'];
				      $marcador2 = $fila['Marcador2'];
				      $fecha = $fila['Fecha'];
				      $lugar = $fila['Lugar'];
				      $tipo = $fila['Tipo'];
				      $otro = $fila['Otro'];
				  
				      $jugadores = $fila['Jugadores'];
				      $citado = $fila['Citado'];
				      $asistio = $fila['Asistio'];
				      $min1 = $fila['Min1'];
				      $min2 = $fila['Min2'];
				      $min3 = $fila['Min3'];
				      $min4 = $fila['Min4'];
				      $min5 = $fila['Min5'];
				      $min6 = $fila['Min6'];
				      $min7 = $fila['Min7'];
				  
     			      $amonestados = $fila['Amonestados'];
				      $expulsados = $fila['Expulsados'];
				      $insidentes = $fila['Insidentes'];
				      $conducta = $fila['Conducta'];
				      $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $reporte_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$colegio.'</td>
						  <td style="vertical-align:middle;" align="center">'.$marcador1.'</td>
						  <td style="vertical-align:middle;" align="center">'.$marcador2.'</td>
						  <td style="vertical-align:middle;" align="center">'.$fecha.'</td>
						  <td style="vertical-align:middle;" align="center">'.$lugar.'</td>
						  <td style="vertical-align:middle;" align="center">'.$tipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$otro.'</td>
						  
						  <td style="vertical-align:middle;" align="center">'.$jugadores.'</td>
						  <td style="vertical-align:middle;" align="center">'.$citado.'</td>
						  <td style="vertical-align:middle;" align="center">'.$asistio.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min1.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min2.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min3.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min4.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min5.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min6.'</td>
						  <td style="vertical-align:middle;" align="center">'.$min7.'</td>
						  
						  <td style="vertical-align:middle;" align="center">'.$amonestados.'</td>
						  <td style="vertical-align:middle;" align="center">'.$expulsados.'</td>
						  <td style="vertical-align:middle;" align="center">'.$insidentes.'</td>
						  <td style="vertical-align:middle;" align="center">'.$conducta.'</td>';
						  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.=' <td style="vertical-align:middle;" align="center"><button id="'.$reporte_id.'" class="btn_modificar btn btn-success" accion="editreporte">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$reporte_id.'" class="btn_eliminar btn btn-danger" accion="delreporte">Eliminar                          </button></td>';
                          }
                        $regreso.='</tr>'; 
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>
<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Visitante') {
      header('Location: Menu.php');
  }
  
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Lista</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_lista.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
	  var nombre_inp = $('#inp_nombre').val();
	  var apellidos_inp = $('#inp_apellidos').val();
	  var ano_inp = $('#inp_ano').val();
	  var grado_inp = $('#inp_grado').val();
	  var uno_inp = $('#inp_uno').val();
	  var dos_inp = $('#inp_dos').val();
	  var tres_inp = $('#inp_tres').val();
	  var cuatro_inp = $('#inp_cuatro').val();
	  var cinco_inp = $('#inp_cinco').val();
	  var seis_inp = $('#inp_seis').val();
	  var siete_inp = $('#inp_siete').val();
	  var ocho_inp = $('#inp_ocho').val();
	  var nueve_inp = $('#inp_nueve').val();
	  var diez_inp = $('#inp_diez').val();
	  var once_inp = $('#inp_once').val();
	  var doce_inp = $('#inp_doce').val();
	  var trece_inp = $('#inp_trece').val();
	  var catorce_inp = $('#inp_catorce').val();
	  var quince_inp = $('#inp_quince').val();
	  var diezyseis_inp = $('#inp_diezyseis').val();
	  var diezysiete_inp = $('#inp_diezysiete').val();
	  var diezyocho_inp = $('#inp_diezyocho').val();
	  var diezynueve_inp = $('#inp_diezynueve').val();
	  var veinte_inp = $('#inp_veinte').val();
	  var veinteyuno_inp = $('#inp_veinteyuno').val();
	  var veinteydos_inp = $('#inp_veinteydos').val();
	  var veinteytres_inp = $('#inp_veinteytres').val();
	  var veinteycuatro_inp = $('#inp_veinteycuatro').val();
	  var veinteycinco_inp = $('#inp_veinteycinco').val();
	  var veinteyseis_inp = $('#inp_veinteyseis').val();
	  var veinteysiete_inp = $('#inp_veinteysiete').val();
	  var veinteyocho_inp = $('#inp_veinteyocho').val();
	  var veinteynueve_inp = $('#inp_veinteynueve').val();
	  var treinta_inp = $('#inp_treinta').val();
	  var treintayuno_inp = $('#inp_treintayuno').val();
	  var categoria_inp = $('#inp_categoria').val();

	  var campos_insert = {nombre: nombre_inp, apellidos: apellidos_inp, ano: ano_inp, grado: grado_inp, uno: uno_inp, dos: dos_inp, tres: tres_inp, cuatro: cuatro_inp, 
	  cinco: cinco_inp, seis: seis_inp, siete: siete_inp, ocho: ocho_inp, nueve: nueve_inp, diez: diez_inp, once: once_inp, doce: doce_inp, trece: trece_inp, 
	  catorce: catorce_inp, quince: quince_inp, diezyseis: diezyseis_inp, diezysiete: diezysiete_inp, diezyocho: diezyocho_inp, diezynueve: diezynueve_inp, 
	  veinte: veinte_inp, veinteyuno: veinteyuno_inp, veinteydos: veinteydos_inp, veinteytres: veinteytres_inp, veinteycuatro: veinteycuatro_inp, 
	  veinteycinco: veinteycinco_inp, veinteyseis: veinteyseis_inp, veinteysiete: veinteysiete_inp, veinteyocho: veinteyocho_inp, veinteynueve: veinteynueve_inp, 
	  treinta: treinta_inp, treintayuno: treintayuno_inp, categoria: categoria_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_lista.php',

		  success: function(response){
			swal({   
                  type: "success",   
                  title: "¡Se inserto correctamente!", 
                });
			$('#div_pri').html(response);
			$('#inp_nombre').val('');
			$('#inp_apellidos').val('');
			$('#inp_ano').val('');
			$('#inp_grado').val('');
			$('#inp_uno').val('');
			$('#inp_dos').val('');
			$('#inp_tres').val('');
			$('#inp_cuatro').val('');
			$('#inp_cinco').val('');
			$('#inp_seis').val('');
			$('#inp_siete').val('');
			$('#inp_ocho').val('');
			$('#inp_nueve').val('');
			$('#inp_diez').val('');
			$('#inp_once').val('');
			$('#inp_doce').val('');
			$('#inp_trece').val('');
			$('#inp_catorce').val('');
			$('#inp_quince').val('');
			$('#inp_diezyseis').val('');
			$('#inp_diezysiete').val('');
			$('#inp_diezyocho').val('');
			$('#inp_diezynueve').val('');
			$('#inp_veinte').val('');
			$('#inp_veinteyuno').val('');
			$('#inp_veinteydos').val('');
			$('#inp_veinteytres').val('');
			$('#inp_veinteycuatro').val('');
			$('#inp_veinteycinco').val('');
			$('#inp_veinteyseis').val('');
			$('#inp_veinteysiete').val('');
			$('#inp_veinteyocho').val('');
			$('#inp_veinteynueve').val('');
			$('#inp_treinta').val('');
			$('#inp_treintayuno').val('');
			$('#inp_categoria').val('');
		  },

		  error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
    
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {lista_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_lista.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
      var id = $(this).attr('id');
	  var nombre_inp = $('#inp_nombre_modal').val();
	  var apellidos_inp = $('#inp_apellidos_modal').val();
	  var ano_inp = $('#inp_ano_modal').val();
	  var grado_inp = $('#inp_grado_modal').val();
	  var uno_inp = $('#inp_uno_modal').val();
	  var dos_inp = $('#inp_dos_modal').val();
	  var tres_inp = $('#inp_tres_modal').val();
	  var cuatro_inp = $('#inp_cuatro_modal').val();
	  var cinco_inp = $('#inp_cinco_modal').val();
	  var seis_inp = $('#inp_seis_modal').val();
	  var siete_inp = $('#inp_siete_modal').val();
	  var ocho_inp = $('#inp_ocho_modal').val();
	  var nueve_inp = $('#inp_nueve_modal').val();
	  var diez_inp = $('#inp_diez_modal').val();
	  var once_inp = $('#inp_once_modal').val();
	  var doce_inp = $('#inp_doce_modal').val();
	  var trece_inp = $('#inp_trece_modal').val();
	  var catorce_inp = $('#inp_catorce_modal').val();
	  var quince_inp = $('#inp_quince_modal').val();
	  var diezyseis_inp = $('#inp_diezyseis_modal').val();
	  var diezysiete_inp = $('#inp_diezysiete_modal').val();
	  var diezyocho_inp = $('#inp_diezyocho_modal').val();
	  var diezynueve_inp = $('#inp_diezynueve_modal').val();
	  var veinte_inp = $('#inp_veinte_modal').val();
	  var veinteyuno_inp = $('#inp_veinteyuno_modal').val();
	  var veinteydos_inp = $('#inp_veinteydos_modal').val();
	  var veinteytres_inp = $('#inp_veinteytres_modal').val();
	  var veinteycuatro_inp = $('#inp_veinteycuatro_modal').val();
	  var veinteycinco_inp = $('#inp_veinteycinco_modal').val();
	  var veinteyseis_inp = $('#inp_veinteyseis_modal').val();
	  var veinteysiete_inp = $('#inp_veinteysiete_modal').val();
	  var veinteyocho_inp = $('#inp_veinteyocho_modal').val();
	  var veinteynueve_inp = $('#inp_veinteynueve_modal').val();
	  var treinta_inp = $('#inp_treinta_modal').val();
	  var treintayuno_inp = $('#inp_treintayuno_modal').val();
	  var categoria_inp = $('#inp_categoria_modal').val();

        
      var campos_modificar = {lista_id: id, nombre: nombre_inp, apellidos: apellidos_inp, ano: ano_inp, grado: grado_inp, uno: uno_inp, dos: dos_inp, tres: tres_inp, cuatro: cuatro_inp, cinco: cinco_inp, seis: seis_inp, siete: siete_inp, ocho: ocho_inp, nueve: nueve_inp, diez: diez_inp, once: once_inp, doce: doce_inp, trece: trece_inp, catorce: catorce_inp, quince: quince_inp, diezyseis: diezyseis_inp, diezysiete: diezysiete_inp, diezyocho: diezyocho_inp, diezynueve: diezynueve_inp, veinte: veinte_inp, veinteyuno: veinteyuno_inp, veinteydos: veinteydos_inp, veinteytres: veinteytres_inp, veinteycuatro: veinteycuatro_inp, veinteycinco: veinteycinco_inp, veinteyseis: veinteyseis_inp, veinteysiete: veinteysiete_inp, veinteyocho: veinteyocho_inp, veinteynueve: veinteynueve_inp, treinta: treinta_inp, treintayuno: treintayuno_inp, categoria: categoria_inp act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_lista.php',

              success: function(response){
                $('#div_pri').html(response);
				swal({   
                  type: "success",   
                  title: "¡Se actualizo la información con éxito!", 
                });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar de la lista con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {lista_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_lista.php',

              success: function(response){
				swal({   
                  type: "success",   
                  title: "¡Se elimino con éxito!", 
                });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_lista.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
    
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_lista{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-check"></span>&nbsp; Lista de asistencia</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  	<br>
  <div class="form-group row">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente') {
	echo '<label class="col-md-1">Nombre(s):</label>
	  <div class="col-md-2">
	      <input id="inp_nombre" class="form-control" type="text">
      </div>
      <label class="col-md-1">Apellidos:</label>
	  <div class="col-md-2">
	      <input id="inp_apellidos" class="form-control" type="text">
      </div>
	  <label class="col-md-1">A&ntilde;o:</label>
	  <div class="col-md-2">
	      <input id="inp_ano" class="form-control" type="text">
	  </div>  
   </div> 
   <div class="form-group row">
      <label class="col-md-1">Grado:</label>
	  <div class="col-md-1">
	      <input id="inp_grado" class="form-control" type="text">
      </div>
      <label class="col-md-1">1</label>
	  <div class="col-md-1">
	      <input id="inp_uno" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">2</label>
	  <div class="col-md-1">
	      <input id="inp_dos" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">3</label>
	  <div class="col-md-1">
	      <input id="inp_tres" class="form-control" type="text">
      </div>
	  <label class="col-md-1">4</label>
	  <div class="col-md-1">
	      <input id="inp_cuatro" class="form-control" type="text">
      </div>
	  <label class="col-md-1">5</label>
	  <div class="col-md-1">
	      <input id="inp_cinco" class="form-control" type="text">
      </div>   
   </div> 
   <div class="form-group row">
	  <label class="col-md-1">6</label>
	  <div class="col-md-1">
	      <input id="inp_seis" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">7</label>
	  <div class="col-md-1">
	      <input id="inp_siete" class="form-control" type="text">
      </div>
	  <label class="col-md-1">8</label>
	  <div class="col-md-1">
	      <input id="inp_ocho" class="form-control" type="text">
      </div>
	  <label class="col-md-1">9</label>
	  <div class="col-md-1">
	      <input id="inp_nueve" class="form-control" type="text">
      </div>
	  <label class="col-md-1">10</label>
	  <div class="col-md-1">
	      <input id="inp_diez" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">11</label>
	  <div class="col-md-1">
	      <input id="inp_once" class="form-control" type="text">
      </div>  
   </div>
   <div class="form-group row">
	  <label class="col-md-1">12</label>
	  <div class="col-md-1">
	      <input id="inp_doce" class="form-control" type="text">
      </div>
	   <label class="col-md-1">13</label>
	  <div class="col-md-1">
	      <input id="inp_trece" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">14</label>
	  <div class="col-md-1">
	      <input id="inp_catorce" class="form-control" type="text">
      </div>
	  <label class="col-md-1">15</label>
	  <div class="col-md-1">
	      <input id="inp_quince" class="form-control" type="text">
      </div>
	  <label class="col-md-1">16</label>
	  <div class="col-md-1">
	      <input id="inp_diezyseis" class="form-control" type="text">
      </div>
      <label class="col-md-1">17</label>
	  <div class="col-md-1">
	      <input id="inp_diezysiete" class="form-control" type="text">
      </div>   
   </div>
   <div class="form-group row">
	  <label class="col-md-1">18</label>
	  <div class="col-md-1">
	      <input id="inp_diezyocho" class="form-control" type="text">
      </div>
	  <label class="col-md-1">19</label>
	  <div class="col-md-1">
	      <input id="inp_diezynueve" class="form-control" type="text">
      </div> 
      <label class="col-md-1">20</label>
	  <div class="col-md-1">
	      <input id="inp_veinte" class="form-control" type="text">
      </div>
      <label class="col-md-1">21</label>
	  <div class="col-md-1">
	      <input id="inp_veinteyuno" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">22</label>
	  <div class="col-md-1">
	      <input id="inp_veinteydos" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">23</label>
	  <div class="col-md-1">
	      <input id="inp_veinteytres" class="form-control" type="text">
      </div>
   </div>
   <div class="form-group row">
	  <label class="col-md-1">24</label>
	  <div class="col-md-1">
	      <input id="inp_veinteycuatro" class="form-control" type="text">
      </div>  
      <label class="col-md-1">25</label>
	  <div class="col-md-1">
	      <input id="inp_veinteycinco" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">26</label>
	  <div class="col-md-1">
	      <input id="inp_veinteyseis" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">27</label>
	  <div class="col-md-1">
	      <input id="inp_veinteysiete" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">28</label>
	  <div class="col-md-1">
	      <input id="inp_veinteyocho" class="form-control" type="text">
      </div>
      <label class="col-md-1">29</label>
	  <div class="col-md-1">
	      <input id="inp_veinteynueve" class="form-control" type="text">
      </div> 
   </div> 
   <div class="form-group row">
	  <label class="col-md-1">30</label>
	  <div class="col-md-1">
	      <input id="inp_treinta" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">31</label>
	  <div class="col-md-1">
	      <input id="inp_treintayuno" class="form-control" type="text">
      </div> 
	  <label class="col-md-1">Categoria:</label>
	  <div class="col-md-3">
	    <select class="form-control" id="inp_categoria" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Biberones">Biberones</option>
		  <option value="Dientes de leche">Dientes de leche</option>
          <option value="Asqueles">Voleibol</option>
          <option value="Convivencia">Convivencia</option>
		  <option value="Juvenil A">Juvenil A</option>
		  <option value="Juvenil B">Juvenil B</option>
          <option value="Juvenil C">Juvenil C</option>
          <option value="Infantil Menor">Infantil Menor</option>
		  <option value="Infantil Mayor">Infantil Mayor</option>
		  <option value="Infantil Menor">Basquetbol</option>
          <option value="Infantil Mayor">Infantil Mayor</option>
		  <!-----Basquetbol--->
          <option value="BabyBasquet">BabyBasquet</option>
		  <option value="Promocional">Promocional</option>
		  <option value="Minibasquet">Minibasquet</option>
          <option value="Pasarela">Pasarela</option>
          <option value="Cadetes">Cadetes</option>
		  <option value="Elite">Elite</option>
		  <!-----Voleibol--->
		  <option value="Primaria">Atletismo</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		  <!-----Atletismo--->
           <option value="Primaria">Primaria</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		</select>
	  </div> 
   </div>
     <small id="emailHelp" class="form-text text-muted" style="color:#003300">1: Asistencia, 2:Partido de Liga, 3: Partido de Amistoso, 4:Retardo, 5: Permiso otro deporte, 		     6: Permiso,7: Lesionado o Enfermo, 8: Varsity,  9: Falta justificada, 10:Falta injustificada</small>
	  <br><br><br> 
  <div align="center">
  	<button class="btn btn-primary" id="btn_nuevo">Nueva asistencia</button>
  </div>'; } ?>
  <br>
  <div class="form-group row">
    <label class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar lista</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar de la lista</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
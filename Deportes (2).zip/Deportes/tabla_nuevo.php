<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['titulo'])) { $titulo = $_POST['titulo']; }
if(isset($_POST['descripcion'])) { $descripcion = $_POST['descripcion']; }
if(isset($_POST['foto'])) { $foto = $_POST['foto']; }
if(isset($_POST['nuevo_id'])) { $nuevo_id = $_POST['nuevo_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.nuevo (Titulo, Descripcion, Foto) values('$titulo','$descripcion','$foto')");
          echo Tabla();
    break;
    
    case 'insert-img':
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'img/fotos/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select Foto from Deportes.nuevo where Foto like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
                
            }
    break;
	
    case 'modificar-img':
          $foto = $_POST['foto'];
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'img/fotos/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = 0;//mysqli_num_rows(mysqli_query($con, "select Foto from Deportes.nuevo where Foto like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                        echo '<img alt="'.$foto.'" src="'.$path.'" style="height:200px;">
                            <br><button class="btn btn-warning" id="cambiar-img" valor="img/fotos/'.$foto.'">Cambiar</button>
                            <input id="upload2" type="file" name="file" valor="'.$foto.'" style="display:none;"/>';
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
            }
    break;
	
	case 'modificar':
          if(isset($_POST['foto']))
              $foto = $_POST['foto']; 
          else 
          {
              $foto = '';
          }              
              
		  mysqli_query($con, "update Deportes.nuevo set Titulo= '$titulo', Descripcion= '$descripcion', Foto= '$foto' where nuevo_id = '$nuevo_id';");
          
		  echo Tabla();
    break;
	
	case 'eliminar':
          $query = mysqli_query($con, "select * from Deportes.nuevo where nuevo_id= '$nuevo_id'");
          if($query) {
              while($fila = mysqli_fetch_array($query)) {
                  extract($fila);
                  $img = $fila['Foto'];
                  
                  $filePath = 'img/fotos/'.$img;
                  if (file_exists($filePath) && $filePath != 'img/fotos/') {
                    unlink($filePath);
                  }
              }
          }

		  mysqli_query($con, "delete from Deportes.nuevo where nuevo_id= '$nuevo_id'");
		  echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
          
    case 'cambio-imagen':
        $filePath = $_POST['path'];
        if (file_exists($filePath)) 
        {
            unlink($filePath);
        }
		echo '<form id="form2" action="tabla_nuevo.php" method="post" enctype="multipart/form-data">
                   <label class="btn btn-primary btn-file">
                     Seleccionar Nuevo...<input id="upload2" type="file" name="file" style="display:none;"/>
                  </label>
                 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload2" disabled>
              </form>';
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}

function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.nuevo");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_nuevo">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Nuevo ID</p></th>
							<th class="col-md-2"><p align="center">T&iacute;tulo</p></th>
							<th class="col-md-2"><p align="center">Descripci&oacute;n</p></th>
							<th class="col-md-2"><p align="center">Foto</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
							             <th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.='</tr>
					</thead>
			<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $nuevo_id = $fila['nuevo_id'];
				  $titulo = $fila['Titulo'];
				  $descripcion = $fila['Descripcion'];
				  $foto = $fila['Foto'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $nuevo_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$titulo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$descripcion.'</td>
						  <td style="vertical-align:middle;" align="center"><span class="glyphicon glyphicon-file"></span> '.$foto.'</td>';
                    if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='
						  <td style="vertical-align:middle;" align="center"><button id="'.$nuevo_id.'" class="btn_modificar btn btn-success" accion="editnuevo">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$nuevo_id.'" class="btn_eliminar btn btn-danger" accion="delnuevo">Eliminar</button></td>';
                    }
						$regreso.='</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $nuevo_id = $_POST['nuevo_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.nuevo where nuevo_id= '$nuevo_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $nuevo_id = $fila['nuevo_id'];
    $titulo = $fila['Titulo'];
    $descripcion = $fila['Descripcion'];
	$foto = $fila['Foto'];
        
    $regreso.= '<label class="col-md-2">T&iacute;tulo:</label>
	 			 <div class="col-md-10">
	      			<input id="inp_titulo_modal" class="form-control" type="text" value= "'.$titulo.'">
				 </div>	
				 <br><br><br>
			   <label class="col-md-2">Descripci&oacute;n:</label>
				  <div class="col-md-10">
					  <input id="inp_descripcion_modal" class="form-control" type="text" value= "'.$descripcion.'">
				  </div>
				  <br><br><br>
				<label class="col-sm-2">Foto:</label>
				  <div class="col-md-10" id="div-img">';
                        if($foto){
                            $regreso.= '<img alt="'.$foto.'" src="img/fotos/'.$foto.'" style="height:200px;">
                            <br><button class="btn btn-warning" id="cambiar-img" valor="img/fotos/'.$foto.'">Cambiar</button>
                            <input id="upload2" type="file" name="file" valor="'.$foto.'" style="display:none;"/>
                            ';
                        }
                        else {
                            $regreso.= '<form id="form2" action="tabla_Documentos.php" method="post" enctype="multipart/form-data">
                               <label class="btn btn-primary btn-file">
                                 Seleccionar Nuevo...<input id="upload2" type="file" name="file" style="display:none;"/>
                              </label>
                             <input class="btn btn-success" type="submit" value="Cargar" id="file-upload2" disabled>
                          </form>';
                        }
                   $regreso.= '</div>
                   <div class="col-md-2"></div>
                   <div class="col-md-10"><div id="file-status2"></div><div id="err2"></div></div>
                   ';
    return $regreso;
}
function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.nuevo where Titulo like '%$busqueda%' or Descripcion like '%$busqueda%' or Foto like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_nuevo">
						 <thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Nuevo ID</p></th>
							<th class="col-md-2"><p align="center">T&iacute;tulo</p></th>
							<th class="col-md-2"><p align="center">Descripci&oacute;n</p></th>
							<th class="col-md-2"><p align="center">Foto</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='
                            <th class="col-md-2"><p align="center">Modificar</p></th>
							<th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.='</tr>
						 </thead>
						<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);

                      $nuevo_id = $fila['nuevo_id'];
				  	  $titulo = $fila['Titulo'];
				  	  $descripcion = $fila['Descripcion'];
				  	  $foto = $fila['Foto'];
				  	  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $nuevo_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$titulo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$descripcion.'</td>
						  <td style="vertical-align:middle;" align="center"><span class="glyphicon glyphicon-file"></span>'.$foto.'</td>';
                        if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='
						  <td style="vertical-align:middle;" align="center"><button id="'.$nuevo_id.'" class="btn_modificar btn btn-success" accion="editnuevo">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$nuevo_id.'" class="btn_eliminar btn btn-danger" accion="delnuevo">Eliminar</button></td>';
                        }
						$regreso.='</tr>'; 
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>

<?php
  
  include('conecta.php');
  $con=mysqli_connect("localhost","root","","Deportes");

  if(isset($_POST['inp_usuario']) && isset($_POST['inp_contrasena']))
  {     
    $usuario = $_POST['inp_usuario'];
    $password = $_POST['inp_contrasena'];
         
    $query = mysqli_query($con, "select * from Deportes.usuarios where Usuario like '$usuario' and Contrasena like '$password'");
    $query_count = mysqli_num_rows(mysqli_query($con, "select * from Deportes.usuarios where Usuario like '%$usuario%' and Contrasena like '$password'"));
    if($query_count != 0)
    {
      session_start();
      while($fila = mysqli_fetch_array($query))
      {
         extract($fila);
         $_SESSION['iniciada'] = 1;
         $_SESSION['usua_id'] = $fila['usuarios_id'];
         $_SESSION['usua'] = $fila['Usuario'];
         $_SESSION['usua_nombre'] = $fila['Nombre'];
         $_SESSION['usua_rol'] = $fila['Rol'];
         $_SESSION['usua_activo'] = $fila['Activo'];
          
      }
      if($_SESSION['usua_activo'] == 'Si'){
         header("location: Menu.php");
      }
      else {
         header("location: error.php");   
      }
         
    }
    else
    {
      header("Location: error.php");
    }
  }

?>

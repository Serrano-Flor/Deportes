<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Visitante') {
      header('Location: Menu.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Asistencia</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_asistencia.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
	  var deporte_inp = $('#inp_deporte option:selected').val();
	  var equipo_inp = $('#inp_equipo option:selected').val();
	  var rama_inp = $('#inp_rama option:selected').val();
	  var asistencia_inp = $('#inp_asistencia').val();
	  var calificacion_inp = $('#inp_calificacion').val();

	  var campos_insert = {deporte: deporte_inp, equipo: equipo_inp, rama: rama_inp, asistencia: asistencia_inp, calificacion: calificacion_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_asistencia.php',

		  success: function(response){
			swal({   
                  type: "success",   
                  title: "¡Se inserto correctamenteo!", 
                });
			$('#div_pri').html(response);
			$('#inp_deporte').val(''); 
			$('#inp_equipo').val('');
			$('#inp_rama').val('');
			$('#inp_asistencia').val('');
			$('#inp_calificacion').val('');
		  },

		  error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {asistencia_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_asistencia.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
        var deporte_inp = $('#inp_deporte_modal option:selected').val();
	    var equipo_inp = $('#inp_equipo_modal option:selected').val();
	    var rama_inp = $('#inp_rama_modal option:selected').val();
		var asistencia_inp = $('#inp_asistencia_modal').val();
	    var calificacion_inp = $('#inp_calificacion_modal').val();
        
        var campos_modificar = {asistencia_id: id, deporte: deporte_inp, equipo: equipo_inp, rama: rama_inp, asistencia: asistencia_inp, calificacion: calificacion_inp, 
		act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_asistencia.php',

              success: function(response){
                $('#div_pri').html(response);
				swal({   
                  type: "success",   
                  title: "¡Se actualizo la información con éxito!", 
                });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar la asistencia con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {asistencia_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_asistencia.php',

              success: function(response){
				swal({   
                  type: "success",   
                  title: "¡Se elimino con éxito!", 
                });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_asistencia.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
	 $(function(){
        $("#imprimir").click(function(){
			$(".glyphicon").hide();
			$("#menu").hide();
			$("#lista").hide();
			$("#lbl_equipo").hide();
			$("#inp_equipo").hide();
            $("#lbl_deporte").hide();
			$("#inp_deporte").hide();
			$("#lbl_rama").hide();
			$("#inp_rama").hide();
			$("#lbl_asistencia").hide();
			$("#inp_asistencia").hide();
			$("#lbl_calificacion").hide();
			$("#inp_calificacion").hide();
			$("#emailHelp").hide();
			$("#btn_nuevo").hide();
		    $("#lbl_buscar").hide();
			$("#inp_buscar").hide();
			window.print();
        });
    });
    
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_asistencia{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-ok"></span>&nbsp; Asistencia</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" id="menu" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  <div align="left">
  	<strong><p style="text-decoration:underline"><a href="Lista.php" id="lista" style="color:#FFFFFF">Lista</a></p></strong>
  </div>
  <div align="left">
  	<span class="glyphicon glyphicon-print"style="color:#FFFFFF"></span>
		 <input type="button" value="Imprimir" id="imprimir" class="btn btn-link" style="color:#003300; font-size:18px" onClick="window.print();">
	</span>
  </div>
  <br>
  <div class="form-group row">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente') {
  echo '<label id="lbl_deporte" class="col-md-1">Deporte:</label>
	  <div class="col-md-2">
		<select class="form-control" id="inp_deporte" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="F&uacute;tbol">F&uacute;tbol</option>
		  <option value="Basquetbol">Basquetbol</option>
          <option value="Voleibol">Voleibol</option>
          <option value="Atletismo">Atletismo</option>
		</select>
	  </div>
	  <label id="lbl_equipo" class="col-md-1">Equipo:</label>
	  <div class="col-md-2">
		<select class="form-control" id="inp_equipo" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Colegio ingles">Colegio ingles</option>
		  <option value="Colegio ingles verde">Colegio ingles verde</option>
		  <option value="Colegio ingles blanco">Colegio ingles blanco</option>
		</select>
	  </div>
	  <label id="lbl_rama" class="col-md-1">Rama:</label>
		  <div class="col-md-2">
			 <select class="form-control" id="inp_rama" required>
			  <option selected disabled value="">Selecciona:</option>
			  <option value="Varonil">Varonil</option>
			  <option value="Femenil">Femenil</option>
			  <option value="Mixto">Mixto</option>
			</select>
		  </div> 
   </div> 
   <div class="form-group row">
  	<label id="lbl_asistencia" class="col-md-1">Asistencia:</label>
		  <div class="col-md-1">
			  <input id="inp_asistencia" class="form-control" type="text">
		  </div>
		  <label id="lbl_calificacion" class="col-md-1">Calificaci&oacute;n:</label>
		  <div class="col-md-1">
			  <input id="inp_calificacion" class="form-control" type="text">
	  	  </div>
	  </div> 
	  <small id="emailHelp" class="form-text text-muted" style="color:#003300">1: Asistencia, 2:Partido de Liga, 3: Partido de Amistoso, 4:Retardo, 5: Permiso otro deporte, 		     6: Permiso, 7: Lesionado o Enfermo, 8: Varsity,  9: Falta justificada, 10:Falta injustificada</small>'; } ?>
	  <br><br><br>  
  <div align="center">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente') {
     echo '<button class="btn btn-primary" id="btn_nuevo">Nueva asistencia</button>'; } 
	?>
  </div><br>
  <div class="form-group row">
    <label id="lbl_buscar" class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar asistencia</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar asistencia</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
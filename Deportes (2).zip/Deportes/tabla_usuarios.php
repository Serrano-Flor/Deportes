<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

$act = $_POST['act'];
if(isset($_POST['usuario'])) { $usuario = $_POST['usuario']; } 
if(isset($_POST['nombre'])) { $nombre = $_POST['nombre']; }
if(isset($_POST['email'])) { $email = $_POST['email'] ;}
if(isset($_POST['contrasena'])) { $contrasena = $_POST['contrasena']; }
if(isset($_POST['rol'])) { $rol = $_POST['rol']; }
if(isset($_POST['categoria'])) { $categoria = $_POST['categoria']; }
if(isset($_POST['activo'])) { $activo = $_POST['activo']; }
  
if(isset($_POST['usuarios_id'])) { $usuarios_id = $_POST['usuarios_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }
   

switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.usuarios (Usuario, Nombre, Email, Contrasena, Rol, Categoria, Activo) values('$usuario', '$nombre', '$email', '$contrasena', '$rol', '$categoria', '$activo')");
          echo Tabla();
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.usuarios set Usuario= '$usuario', Nombre= '$nombre', Email= '$email', Contrasena= '$contrasena', rol= '$rol', 
		  Categoria= '$categoria', Activo= '$activo' where usuarios_id = '$usuarios_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.usuarios where usuarios_id= '$usuarios_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}
function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.usuarios");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_usuarios">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Usuarios ID</p></th>
							<th class="col-md-2"><p align="center">Usuario</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Email</p></th>
							<th class="col-md-1"><p align="center">Contrase&ntilde;a</p></th>
							<th class="col-md-2"><p align="center">Rol</p></th>
							<th class="col-md-2"><p align="center">Categoria</p></th>
							<th class="col-md-2"><p align="center">Activo</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
							<th class="col-md-2"><p align="center">Eliminar</p></th>';
	 						}
						  $regreso.= '</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
				  $usuarios_id = $fila['usuarios_id'];
				  $usuario = $fila['Usuario'];
				  $nombre = $fila['Nombre'];
				  $email = $fila['Email'];
				  $contrasena = $fila['Contrasena'];
				  $rol = $fila['Rol'];
				  $categoria = $fila['Categoria'];
				  $activo = $fila['Activo'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $usuarios_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$usuario.'</td>
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center">'.$email.'</td>
						  <td style="vertical-align:middle;" align="left">'. $contrasena.'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$rol.'</td>
						  <td style="vertical-align:middle;" align="center">'.$categoria.'</td>
						  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                            
                           if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$usuarios_id.'" class="btn_modificar btn btn-success" accion="editusuarios">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$usuarios_id.'" class="btn_eliminar btn btn-danger" accion="delusuarios">Eliminar                          </button></td>';
                          }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $usuarios_id = $_POST['usuarios_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.usuarios where usuarios_id= '$usuarios_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $usuarios_id = $fila['usuarios_id'];
    $usuario = $fila['Usuario'];
    $nombre = $fila['Nombre'];
	$email = $fila['Email'];
	$contrasena = $fila['Contrasena'];
    $rol = $fila['Rol'];
    $categoria = $fila['Categoria'];
    $activo = $fila['Activo'];
        
    $regreso= '<label class="col-md-2">Usuario:</label>
				  <div class="col-md-4">
					  <input id="inp_usuario_modal" class="form-control" type="text" value= "'.$usuario.'">
				  </div>
				  <label class="col-md-2">Nombre:</label>
				  <div class="col-md-4">
					  <input id="inp_nombre_modal" class="form-control" type="text" value= "'.$nombre.'">
				  </div>  
				  <br><br><br>
				  <label class="col-md-2">E-mail:</label>
				  <div class="col-md-4">
					  <input id="inp_email_modal" class="form-control" type="text" value= "'.$email.'">
				  </div>	  
				  <label class="col-md-2">Contrase&ntilde;a:</label>
				  <div class="col-md-4">
					  <input id="inp_contrasena_modal" class="form-control" type="password" value= "'.$contrasena.'">
				  </div>
			      <br><br><br>
				  <label class="col-md-2">Rol:</label>
				  <div class="col-md-4">';
					if($rol == 'Administrador') {
                      $regreso.= '<select class="form-control" id="inp_rol_modal" required>
                        <option disabled value="">Selecciona:</option>
                        <option value="Administrador" selected>Administrador</option>
                        <option value="Entrenador">Entrenador</option>
                        <option value="Asistente">Asistente</option>
                        <option value="Visitante">Visitante</option>
                       </select>';
                  } elseif ($rol == 'Entrenador') {
                      $regreso.= '<select class="form-control" id="inp_rol_modal" required>
                        <option disabled value="">Selecciona:</option>
                        <option value="Administrador">Administrador</option>
                        <option value="Entrenador" selected>Entrenador</option>
                        <option value="Asistente">Asistente</option>
                        <option value="Visitante">Visitante</option>
                       </select>';
                  } elseif ($rol == 'Asistente') {
                      $regreso.= '<select class="form-control" id="inp_rol_modal" required>
                        <option disabled value="">Selecciona:</option>
                        <option value="Administrador">Administrador</option>
                        <option value="Entrenador">Entrenador</option>
                        <option value="Asistente" selected>Asistente</option>
                        <option value="Visitante">Visitante</option>
                       </select>';
                  } else if($rol == 'Visitante') {
                      $regreso.= '<select class="form-control" id="inp_rol_modal" required>
                        <option disabled value="">Selecciona:</option>
                        <option value="Administrador">Administrador</option>
                        <option value="Entrenador">Entrenador</option>
                        <option value="Asistente">Asistente</option>
                        <option value="Visitante" selected>Visitante</option>
                       </select>';
                  } else {
                      $regreso.= '<select class="form-control" id="inp_rol_modal" required>
                        <option selected disabled value="">Selecciona:</option>
                        <option value="Administrador">Administrador</option>
                        <option value="Entrenador">Entrenador</option>
                        <option value="Asistente">Asistente</option>
                        <option value="Visitante">Visitante</option>
                       </select>';
                  } 
				  $regreso.= '</div>
				  <label class="col-md-2">Categoria:</label>
				   <div class="col-md-4">
				  	<select size="5" class="form-control" id="inp_categoria_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($categoria == 'selected'){
                          $regreso.= '<option value="Biberones" selected>Biberones</option>
									  <option value="Dientes de leche" selected>Dientes de leche</option>
									  <option value="Asqueles" selected>Voleibol</option>
									  <option value="Convivencia" selected>Convivencia</option>
									  <option value="Juvenil A" selected>Juvenil A</option>
									  <option value="Juvenil B" selected>Juvenil B</option>
									  <option value="Juvenil C" selected>Juvenil C</option>
									  <option value="Infantil Menor" selected>Infantil Menor</option>
									  <option value="Infantil Mayor" selected>Infantil Mayor</option>
									  <option value="Infantil Menor" selected>Basquetbol</option>
									  <option value="Infantil Mayor" selected>Infantil Mayor</option>
									  <!-----Basquetbol--->
									  <option value="BabyBasquet" selected>BabyBasquet</option>
									  <option value="Promocional" selected>Promocional</option>
									  <option value="Minibasquet" selected>Minibasquet</option>
									  <option value="Pasarela" selected>Pasarela</option>
									  <option value="Cadetes" selected>Cadetes</option>
									  <option value="Elite" selected>Elite</option>
									  <!-----Voleibol--->
									  <option value="Primaria" selected>Atletismo</option>
									  <option value="Secundaria" selected>Secundaria</option>
									  <option value="Preparatoria" selected>Preparatoria</option>
									  <!-----Atletismo--->
									   <option value="Primaria" selected>Primaria</option>
									  <option value="Secundaria" selected>Secundaria</option>
									  <option value="Preparatoria" selected>Preparatoria</option>';		  
                      } else {
                          $regreso.= '<option value="Biberones" selected>Biberones</option>
									  <option value="Dientes de leche">Dientes de leche</option>
									  <option value="Asqueles">Voleibol</option>
									  <option value="Convivencia">Convivencia</option>
									  <option value="Juvenil A">Juvenil A</option>
									  <option value="Juvenil B">Juvenil B</option>
									  <option value="Juvenil C">Juvenil C</option>
									  <option value="Infantil Menor">Infantil Menor</option>
									  <option value="Infantil Mayor">Infantil Mayor</option>
									  <option value="Infantil Menor">Basquetbol</option>
									  <option value="Infantil Mayor">Infantil Mayor</option>
									  <!-----Basquetbol--->
									  <option value="BabyBasquet">BabyBasquet</option>
									  <option value="Promocional">Promocional</option>
									  <option value="Minibasquet">Minibasquet</option>
									  <option value="Pasarela">Pasarela</option>
									  <option value="Cadetes">Cadetes</option>
									  <option value="Elite">Elite</option>
									  <!-----Voleibol--->
									  <option value="Primaria">Atletismo</option>
									  <option value="Secundaria">Secundaria</option>
									  <option value="Preparatoria">Preparatoria</option>
									  <!-----Atletismo--->
									   <option value="Primaria">Primaria</option>
									  <option value="Secundaria">Secundaria</option>
									  <option value="Preparatoria">Preparatoria</option>';
                      }
               		$regreso.= '</select>
      			</div>
				 <br><br><br>	  
				  <label class="col-md-2">Activo:</label>
				  <div class="col-md-4">
              		<select class="form-control" id="inp_activo_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($activo == 'Si'){
                          $regreso.= '<option value="Si" selected>Si</option>
					                  <option value="No">No</option>';
                      } elseif($activo == 'No'){
                         $regreso.= '<option value="Si">Si</option>
					                  <option value="No" selected>No</option>'; 
                      } else {
                          $regreso.= '<option value="Si">Si</option>
					                  <option value="No">No</option>';
                      }
               		$regreso.= '</select>
      			</div>';
    return $regreso;
}

function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.usuarios where Usuario like '%$busqueda%' or Nombre like '%$busqueda%' or Email like '%$busqueda%' 
	or Contrasena like '%$busqueda%' or Rol like '%$busqueda%' or Categoria like '%$busqueda%' or Activo like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
			$regreso = (isset($_POST['regreso']));
			
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_usuarios">
							<thead>
							  <tr>
								<th class="col-md-1"><p align="center">#</p></th>
								<th class="col-md-1"><p align="center">Usuarios ID</p></th>
								<th class="col-md-2"><p align="center">Usuario</p></th>
								<th class="col-md-2"><p align="center">Nombre</p></th>
								<th class="col-md-2"><p align="center">Email</p></th>
								<th class="col-md-1"><p align="center">Contrase&ntilde;a</p></th>
								<th class="col-md-2"><p align="center">Rol</p></th>
								<th class="col-md-2"><p align="center">Categoria</p></th>
								<th class="col-md-2"><p align="center">Activo</p></th>';
								if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								<th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }
		
							  $regreso.='</tr>
							</thead>
						<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);
					  $usuarios_id = $fila['usuarios_id'];
				      $usuario = $fila['Usuario'];
				      $nombre = $fila['Nombre'];
				      $email = $fila['Email'];
				      $contrasena = $fila['Contrasena'];
				      $rol = $fila['Rol'];
				      $categoria = $fila['Categoria'];
				      $activo = $fila['Activo'];
				      $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $usuarios_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$usuario.'</td>
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center">'.$email.'</td>
						  <td style="vertical-align:middle;" align="left">'. $contrasena.'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$rol.'</td>
						  <td style="vertical-align:middle;" align="center">'.$categoria.'</td>
						  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                        
						  if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$usuarios_id.'" class="btn_modificar btn btn-success" accion="editusuarios">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$usuarios_id.'" class="btn_eliminar btn btn-danger" accion="delusuarios">Eliminar                          </button></td>
						</tr>';
                          }
						$regreso.='</tr>';
                      $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>

<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['imagen'])) { $imagen = $_POST['imagen']; }
if(isset($_POST['documento'])) { $documento = $_POST['documento']; }
if(isset($_POST['activo'])) { $activo = $_POST['activo']; }
if(isset($_POST['popup_id'])) { $popup_id = $_POST['popup_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
			
          mysqli_query($con, "insert into Deportes.popup (Imagen, Documento, Activo) values('$imagen','$documento','$activo')");
          echo Tabla();
    break;
	
	case 'insert-img':
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'img/fotos/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select Imagen from Deportes.popup where Imagen like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
                
            }
    break;
    
	case 'modificar-img':
          $imagen = $_POST['foto'];
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
          $path = 'img/Fotos/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select Imagen from Deportes.popup where Imagen like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                        echo '<img alt="'.$imagen.'" src="'.$path.'" style="height:150px;width:200px;">
                            <br><button class="btn btn-warning" id="cambiar-img" valor="img/fotos/'.$imagen.'">Cambiar</button>
                            <input id="upload2" type="file" name="file" valor="'.$imagen.'" style="display:none;"/>';
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
            }
    break;
          
    case 'modificar-doc':
          $documento = $_POST['doc'];
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
          $path = 'uploads/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select Documento from Deportes.popup where Documento like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                        echo '<img alt="'.$documento.'" src="'.$path.'" style="height:150px;width:200px;">
                            <br><button class="btn btn-warning" id="cambiar-doc" valor="uploads/'.$documento.'">Cambiar</button>
                            <input id="upload4" type="file" name="file" valor="'.$documento.'" style="display:none;"/>';
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
            }
    break;
    
    case 'insert-doc':
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'uploads/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select Documento from Deportes.popup where Documento like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
                
            }
    break;      
	
	case 'modificar':
	
		  if(isset($_POST['imagen']))
              $imagen = $_POST['imagen']; 
          if(isset($_POST['documento']))
              $documento = $_POST['documento']; 	
		
		  mysqli_query($con, "update Deportes.popup set Imagen= '$imagen', Documento= '$documento', Activo= '$activo' where popup_id = '$popup_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
          $query = mysqli_query($con, "select * from Deportes.popup where popup_id= '$popup_id'");
          if($query) {
              while($fila = mysqli_fetch_array($query)) 
			  {
                  extract($fila);	  
                  $img = $fila['Imagen'];
                  $doc = $fila['Documento'];
                  
                  $filePath = 'img/fotos/'.$img;
                  if (file_exists($filePath) && $filePath != 'img/fotos/') {
                    unlink($filePath);
                  }
                  
                  $filePath2 = 'uploads/'.$doc;
                  if (file_exists($filePath2) && $filePath2 != 'uploads/') {
                    unlink($filePath2);
                  }
              }
          }

		  mysqli_query($con, "delete from Deportes.popup where popup_id= '$popup_id'");
		  echo Tabla();
          
    break;
    
    case 'cambio-doc':
        $filePath = $_POST['path'];
        if (file_exists($filePath)) 
        {
            unlink($filePath);
        }
		echo '<form id="form4" action="tabla_popup.php" method="post" enctype="multipart/form-data">
						   <label class="btn btn-primary btn-file">
							 Seleccionar Nuevo...<input id="upload4" type="file" name="file" style="display:none;"/>
						  </label>
						 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload4" disabled>&nbsp;
					  </form>';
    break;
          
    case 'cambio-imagen':
        $filePath = $_POST['path'];
        if (file_exists($filePath)) 
        {
            unlink($filePath);
        }
		echo '<form id="form2" action="tabla_popup.php" method="post" enctype="multipart/form-data">
                   <label class="btn btn-primary btn-file">
                     Seleccionar Nuevo...<input id="upload2" type="file" name="file" style="display:none;"/>
                  </label>
                 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload2" disabled>
              </form>';
    break;
	
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}

function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.popup");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
	
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_popup">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Popup ID</p></th>
							<th class="col-md-2"><p align="center">Imagen</p></th>
							<th class="col-md-2"><p align="center">Documento</p></th>
							<th class="col-md-2"><p align="center">Activo</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.=' <th class="col-md-2"><p align="center">Modificar</p></th>
							         <th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.='</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $pooup_id = $fila['popup_id'];
				  $imagen = $fila['Imagen'];
				  $documento = $fila['Documento'];
				  $activo = $fila['Activo'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $popup_id .'</td>                 
						  <td style="vertical-align:middle;" align="center"><img src="img/fotos/'.$imagen.'" alt="'.$imagen.'" style="height: 80px; width:80px;">'.$imagen.'</td>
						  <td style="vertical-align:middle;" align="center"><span class="glyphicon glyphicon-file"></span>'.$documento.'</td>
						  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
						  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.='
						  <td style="vertical-align:middle;" align="center"><button id="'.$popup_id.'" class="btn_modificar btn btn-success" accion="editpopup">Modificar</button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$popup_id.'" class="btn_eliminar btn btn-danger" accion="delpopup">Eliminar</button></td>';
                        }
						$regreso.='</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $popup_id = $_POST['popup_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
	$regreso = (isset($_POST['regreso']));
    
    $query = mysqli_query($con, "select * from Deportes.popup where popup_id= '$popup_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $popup_id = $fila['popup_id'];
    $imagen = $fila['Imagen'];
	$documento = $fila['Documento'];
    $activo = $fila['Activo'];
        
    $regreso= ' <label class="col-md-2">Imagen:</label>
                  <div class="col-md-10" id="div-img">';
                        if($imagen){
                            $regreso.= '<img alt="'.$imagen.'" src="img/fotos/'.$imagen.'" style="height:150px;width:200px;">
                            <br><button class="btn btn-warning" id="cambiar-img" valor="img/fotos/'.$imagen.'">Cambiar</button>
                            <input id="upload2" type="file" name="file" valor="'.$imagen.'" style="display:none;"/>
                              <a class="btn btn-primary" href="img/fotos/'.$imagen.'" rel="nofollow">Visualizar</a>
                            ';
                        }
                        else {
                            $regreso.= '<form id="form2" action="tabla_popup.php" method="post" enctype="multipart/form-data">
                               <label class="btn btn-primary btn-file">
                                 Seleccionar Nuevo...<input id="upload2" type="file" name="file" style="display:none;"/>
                              </label>
                             <input class="btn btn-success" type="submit" value="Cargar" id="file-upload2" disabled>
                          </form>';
                        }
                   $regreso.= '</div>
                   <div class="col-md-2"></div>
                   <div class="col-md-10"><div id="file-status2"></div><div id="err2"></div></div><br><br>
				  <label class="col-md-2">Documento:</label>
					  <div class="col-md-10" id="div-doc">';
                        if($documento){
                            $regreso.= '<img alt="'.$documento.'" src="uploads/'.$documento.'" style="height:150px;width:200px;">
                            <br><button class="btn btn-warning" id="cambiar-doc" valor="uploads/'.$documento.'">Cambiar</button>
                            <input id="upload4" type="file" name="file" valor="'.$documento.'" style="display:none;"/>
                              <a class="btn btn-primary" href="uploads/'.$documento.'" rel="nofollow">Visualizar</a>';
                        } else {
                            $regreso.= '<form id="form4" action="tabla_popup.php" method="post" enctype="multipart/form-data">
						   <label class="btn btn-primary btn-file">
							 Seleccionar Nuevo...<input id="upload4" type="file" name="file" style="display:none;"/>
						  </label>
						 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload4" disabled>&nbsp;
					  </form> ';
                        }
					 $regreso.= ' </div>
                     <div class="col-md-2"></div>
                     <div class="col-md-10"><div id="file-status4"></div><div id="err4"></div></div>
				  <label class="col-md-2">Activo:</label>
				    <div class="col-md-3">
					  <select class="form-control" id="inp_activo_modal" required>
						  <option selected disabled value = "">Selecciona:</option>';
							  if($activo == 'Si'){
								  $regreso.= '<option value="Si" selected>Si</option>
											  <option value="No">No</option>';
							  } elseif($activo == 'No'){
								 $regreso.= '<option value="Si">Si</option>
											  <option value="No" selected>No</option>'; 
							  } else {
								  $regreso.= '<option value="Si">Si</option>
											  <option value="No">No</option>';
							  }
							$regreso.= '</select></div>';
    return $regreso;
}

function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.popup where Imagen like '%$busqueda%' or Documento like '%$busqueda%' or Activo like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
			$regreso = (isset($_POST['regreso']));
			
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_popup">
						 <thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Popup ID</p></th>
							<th class="col-md-2"><p align="center">Imagen</p></th>
							<th class="col-md-2"><p align="center">Documento</p></th>
							<th class="col-md-2"><p align="center">Activo</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
							<th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.= '</tr>
						</thead>
					  <tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);

                      $pooup_id = $fila['popup_id'];
					  $imagen = $fila['Imagen'];
				 	  $documento = $fila['Documento'];
					  $activo = $fila['Activo'];
					  $regreso.= '<tr>
								  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
								  <td style="vertical-align:middle;" align="left">'. $popup_id .'</td>                 
								  <td style="vertical-align:middle;" align="center"><img src="img/fotos/'.$imagen.'" alt="'.$imagen.'" style="height: 80px; width:80px;">'.$imagen.'</td>
								  <td style="vertical-align:middle;" align="center"><span class="glyphicon glyphicon-file"></span>'.$documento.'</td>
								  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                                  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.='
								  <td style="vertical-align:middle;" align="center"><button id="'.$popup_id.'" class="btn_modificar btn btn-success" accion="editpopup">Modificar</button></td>
							      <td style="vertical-align:middle;" align="center"><button id="'.$popup_id.'" class="btn_eliminar btn btn-danger" accion="delpopup">Eliminar</button></td>';
                                  }
                        $regreso.='</tr>';
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>
<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

$act = $_POST['act'];
if(isset($_POST['usuario'])) { $usuario = $_POST['usuario']; } 
if(isset($_POST['contrasena'])) { $contrasena = $_POST['contrasena']; }
  
if(isset($_POST['usua_id'])) { $usuarios_id = $_POST['usua_id']; }

   

switch($act){
  
    case 'tab':
         echo Tabla();
       // echo 'sdgahgdsahj';
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.usuarios set Usuario= '$usuario', Contrasena= '$contrasena' where usuarios_id = '$usuarios_id'");
		  echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
}

function Tabla(){
$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.usuarios");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_usuarios">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Usuarios ID</p></th>
							<th class="col-md-2"><p align="center">Usuario</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Email</p></th>
							<th class="col-md-1"><p align="center">Contrase&ntilde;a</p></th>
							<th class="col-md-2"><p align="center">Rol</p></th>
							<th class="col-md-2"><p align="center">Categoria</p></th>
							<th class="col-md-2"><p align="center">Activo</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>';
	 						}
						  $regreso.= '</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
				  $usuarios_id = $fila['usuarios_id'];
				  $usuario = $fila['Usuario'];
				  $nombre = $fila['Nombre'];
				  $email = $fila['Email'];
				  $contrasena = $fila['Contrasena'];
				  $rol = $fila['Rol'];
				  $categoria = $fila['Categoria'];
				  $activo = $fila['Activo'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $usuarios_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$usuario.'</td>
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center">'.$email.'</td>
						  <td style="vertical-align:middle;" align="left">'. $contrasena.'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$rol.'</td>
						  <td style="vertical-align:middle;" align="center">'.$categoria.'</td>
						  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                            
                           if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$usuarios_id.'" class="btn_modificar btn btn-success" accion="editusuarios">Modificar		                          </button></td>';
                          }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $usuarios_id = $_POST['usuarios_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.usuarios where usuarios_id= '$usuarios_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $usuarios_id = $fila['usuarios_id'];
    $usuario = $fila['Usuario'];
	$contrasena = $fila['Contrasena'];
        
    $regreso= '<label class="col-md-2">Usuario:</label>
				  <div class="col-md-4">
					  <input id="inp_usuario_modal" class="form-control" type="text" value= "'.$usuario.'">
				  </div>
				  <br><br><br>	  
				  <label class="col-md-2">Contrase&ntilde;a:</label>
				  <div class="col-md-4">
					  <input id="inp_contrasena_modal" class="form-control" type="password" value= "'.$contrasena.'">
				  </div>
      			</div>';
    return $regreso;
}
?>

<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Entrenador' ) {
      header('Location: Menu.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Pop up</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_popup.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
  	  var imagen_inp = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
	  var documento_inp = $('#upload3[type=file]').val().replace(/C:\\fakepath\\/i, '');
	  var activo_inp = $('#inp_activo option:selected').val();

	  var campos_insert = {imagen: imagen_inp, documento: documento_inp, activo: activo_inp, act: 'insert'};
      if(activo_inp == ""){
          swal({   
              type: "error",   
              title: "Error!", 
              text: "No se ha definido el campo 'Activo'",
          });
      }
      else{
          $.ajax({
              data : campos_insert,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
                swal({   
                      type: "success",   
                      title: "¡Se inserto correctamente!", 
                    });
                $('#div_pri').html(response);
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                  $("#form3")[0].reset();
                  $('#file-status3').html('No se ha seleccionado archivo').fadeIn();
                  $('#inp_activo').val('');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
          });
      }
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {popup_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
        var imagen_inp = $('#upload2').attr('valor');
	    var documento_inp = $('#upload4').attr('valor');
	    var activo_inp = $('#inp_activo_modal option:selected').val();
        
        var campos_modificar = {popup_id: id, imagen: imagen_inp, documento: documento_inp, activo: activo_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
                $('#div_pri').html(response);
				swal({   
                  type: "success",   
                  title: "¡Se actualizo la información con éxito!", 
                });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar el pop up con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {popup_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
				swal({   
                  type: "success",   
                  title: "¡Se elimino con éxito!", 
                });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
	var status= $('#upload').val();
	if(!status){
        $('#file-status').html('No se ha seleccionado archivo');    
    }
    
    $(document).on('change', '#upload', function(){
        var status= $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload').removeAttr('disabled');
        }
    });
    
   
    $(document).on('click','#file-upload',(function(e) {
        var formData= new FormData('#form');
        var path = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','insert-img');
        formData.append('foto', path);
        formData.append('file', $('#upload[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_popup.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				  swal({   
                  	type: "error",   
                  	title: "Archivo no valido! Intente de nuevo.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				   swal({   
                  	type: "error",   
                  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
				  $('#file-upload').attr('disabled','disabled');
                }
                else
                {
                  // view uploaded file.
				  swal({   
				  type: "success",   
				  title: "El archivo se cargo correctamente!", 
				  });
                }
              },
             error: function(e) 
              {
                $("#err").html(e);
              }          
        });
     }));
    
    $(document).on('change', '#upload2', function(){
        var status= $('#upload2[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status2').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload2').removeAttr('disabled');
        }
    });
    
    $(document).on('click','#file-upload2',(function(e) {
        var formData= new FormData(this);
        var path = $('#upload2[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','modificar-img');
        formData.append('foto', path);
        formData.append('file', $('#upload2[type=file]')[0].files[0]);
		
      e.preventDefault();
      $.ajax({
           url: "tabla_popup.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err2").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				   swal({   
					  type: "error",   
					  title: "Archivo no valido!, Intente de nuevo.", 
					});
                  $("#form2")[0].reset();
                  $('#file-status2').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				  swal({   
				  	type: "error",   
				  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
				  });
                  $("#form2")[0].reset();
                  $('#file-status2').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
				   swal({   
					  type: "success",   
					  title: "El archivo se cargo correctamente!", 
					});
                  $('#div-img').html(data);
                }
              },
             error: function(e) 
              {
                $("#err2").html(e);
              }          
        });
     }));
	 
    $(document).on('click','#cambiar-img', function(e) {
        var path = $('#cambiar-img').attr('valor');
        var info = {act: 'cambio-imagen', path: path };
        
        $.ajax({
              data : info,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
                $('#div-img').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
    
    var status= $('#upload3').val();
	if(!status){
        $('#file-status3').html('No se ha seleccionado archivo');    
    }
    
    $(document).on('change', '#upload3', function(){
        var status= $('#upload3[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status3').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload3').removeAttr('disabled');
        }
    });
    
   
    $(document).on('click','#file-upload3',(function(e) {
        var formData= new FormData('#form3');
        var path = $('#upload3[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','insert-doc');
        formData.append('foto', path);
        formData.append('file', $('#upload3[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_popup.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				  swal({   
                  	type: "error",   
                  	title: "Archivo no valido! Intente de nuevo.", 
                  });
                  $("#form3")[0].reset();
                  $('#file-status3').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				   swal({   
                  	type: "error",   
                  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
                  });
                  $("#form3")[0].reset();
                  $('#file-status3').html('No se ha seleccionado archivo').fadeIn();
				  $('#file-upload3').attr('disabled','disabled');
                }
                else
                {
                  // view uploaded file.
				  swal({   
				  type: "success",   
				  title: "El archivo se cargo correctamente!", 
				  });
                }
              },
             error: function(e) 
              {
                $("#err").html(e);
              }          
        });
     }));
    
    $(document).on('change', '#upload4', function(){
        var status= $('#upload4[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status4').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload4').removeAttr('disabled');
        }
    });
    
    $(document).on('click','#file-upload4',(function(e) {
        var formData= new FormData(this);
        var path = $('#upload4[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','modificar-doc');
        formData.append('doc', path);
        formData.append('file', $('#upload4[type=file]')[0].files[0]);
		
      e.preventDefault();
      $.ajax({
           url: "tabla_popup.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err4").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				   swal({   
					  type: "error",   
					  title: "Archivo no valido!, Intente de nuevo.", 
					});
                  $("#form4")[0].reset();
                  $('#file-status4').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				  swal({   
				  	type: "error",   
				  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
				  });
                  $("#form4")[0].reset();
                  $('#file-status4').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
				   swal({   
					  type: "success",   
					  title: "El archivo se cargo correctamente!", 
					});
                  $('#div-doc').html(data);
                }
              },
             error: function(e) 
              {
                $("#err4").html(e);
              }          
        });
     }));
	 
    $(document).on('click','#cambiar-doc', function(e) {
        var path = $('#cambiar-doc').attr('valor');
        var info = {act: 'cambio-doc', path: path };
        
        $.ajax({
              data : info,
              type : 'POST',
              url : 'tabla_popup.php',

              success: function(response){
                $('#div-doc').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_popup{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-picture"></span>&nbsp; Pop up</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600"> 
	<div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
	</div>
	<div class="form-group row">
	   <?php 
         if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
            echo '<label class="col-md-2">Imagen:</label>
			<div class="col-md-3">
			  <form id="form" action="tabla_popup.php" method="post" enctype="multipart/form-data">
				   <label class="btn btn-primary btn-file">
					 Seleccionar Nuevo...<input id="upload" type="file" name="file" style="display:none;"/>
				  </label>
				 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload" disabled>
			  </form>
			  <div id="file-status"></div><div id="err"></div>
      </div>	
    </div>
	<div class="row">
	  <div class="col-md-2"></div>
		<div class="col-md-3">
			<div id="file-status"></div><div id="err"></div>
      </div>
    </div>
	<div class="form-group row">
	  <label class="col-md-2">Documento:</label>
	  	<div class="col-md-3">
		  <form id="form3" action="tabla_popup.php" method="post" enctype="multipart/form-data">
			   <label class="btn btn-primary btn-file">
				 Seleccionar Nuevo...<input id="upload3" type="file" name="file3" style="display:none;"/>
			  </label>
			 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload3" disabled>
		  </form>
		 </div> 
	</div>
	<div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-3">
        <div id="file-status3"></div><div id="err3"></div>
    </div>
  </div>
	<div class="form-grup row">
       <label class="col-sm-2">Activo:</label>
	   <div class="col-sm-3">
	            <select class="form-control" id="inp_activo" style="width:122px" required>
                  <option selected disabled value="">Selecciona</option>
                  <option value="Si">Si</option>
                  <option value="No">No</option>
               </select>           
		</div>
	</div>	   
    <div align="center">
		<button class="btn btn-primary" id="btn_nuevo">Nuevo documento/imagen</button>
    </div>'; } ?> <br>
  <div class="form-group row">
    <label class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar pop up</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar pop up</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
<?php
session_start();    
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['nombre'])) { $nombre = $_POST['nombre']; }
if(isset($_POST['apellidos'])){ $apellidos = $_POST['apellidos']; }
if(isset($_POST['ano'])) { $ano = $_POST['ano']; }
if(isset($_POST['grado'])) { $grado = $_POST['grado']; }
if(isset($_POST['uno'])) { $uno = $_POST['uno']; }
if(isset($_POST['dos'])) { $dos = $_POST['dos']; }
if(isset($_POST['tres'])) { $tres = $_POST['tres']; }
if(isset($_POST['cuatro'])) { $cuatro = $_POST['cuatro']; }
if(isset($_POST['cinco'])) { $cinco = $_POST['cinco']; }
if(isset($_POST['seis'])) { $seis = $_POST['seis']; }
if(isset($_POST['siete'])) { $siete = $_POST['siete']; } 
if(isset($_POST['ocho'])) { $ocho = $_POST['ocho']; }
if(isset($_POST['nueve'])) { $nueve = $_POST['nueve']; }
if(isset($_POST['diez'])) { $diez = $_POST['diez']; }
if(isset($_POST['once'])) { $once = $_POST['once']; }
if(isset($_POST['doce'])) { $doce = $_POST['doce']; }
if(isset($_POST['trece'])) { $trece = $_POST['trece']; }
if(isset($_POST['catorce'])) { $catorce = $_POST['catorce']; }
if(isset($_POST['quince'])) { $quince = $_POST['quince']; }
if(isset($_POST['diezyseis'])) { $diezyseis = $_POST['diezyseis']; }
if(isset($_POST['diezysiete'])) { $diezysiete = $_POST['diezysiete']; }
if(isset($_POST['diezyocho'])) { $diezyocho = $_POST['diezyocho']; }
if(isset($_POST['diezynueve'])) { $diezynueve = $_POST['diezynueve']; }
if(isset($_POST['veinte'])) { $veinte = $_POST['veinte']; } 
if(isset($_POST['veinteyuno'])) { $veinteyuno = $_POST['veinteyuno']; }
if(isset($_POST['veinteydos'])) { $veinteydos = $_POST['veinteydos']; }
if(isset($_POST['veinteytres'])) { $veinteytres = $_POST['veinteytres']; }
if(isset($_POST['veinteycuatro'])) { $veinteycuatro = $_POST['veinteycuatro']; }
if(isset($_POST['veinteycinco'])) { $veinteycinco = $_POST['veinteycinco']; }
if(isset($_POST['veinteyseis'])) { $veinteyseis = $_POST['veinteyseis']; }
if(isset($_POST['veinteysiete'])) { $veinteysiete = $_POST['veinteysiete']; }
if(isset($_POST['veinteyocho'])) { $veinteyocho = $_POST['veinteyocho']; }
if(isset($_POST['veinteynueve'])) { $veinteynueve = $_POST['veinteynueve']; }
if(isset($_POST['treinta'])) { $treinta = $_POST['treinta']; }
if(isset($_POST['treintayuno'])) { $treintayuno = $_POST['treintayuno']; }
if(isset($_POST['lista_id'])) { $lista_id = $_POST['lista_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.lista (Nombre,Apellido,Ano,Grado,Uno,Dos,Tres,Cuatro,Cinco,Seis,Siete,Ocho,Nueve,Diez,Once,Doce,Trece,Catorce,Quince,Diezyseis, Diezysiete,Diezyocho,Diezynueve,Veinte,Veinteyuno,Veinteydos,Veinteytres,Veinteycuatro,Veinteycinco,Veinteyseis,Veinteysiete,Veinteyocho,Veinteynueve,Treinta,Treintayuno) values('$nombre','$apellidos','$ano','$grado','$uno','$dos','$tres','$cuatro','$cinco','$seis','$siete','$ocho','$nueve','$diez','$once','$doce','$trece','$catorce','$quince', '$diezyseis','$diezysiete','$diezyocho','$diezynueve','$veinte','$veinteyuno','$veinteydos','$veinteytres','$veinteycuatro','$veinteycinco','$veinteyseis','$veinteysiete','$veinteyocho','$veinteynueve','$treinta','$treintayuno')");
          echo Tabla();
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.lista set Nombre= '$nombre', Apellido= '$apellidos', Ano= '$ano', Grado= '$grado', Uno= '$uno', Dos= '$dos', Tres= '$tres', Cuatro= '$cuatro', Cinco= '$cinco', Seis= '$seis', Siete= '$siete', Ocho= '$ocho', Nueve= '$nueve', Diez= '$diez', Once= '$once', Doce= '$doce', Trece= '$trece', Catorce= '$catorce', Quince= '$quince', Diezyseis= '$diezyseis', Diezysiete= '$diezysiete', Diezyocho= '$diezyocho', Diezynueve= '$diezynueve', Veinte= '$veinte', Veinteyuno= '$veinteyuno', Veinteydos= '$veinteydos', Veinteytres= '$veinteytres', Veinteycuatro= '$veinteycuatro', Veinteycinco= '$veinteycinco', Veinteyseis= '$veinteyseis', Veinteysiete= '$veinteysiete', Veinteyocho= '$veinteyocho', Veinteynueve= '$veinteynueve', Treinta= '$treinta',  Treintayuno= '$treintayuno' where lista_id = '$lista_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.lista where lista_id= '$lista_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}
function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.lista");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_lista">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Lista ID</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Apellidos</p></th>
							<th class="col-md-2"><p align="center">Ano</p></th>
							<th class="col-md-2"><p align="center">Grado</p></th>
							<th class="col-md-2"><p align="center">1</p></th>
							<th class="col-md-2"><p align="center">2</p></th>
							<th class="col-md-2"><p align="center">3</p></th>
							<th class="col-md-2"><p align="center">4</p></th>
							<th class="col-md-2"><p align="center">5</p></th>
							<th class="col-md-2"><p align="center">6</p></th>
							<th class="col-md-2"><p align="center">7</p></th>
							<th class="col-md-2"><p align="center">8</p></th>
							<th class="col-md-2"><p align="center">9</p></th>
							<th class="col-md-2"><p align="center">10</p></th>
							<th class="col-md-2"><p align="center">11</p></th>
							<th class="col-md-2"><p align="center">12</p></th>
							<th class="col-md-2"><p align="center">13</p></th>
							<th class="col-md-2"><p align="center">14</p></th>
							<th class="col-md-2"><p align="center">15</p></th>
							<th class="col-md-2"><p align="center">16</p></th>
							<th class="col-md-2"><p align="center">17</p></th>
							<th class="col-md-2"><p align="center">18</p></th>
							<th class="col-md-2"><p align="center">19</p></th>
							<th class="col-md-2"><p align="center">20</p></th>
							<th class="col-md-2"><p align="center">21</p></th>
							<th class="col-md-2"><p align="center">22</p></th>
							<th class="col-md-2"><p align="center">23</p></th>
							<th class="col-md-2"><p align="center">24</p></th>
							<th class="col-md-2"><p align="center">25</p></th>
							<th class="col-md-2"><p align="center">26</p></th>
							<th class="col-md-2"><p align="center">27</p></th>
							<th class="col-md-2"><p align="center">28</p></th>
							<th class="col-md-2"><p align="center">29</p></th>
							<th class="col-md-2"><p align="center">30</p></th>
							<th class="col-md-2"><p align="center">31</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
							<th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.= '</tr>
					</thead>
			<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
				  $lista_id = $fila['lista_id'];
				  $nombre = $fila['Nombre'];
				  $apellidos = $fila['Apellido'];
				  $ano = $fila['Ano'];
				  $grado = $fila['Grado'];
				  $uno = $fila['Uno'];
				  $dos = $fila['Dos'];
				  $tres = $fila['Tres'];
				  $cuatro = $fila['Cuatro'];
				  $cinco = $fila['Cinco'];
				  $seis = $fila['Seis'];
				  $siete = $fila['Siete'];
				  $ocho = $fila['Ocho'];
				  $nueve = $fila['Nueve'];
				  $diez = $fila['Diez'];
				  $once = $fila['Once'];
				  $doce = $fila['Doce'];
				  $trece = $fila['Trece'];
				  $catorce = $fila['Catorce'];
				  $quince = $fila['Quince'];
				  $diezyseis = $fila['Diezyseis'];
				  $diezysiete = $fila['Diezysiete'];
				  $diezyocho = $fila['Diezyocho'];
				  $diezynueve = $fila['Diezynueve'];
				  $veinte = $fila['Veinte'];
				  $veinteyuno = $fila['Veinteyuno'];
				  $veinteydos = $fila['Veinteydos'];
				  $veinteytres = $fila['Veinteytres'];
				  $veinteycuatro = $fila['Veinteycuatro'];
				  $veinteycinco = $fila['Veinteycinco'];
				  $veinteyseis = $fila['Veinteyseis'];
				  $veinteysiete = $fila['Veinteysiete'];
				  $veinteyocho = $fila['Veinteyocho'];
				  $veinteynueve = $fila['Veinteynueve'];
				  $treinta = $fila['Treinta'];
				  $treintayuno = $fila['Treintayuno'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $lista_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center">'.$apellidos.'</td>
						  <td style="vertical-align:middle;" align="center">'.$ano.'</td>
						  <td style="vertical-align:middle;" align="center">'.$grado.'</td>
						  <td style="vertical-align:middle;" align="center">'.$uno.'</td>
						  <td style="vertical-align:middle;" align="center">'.$dos.'</td>
						  <td style="vertical-align:middle;" align="center">'.$tres.'</td>
						  <td style="vertical-align:middle;" align="center">'.$cuatro.'</td>
						  <td style="vertical-align:middle;" align="center">'.$cinco.'</td>
						  <td style="vertical-align:middle;" align="center">'.$seis.'</td>
						  <td style="vertical-align:middle;" align="center">'.$siete.'</td>
						  <td style="vertical-align:middle;" align="center">'.$ocho.'</td>
						  <td style="vertical-align:middle;" align="center">'.$nueve.'</td>
						  <td style="vertical-align:middle;" align="center">'.$diez.'</td>
						  <td style="vertical-align:middle;" align="center">'.$once.'</td>
						  <td style="vertical-align:middle;" align="center">'.$doce.'</td>
						  <td style="vertical-align:middle;" align="center">'.$trece.'</td>
						  <td style="vertical-align:middle;" align="center">'.$catorce.'</td>
						  <td style="vertical-align:middle;" align="center">'.$quince.'</td>
						  <td style="vertical-align:middle;" align="center">'.$diezyseis.'</td>
						  <td style="vertical-align:middle;" align="center">'.$diezysiete.'</td>
						  <td style="vertical-align:middle;" align="center">'.$diezyocho.'</td>
						  <td style="vertical-align:middle;" align="center">'.$diezynueve.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteyuno.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteydos.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteytres.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteycuatro.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteycinco.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteyseis.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteysiete.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteyocho.'</td>
						  <td style="vertical-align:middle;" align="center">'.$veinteynueve.'</td>
						  <td style="vertical-align:middle;" align="center">'.$treinta.'</td>
						  <td style="vertical-align:middle;" align="center">'.$treintayuno.'</td>';
						  if($_SESSION['usua_rol'] != 'Asistente') {
                              $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$lista_id.'" class="btn_modificar btn btn-success" accion="editlista">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$lista_id.'" class="btn_eliminar btn btn-danger" accion="dellista">Eliminar                          </button></td>';
                          }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $lista_id = $_POST['lista_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.lista where lista_id= '$lista_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $lista_id = $fila['lista_id'];
    $nombre = $fila['Nombre'];
    $apellidos = $fila['Apellido'];
    $ano = $fila['Ano'];
    $grado = $fila['Grado'];
    $uno = $fila['Uno'];
    $dos = $fila['Dos'];
    $tres = $fila['Tres'];
    $cuatro = $fila['Cuatro'];
    $cinco = $fila['Cinco'];
    $seis = $fila['Seis'];
    $siete = $fila['Siete'];
    $ocho = $fila['Ocho'];
    $nueve = $fila['Nueve'];
    $diez = $fila['Diez'];
    $once = $fila['Once'];
    $doce = $fila['Doce'];
    $trece = $fila['Trece'];
    $catorce = $fila['Catorce'];
    $quince = $fila['Quince'];
    $diezyseis = $fila['Diezyseis'];
    $diezysiete = $fila['Diezysiete'];
    $diezyocho = $fila['Diezyocho'];
    $diezynueve = $fila['Diezynueve'];
    $veinte = $fila['Veinte'];
    $veinteyuno = $fila['Veinteyuno'];
    $veinteydos = $fila['Veinteydos'];
    $veinteytres = $fila['Veinteytres'];
    $veinteycuatro = $fila['Veinteycuatro'];
    $veinteycinco = $fila['Veinteycinco'];
    $veinteyseis = $fila['Veinteyseis'];
    $veinteysiete = $fila['Veinteysiete'];
    $veinteyocho = $fila['Veinteyocho'];
    $veinteynueve = $fila['Veinteynueve'];
    $treinta = $fila['Treinta'];
    $treintayuno = $fila['Treintayuno'];
        
    $regreso.= '<label class="col-md-2">Nombre(s):</label>
				  <div class="col-md-3">
					  <input id="inp_nombre_modal" class="form-control" type="text" value= "'.$nombre.'">
				  </div>
				  <label class="col-md-2">Apellidos:</label>
				  <div class="col-md-4">
					  <input id="inp_apellidos_modal" class="form-control" type="text" value= "'.$apellidos.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">A&ntilde;o:</label>
				  <div class="col-md-3">
					  <input id="inp_ano_modal" class="form-control" type="text" value= "'.$ano.'">
				  </div>  
				  <label class="col-md-2">Grado:</label>
				  <div class="col-md-2">
					  <input id="inp_grado_modal" class="form-control" type="text" value= "'.$grado.'" >
				  </div>
				  <br><br><br>
				  <label class="col-md-1">1</label>
				  <div class="col-md-2">
					  <input id="inp_uno_modal" class="form-control" type="text" value= "'.$uno.'">
				  </div> 
				  <label class="col-md-1">2</label>
				  <div class="col-md-2">
					  <input id="inp_dos_modal" class="form-control" type="text" value= "'.$dos.'" >
				  </div> 
				  <label class="col-md-1">3</label>
				  <div class="col-md-2">
					  <input id="inp_tres_modal" class="form-control" type="text" value= "'.$tres.'">
				  </div>
				  <label class="col-md-1">4</label>
				  <div class="col-md-2">
					  <input id="inp_cuatro_modal" class="form-control" type="text" value= "'.$cuatro.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-1">5</label>
				  <div class="col-md-2">
					  <input id="inp_cinco_modal" class="form-control" type="text" value= "'.$cinco.'" >
				  </div>   
				  <label class="col-md-1">6</label>
				  <div class="col-md-2">
					  <input id="inp_seis_modal" class="form-control" type="text" value= "'.$seis.'">
				  </div> 
				  <label class="col-md-1">7</label>
				  <div class="col-md-2">
					  <input id="inp_siete_modal" class="form-control" type="text" value= "'.$siete.'">
				  </div>
				  <label class="col-md-1">8</label>
				  <div class="col-md-2">
					  <input id="inp_ocho_modal" class="form-control" type="text" value= "'.$ocho.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-1">9</label>
				  <div class="col-md-2">
					  <input id="inp_nueve_modal" class="form-control" type="text" value= "'.$nueve.'" >
				  </div>
				  <label class="col-md-1">10</label>
				  <div class="col-md-2">
					  <input id="inp_diez_modal" class="form-control" type="text" value= "'.$diez.'" >
				  </div>
				  <label class="col-md-1">11</label>
				  <div class="col-md-2">
					  <input id="inp_once_modal" class="form-control" type="text" value= "'.$once.'">
				  </div>  
				  <label class="col-md-1">12</label>
				  <div class="col-md-2">
					  <input id="inp_doce_modal" class="form-control" type="text" value= "'.$doce.'">
				  </div>
				  <br><br><br>
				   <label class="col-md-1">13</label>
				  <div class="col-md-2">
					  <input id="inp_trece_modal" class="form-control" type="text" value= "'.$trece.'">
				  </div> 
				  <label class="col-md-1">14</label>
				  <div class="col-md-2">
					  <input id="inp_catorce_modal" class="form-control" type="text" value= "'.$catorce.'">
				  </div>
				  <label class="col-md-1">15</label>
				  <div class="col-md-2">
					  <input id="inp_quince_modal" class="form-control" type="text" value= "'.$quince.'">
				  </div>
				  <label class="col-md-1">16</label>
				  <div class="col-md-2">
					  <input id="inp_diezyseis_modal" class="form-control" type="text" value= "'.$diezyseis.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-1">17</label>
				  <div class="col-md-2">
					  <input id="inp_diezysiete_modal" class="form-control" type="text" value= "'.$diezysiete.'" >
				  </div>   
				  <label class="col-md-1">18</label>
				  <div class="col-md-2">
					  <input id="inp_diezyocho_modal" class="form-control" type="text" value= "'.$diezyocho.'">
				  </div>
				  <label class="col-md-1">19</label>
				  <div class="col-md-2">
					  <input id="inp_diezynueve_modal" class="form-control" type="text" value= "'.$diezynueve.'">
				  </div> 
				  <label class="col-md-1">20</label>
				  <div class="col-md-2">
					  <input id="inp_veinte_modal" class="form-control" type="text" value= "'.$veinte.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-1">21</label>
				  <div class="col-md-2">
					  <input id="inp_veinteyuno_modal" class="form-control" type="text" value= "'.$veinteyuno.'" >
				  </div> 
				  <label class="col-md-1">22</label>
				  <div class="col-md-2">
					  <input id="inp_veinteydos_modal" class="form-control" type="text" value= "'.$veinteydos.'">
				  </div> 
				  <label class="col-md-1">23</label>
				  <div class="col-md-2">
					  <input id="inp_veinteytres_modal" class="form-control" type="text" value= "'.$veinteytres.'">
				  </div>
				  <label class="col-md-1">24</label>
				  <div class="col-md-2">
					  <input id="inp_veinteycuatro_modal" class="form-control" type="text" value= "'.$veinteycuatro.'">
				  </div>  
				  <br><br><br>
				  <label class="col-md-1">25</label>
				  <div class="col-md-2">
					  <input id="inp_veinteycinco_modal" class="form-control" type="text" value= "'.$veinteycinco.'">
				  </div>
				  <label class="col-md-1">26</label>
				  <div class="col-md-2">
					  <input id="inp_veinteyseis_modal" class="form-control" type="text" value= "'.$veinteyseis.'">
				  </div> 
				  <label class="col-md-1">27</label>
				  <div class="col-md-2">
					  <input id="inp_veinteysiete_modal" class="form-control" type="text" value= "'.$veinteysiete.'">
				  </div> 
				  <label class="col-md-1">28</label>
				  <div class="col-md-2">
					  <input id="inp_veinteyocho_modal" class="form-control" type="text" value= "'.$veinteyocho.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-1">29</label>
				  <div class="col-md-2">
					  <input id="inp_veinteynueve_modal" class="form-control" type="text" value= "'.$veinteynueve.'">
				  </div> 
				  <label class="col-md-1">30</label>
				  <div class="col-md-2">
					  <input id="inp_treinta_modal" class="form-control" type="text" value= "'.$treinta.'">
				  </div> 
				  <label class="col-md-1">31</label>
				  <div class="col-md-2">
					  <input id="inp_treintayuno_modal" class="form-control" type="text" value= "'.$treintayuno.'">
				  </div>';
    return $regreso;
}
function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.lista where Nombre like '%$busqueda%' or Apellido like '%$busqueda%' or Ano like '%$busqueda%' 
	or Grado like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
			$regreso = (isset($_POST['regreso']));
			
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_lista">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Lista ID</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Apellidos</p></th>
							<th class="col-md-2"><p align="center">Ano</p></th>
							<th class="col-md-2"><p align="center">Grado</p></th>
							<th class="col-md-2"><p align="center">1</p></th>
							<th class="col-md-2"><p align="center">2</p></th>
							<th class="col-md-2"><p align="center">3</p></th>
							<th class="col-md-2"><p align="center">4</p></th>
							<th class="col-md-2"><p align="center">5</p></th>
							<th class="col-md-2"><p align="center">6</p></th>
							<th class="col-md-2"><p align="center">7</p></th>
							<th class="col-md-2"><p align="center">8</p></th>
							<th class="col-md-2"><p align="center">9</p></th>
							<th class="col-md-2"><p align="center">10</p></th>
							<th class="col-md-2"><p align="center">11</p></th>
							<th class="col-md-2"><p align="center">12</p></th>
							<th class="col-md-2"><p align="center">13</p></th>
							<th class="col-md-2"><p align="center">14</p></th>
							<th class="col-md-2"><p align="center">15</p></th>
							<th class="col-md-2"><p align="center">16</p></th>
							<th class="col-md-2"><p align="center">17</p></th>
							<th class="col-md-2"><p align="center">18</p></th>
							<th class="col-md-2"><p align="center">19</p></th>
							<th class="col-md-2"><p align="center">20</p></th>
							<th class="col-md-2"><p align="center">21</p></th>
							<th class="col-md-2"><p align="center">22</p></th>
							<th class="col-md-2"><p align="center">23</p></th>
							<th class="col-md-2"><p align="center">24</p></th>
							<th class="col-md-2"><p align="center">25</p></th>
							<th class="col-md-2"><p align="center">26</p></th>
							<th class="col-md-2"><p align="center">27</p></th>
							<th class="col-md-2"><p align="center">28</p></th>
							<th class="col-md-2"><p align="center">29</p></th>
							<th class="col-md-2"><p align="center">30</p></th>
							<th class="col-md-2"><p align="center">31</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }
						  $regreso.='</tr>
						</thead>
					<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);
                      $lista_id = $fila['lista_id'];
				  	  $nombre = $fila['Nombre'];
				  	  $apellidos = $fila['Apellido'];
				  	  $ano = $fila['Ano'];
				  	  $grado = $fila['Grado'];
				  	  $uno = $fila['Uno'];
				  	  $dos = $fila['Dos'];
				  	  $tres = $fila['Tres'];
				  	  $cuatro = $fila['Cuatro'];
				  	  $cinco = $fila['Cinco'];
				  	  $seis = $fila['Seis'];
				  	  $siete = $fila['Siete'];
				  	  $ocho = $fila['Ocho'];
				  	  $nueve = $fila['Nueve'];
				  	  $diez = $fila['Diez'];
				  	  $once = $fila['Once'];
				  	  $doce = $fila['Doce'];
				  	  $trece = $fila['Trece'];
				  	  $catorce = $fila['Catorce'];
				  	  $quince = $fila['Quince'];
				  	  $diezyseis = $fila['Diezyseis'];
				  	  $diezysiete = $fila['Diezysiete'];
				  	  $diezyocho = $fila['Diezyocho'];
				  	  $diezynueve = $fila['Diezynueve'];
				  	  $veinte = $fila['Veinte'];
				  	  $veinteyuno = $fila['Veinteyuno'];
				  	  $veinteydos = $fila['Veinteydos'];
				  	  $veinteytres = $fila['Veinteytres'];
				  	  $veinteycuatro = $fila['Veinteycuatro'];
				  	  $veinteycinco = $fila['Veinteycinco'];
				  	  $veinteyseis = $fila['Veinteyseis'];
				  	  $veinteysiete = $fila['Veinteysiete'];
				  	  $veinteyocho = $fila['Veinteyocho'];
				  	  $veinteynueve = $fila['Veinteynueve'];
				  	  $treinta = $fila['Treinta'];
				  	  $treintayuno = $fila['Treintayuno'];
				  	  $regreso.= '<tr>
								  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
								  <td style="vertical-align:middle;" align="left">'. $lista_id .'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
								  <td style="vertical-align:middle;" align="center">'.$apellidos.'</td>
								  <td style="vertical-align:middle;" align="center">'.$ano.'</td>
								  <td style="vertical-align:middle;" align="center">'.$grado.'</td>
								  <td style="vertical-align:middle;" align="center">'.$uno.'</td>
								  <td style="vertical-align:middle;" align="center">'.$dos.'</td>
								  <td style="vertical-align:middle;" align="center">'.$tres.'</td>
								  <td style="vertical-align:middle;" align="center">'.$cuatro.'</td>
								  <td style="vertical-align:middle;" align="center">'.$cinco.'</td>
								  <td style="vertical-align:middle;" align="center">'.$seis.'</td>
								  <td style="vertical-align:middle;" align="center">'.$siete.'</td>
								  <td style="vertical-align:middle;" align="center">'.$ocho.'</td>
								  <td style="vertical-align:middle;" align="center">'.$nueve.'</td>
								  <td style="vertical-align:middle;" align="center">'.$diez.'</td>
								  <td style="vertical-align:middle;" align="center">'.$once.'</td>
								  <td style="vertical-align:middle;" align="center">'.$doce.'</td>
								  <td style="vertical-align:middle;" align="center">'.$trece.'</td>
								  <td style="vertical-align:middle;" align="center">'.$catorce.'</td>
								  <td style="vertical-align:middle;" align="center">'.$quince.'</td>
								  <td style="vertical-align:middle;" align="center">'.$diezyseis.'</td>
								  <td style="vertical-align:middle;" align="center">'.$diezysiete.'</td>
								  <td style="vertical-align:middle;" align="center">'.$diezyocho.'</td>
								  <td style="vertical-align:middle;" align="center">'.$diezynueve.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinte.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteyuno.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteydos.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteytres.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteycuatro.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteycinco.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteyseis.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteysiete.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteyocho.'</td>
								  <td style="vertical-align:middle;" align="center">'.$veinteynueve.'</td>
								  <td style="vertical-align:middle;" align="center">'.$treinta.'</td>
								  <td style="vertical-align:middle;" align="center">'.$treintayuno.'</td>';
								  if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$lista_id.'" class="btn_modificar btn btn-success" accion="editlista">Modificar		                          </button></td>
								  <td style="vertical-align:middle;" align="center"><button id="'.$lista_id.'" class="btn_eliminar btn btn-danger" accion="dellista">Eliminar                          </button></td>
							</tr>';  
                                }
						$regreso.='</tr>';
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>
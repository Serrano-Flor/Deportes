<?php
  include("conecta.php");
  session_start();
  if(!$_SESSION['iniciada'])
  {
      header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Entrenador' || $_SESSION['usua_rol'] == 'Visitante') {
      header('Location: Menu.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-multiselect.js"></script>
<link rel="stylesheet" href="css/bootstrap-multiselect.css" type="text/css"/>
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Usuarios</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{
  var categoria_selected= []; 
  $('#inp_categoria').multiselect({
      nonSelectedText: 'Nada seleccionado',
    onChange: function(element, checked) {
        var brands = $('#inp_categoria option:selected');
        categoria_selected= [];
        $(brands).each(function(index, brand){
            categoria_selected.push([$(this).val()]);
        });
    }
  });
    
  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_usuarios.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
	  var usuario_inp = $('#inp_usuario').val();
	  var nombre_inp = $('#inp_nombre').val();
	  var email_inp = $('#inp_email').val();
	  var contrasena_inp = $('#inp_contrasena').val();
	  var rol_inp = $('#inp_rol option:selected').val();
	  var categoria_inp = categoria_selected.toString();
	  var activo_inp = $('#inp_activo option:selected').val();
      
      
	  var campos_insert = {usuario: usuario_inp, nombre: nombre_inp, email: email_inp, contrasena: contrasena_inp, rol: rol_inp, categoria: categoria_inp, activo: activo_inp,
	  act: 'insert'};
     
      if(activo_inp == "" || categoria_inp == "" || rol_inp== ""){
          swal({   
              type: "error",   
              title: "Error!", 
              text: "No se ha definido el campo 'Activo' o 'Categoria' o 'Rol'",
          });
      }
      else{
          $.ajax({
              data : campos_insert,
              type : 'POST',
              url : 'tabla_usuarios.php',

              success: function(response){
                swal({   
                    type: "success",   
                    title: "Se inserto correctamente!", 
                });
                $('#div_pri').html(response);
                $('#inp_usuario').val('');
	            $('#inp_nombre').val('');
	            $('#inp_email').val('');
	            $('#inp_contrasena').val('');
	            $('#inp_rol').val('');
	            $('#inp_categoria').val('');
	            $('#inp_activo').val('');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
          });
      }
	  
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {usuarios_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_usuarios.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
        var usuario_inp = $('#inp_usuario_modal').val();
	    var nombre_inp = $('#inp_nombre_modal').val();
	    var email_inp = $('#inp_email_modal').val();
	    var contrasena_inp = $('#inp_contrasena_modal').val();
	    var rol_inp = $('#inp_rol_modal option:selected').val();
	    var categoria_inp = $('#inp_categoria_modal option:selected').val();
	    var activo_inp = $('#inp_activo_modal option:selected').val();
        
        var campos_modificar = {usuarios_id: id, usuario: usuario_inp, nombre: nombre_inp, email: email_inp, contrasena: contrasena_inp, rol: rol_inp, 
		categoria: categoria_inp, activo: activo_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_usuarios.php',

              success: function(response){
                $('#div_pri').html(response);
                swal({   
                    type: "success",   
                    title: "¡Se actualizo la información con éxito!", 
                });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar la planeación con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {usuarios_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_usuarios.php',

              success: function(response){
                swal({   
                    type: "success",   
                    title: "Se elimino con éxito!", 
                });  
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
                $('#inp_usuario').val('');
	            $('#inp_nombre').val('');
	            $('#inp_email').val('');
	            $('#inp_contrasena').val('');
	            $('#inp_rol').val('');
	            $('#inp_categoria').val('');
	            $('#inp_activo').val('');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_usuarios.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
    
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar {
		width: 40px;
		height: 40px;
     }
		
     body {
        color: #100719;
     }
		
     #tabla_usuarios {
	   font-size: 14;
	   font-style: arial;
     }
	
     .Contenedor img {
	   width: 100%; 
       position: relative;
     }	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-user"></span>&nbsp; Usuarios</h1>	

<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  	<br>
  <div class="form-group row">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente') {
	echo '<label class="col-md-1">Usuario:</label>
	  <div class="col-md-3">
		  <input id="inp_usuario" class="form-control" type="text" placeholder="Nombre de usuario">
	  </div>
	  <label class="col-md-1">Nombre:</label>
	  <div class="col-md-3">
		  <input id="inp_nombre" class="form-control" type="text" placeholder="Nombre completo">
	  </div>
	  <label class="col-md-1">E-mail:</label>
	  <div class="col-md-3">
		  <input id="inp_email" class="form-control" type="text" placeholder="Nombre@gmail.com">
	  </div>
  </div>	  
  <div class="form-group row"> 
	  <label class="col-md-1">Contrase&ntilde;a:</label>
	  <div class="col-md-3">
		  <input id="inp_contrasena" class="form-control" type="password">
	  </div>
	  <label class="col-md-1">Rol:</label>
	  <div class="col-md-3">
	    <select class="form-control" id="inp_rol" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Administrador">Administrador</option>
		  <option value="Entrenador">Entrenador</option>
          <option value="Asistente">Asistente</option>
          <option value="Visitante">Visitante</option>
		</select>
	  </div>
      <div class="form-group">	  
	  <label class="col-md-1">Categoria:</label>
	  <div class="col-md-3">
		<select class="form-control" id="inp_categoria"  multiple="multiple" required>
		  <optgroup label="F&uacute;tbol">
		  <option value="Biberones">Biberones</option>
		  <option value="Dientes de leche">Dientes de leche</option>
          <option value="Asqueles">Asqueles</option>
          <option value="Convivencia">Convivencia</option>
		  <option value="Juvenil A">Juvenil A</option>
		  <option value="Juvenil B">Juvenil B</option>
          <option value="Juvenil C">Juvenil C</option>
          <option value="Infantil Menor">Infantil Menor</option>
		  <option value="Infantil Mayor">Infantil Mayor</option>
		  <option value="Infantil Menor">Infantil Menor</option>
          <option value="Infantil Mayor">Infantil Mayor</option>
          </optgroup>
		  <!-----Basquetbol--->
          <option value="BabyBasquet">BabyBasquet</option>
		  <option value="Promocional">Promocional</option>
		  <option value="Minibasquet">Minibasquet</option>
          <option value="Pasarela">Pasarela</option>
          <option value="Cadetes">Cadetes</option>
		  <option value="Elite">Elite</option>
		  <!-----Voleibol--->
		  <option value="Primaria">Primaria</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		  <!-----Atletismo--->
           <option value="Primaria">Primaria</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		</select>
	</div>
   </div>
  </div>
  <div class="form-group row">	  
	  <label class="col-md-1">Activo:</label>
	  <div class="col-md-3">
		<select class="form-control" id="inp_activo" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Si">Si</option>
		  <option value="No">No</option>
		</select>
	</div>
   </div>
  <div align="center">
  	 <button class="btn btn-primary" id="btn_nuevo">Nueva asistencia</button>
  </div>'; } ?>
  <br>
  <div class="form-group row">
    <label class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar usuario</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar usuario</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
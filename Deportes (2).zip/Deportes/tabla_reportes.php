<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['deporte'])) { $deporte = $_POST['deporte']; }
if(isset($_POST['equipo'])) { $equipo = $_POST['equipo']; }
if(isset($_POST['rama'])) { $rama = $_POST['rama']; }
if(isset($_POST['reportes_id'])) { $reportes_id = $_POST['reportes_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.reportes (Deporte, Equipo, Rama) values('$deporte','$equipo','$rama')");
          echo Tabla();
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.reportes set Deporte= '$deporte', Equipo= '$equipo', Rama= '$rama' where reportes_id = '$reportes_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.reportes where reportes_id= '$reportes_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}

function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.reportes");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
	
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_reportes">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Reporte ID</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Equipo</p></th>
							<th class="col-md-2"><p align="center">Rama</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>
                                    ';
                                }
		
							  $regreso.='</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $reportes_id = $fila['reportes_id'];
				  $deporte = $fila['Deporte'];
				  $equipo = $fila['Equipo'];
				  $rama = $fila['Rama'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $reportes_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$rama.'</td>';
						  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
						  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$reportes_id.'" class="btn_modificar btn btn-success" accion="editreportes">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$reportes_id.'" class="btn_eliminar btn btn-danger" accion="delreportes">Eliminar                          </button></td>
						</tr> ';
                        }
						$regreso.='</tr>';
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $reportes_id = $_POST['reportes_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.reportes where reportes_id= '$reportes_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $reportes_id = $fila['reportes_id'];
    $deporte = $fila['Deporte'];
    $equipo = $fila['Equipo'];
	$rama = $fila['Rama'];
        
    $regreso= '<label class="col-md-2">Deporte:</label>
	 			 <div class="col-md-3">
	      			<select class="form-control" id="inp_deporte_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                     if($deporte == 'F&uacute;tbol'){
                          $regreso.= '<option value="F&uacute;tbol" selected>F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      } elseif($deporte == 'Basquetbol'){
                         $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol" selected>Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>'; 
					 } elseif($deporte == 'Voleibol'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol" selected>Voleibol</option>
								   	<option value="Atletismo">Atletismo</option>'; 
					} elseif($deporte == 'Atletismo'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol">Voleibol</option>
								   	<option value="Atletismo" selected>Atletismo</option>';				
												  
                      } else {
                          $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      }
               		$regreso.= '</select>
      			</div>
			    <br><br><br>
			   <label class="col-md-2">Equipo:</label>
				 <div class="col-md-4">
				  <select class="form-control" id="inp_equipo_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
					 if($equipo == 'Colegio ingles'){
                          $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles">Colegio ingles blanco</option>';
                      } elseif($equipo == 'Colegio ingles verde'){
					 	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde" selected>Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
					  } elseif($equipo == 'Colegio ingles blanco'){
					  	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles</option>
									  <option value="Colegio ingles blanco" selected>Colegio ingles blanco</option>';	
					} else {
                          $regreso.= '<option value="Colegio ingles">Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
                    }
					$regreso.= '</select>
				  </div>
				  <br><br><br>
				<label class="col-md-2">Rama:</label>
				  <div class="col-md-3">
					<select class="form-control" id="inp_rama_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($rama == 'Varonil'){
                          $regreso.= '<option value="Varonil" selected>Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      } elseif($rama == 'Femenil'){
                         $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil" selected>Femenil</option>
									  <option value="Mixto">Mixto</option>'; 
					 } elseif($rama == 'Mixto'){
					 	$regreso.= '<option value="Varonil">Varonil</option>
								  <option value="Femenil">Femenil</option>
								  <option value="Mixto" selected>Mixto</option>'; 			  
                      } else {
                          $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      }
               		$regreso.= '</select>
      			</div>';
    return $regreso;
}
function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.reportes where Deporte like '%$busqueda%' or Equipo like '%$busqueda%' or Rama like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso= '<table class="table table-striped table-bordered" id="tabla_reportes">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Reporte ID</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Equipo</p></th>
							<th class="col-md-2"><p align="center">Rama</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }
		
							  $regreso.='</tr>
						</thead>
					  <tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);
					  $reportes_id = $fila['reportes_id'];
				      $deporte = $fila['Deporte'];
				      $equipo = $fila['Equipo'];
				      $rama = $fila['Rama'];
				      $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $reportes_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$rama.'</td>';
						  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
						  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$reportes_id.'" class="btn_modificar btn btn-success" accion="editreportes">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$reportes_id.'" class="btn_eliminar btn btn-danger" accion="delreportes">Eliminar                          </button></td>
						</tr>';
                                }
						$regreso.= '</tr>';
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>
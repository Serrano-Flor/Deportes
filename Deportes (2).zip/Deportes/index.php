<?php
  include("conecta.php");
  session_start();
  $_SESSION['iniciada'] = 0;
  session_destroy(); 
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Acceso</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->

<style>
	.btn-editar {
		width: 40px;
		height: 40px;
    }
		
    #tabla_acceso {
        font-size: 14;
        font-style: arial;
    }
	
    .Contenedor img {
	   width: 100%; 
       position: relative;
    }
    body{
       background-color:#86a286;   
       background-position:right; 
       background-repeat: no-repeat;
    }
</style>
<script type="text/javascript">
$(document).ready(function()
{
   var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
});
</script>
</head>
<body method="post"> 
	<div class="Contenedor encabezado">
		<img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
	</div>
	<br>	
		<h1 align="center">Acceso</h1>
	<br>
    <div class="container">
        <div class="col-md-3"></div>
        <div class="col-md-6">
        <form action="valida.php" method="POST" role="form"> 
            <div class="form-group row" align="center">
                <label class="col-md-4" style="color:#FFFFFF"><span class="glyphicon glyphicon-user"></span> &nbsp;Usuario:</label>
                <div class="col-md-8">
                    <input type="text" class="form-control" id="inp_usuario" name="inp_usuario" autofocus placeholder="Nombre de usuario" required/>
                    <p id="emailHelp" class="form-text text-muted" style="color:#003300">Rol: Administrador, Asistente, Entrenador, Visitante</p>
                </div>
            </div>	  
            <br>
            <div class="form-group row" align="center">	  
                 <label class="col-md-4" style="color:#FFFFFF"><span class="glyphicon glyphicon-asterisk"></span>&nbsp; Contrase&ntilde;a:</label>
                 <div class="col-md-8">	
                    <input type="password" class="form-control" id="inp_contrasena" name="inp_contrasena" placeholder="Contrase&ntilde;a" required/>
                    <p id="contrasenaHelp" class="form-text text-muted" style="color:#003300">Puede usar letras y n&uacute;meros</p>
                  </div>
            </div>	   
           <br>
          <div align="center">
            <button type="submit" class="btn btn-primary" id="btn_aceptar">Iniciar sesion</button>
		  </div>
		  <br>
  <div id="ack">
  </div>
 </form>
</div>
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
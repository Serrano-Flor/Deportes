<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['nombre'])) { $nombre = $_POST['nombre']; }
if(isset($_POST['activo'])) { $activo = $_POST['activo']; }
if(isset($_POST['temporada_id'])) { $temporada_id = $_POST['temporada_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.temporada (Nombre, Activo) values('$nombre','$activo')");
          echo Tabla();
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.temporada set nombre= '$nombre', activo= '$activo' where temporada_id = '$temporada_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.temporada where temporada_id= '$temporada_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}

function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.temporada");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
	
		$regreso = '<table class="table table-striped table-bordered" id="tabla_temporada">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Temporada ID</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Activo</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
								$regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								<th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
							$regreso.= '</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $temporada_id = $fila['temporada_id'];
				  $nombre = $fila['Nombre'];
				  $activo = $fila['Activo'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $temporada_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                          if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
								$regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$temporada_id.'" class="btn_modificar btn btn-success" accion="edittemporada">Modificar</button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$temporada_id.'" class="btn_eliminar btn btn-danger" accion="deltemporada">Eliminar</button></td>';
                          }
                    $regreso.='</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $temporada_id = $_POST['temporada_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.temporada where temporada_id= '$temporada_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $temporada_id = $fila['temporada_id'];
    $nombre = $fila['Nombre'];
    $activo = $fila['Activo'];
        
    $regreso= '<label class="col-md-2">Nombre:</label>
		 		 <div class="col-md-5">
				  <input id="inp_nombre_modal" class="form-control" type="text" value= "'.$nombre.'" placeholder="Nombre completo">
				  </div>
				  <label class="col-md-2">Activo:</label>
				  <div class="col-md-2">
				  <select class="form-control" id="inp_activo_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($activo == 'Si'){
                          $regreso.= '<option value="Si" selected>Si</option>
					                  <option value="No">No</option>';
                      } elseif($activo == 'No'){
                         $regreso.= '<option value="Si">Si</option>
					                  <option value="No" selected>No</option>'; 
                      } else {
                          $regreso.= '<option value="Si">Si</option>
					                  <option value="No">No</option>';
                      }
               		$regreso.= '</select>
      			</div>';
               		
    return $regreso; 
}

function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.temporada where Nombre like '%$busqueda%' or Activo like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso= '<table class="table table-striped table-bordered" id="tabla_temporada">
							<thead>
							  <tr>
								<th class="col-md-1"><p align="center">#</p></th>
								<th class="col-md-1"><p align="center">Temporada ID</p></th>
								<th class="col-md-2"><p align="center">Nombre</p></th>
								<th class="col-md-2"><p align="center">Activo</p></th>';
								if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }
		
							  $regreso.='</tr>
							</thead>
						<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);

                      $temporada_id = $fila['temporada_id'];
				 	  $nombre = $fila['Nombre'];
				  	  $activo = $fila['Activo'];
					  $regreso.= '<tr>
									  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
									  <td style="vertical-align:middle;" align="left">'. $temporada_id .'</td>                 
									  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
									  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
									  if ($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante') {
                                  $regreso.='<td style="vertical-align:middle;" align="center"><button id="'.$temporada_id.'" class="btn_modificar btn btn-success" accion="edittemporada">Modificar		                          </button></td>
									  <td style="vertical-align:middle;" align="center"><button id="'.$temporada_id.'" class="btn_eliminar btn btn-danger" accion="deltemporada">Eliminar                          </button></td>';
                                }
						$regreso.= '</tr>'; 
                      $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>
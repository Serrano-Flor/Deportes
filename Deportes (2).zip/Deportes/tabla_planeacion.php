<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['nuevo'])) { $nuevo = $_POST['nuevo']; }
if(isset($_POST['equipo'])) { $equipo = $_POST['equipo']; }
if(isset($_POST['fecha'])) { $fecha = $_POST['fecha']; }
if(isset($_POST['planeacion_id'])) { $planeacion_id = $_POST['planeacion_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.planeacion (Nuevo, Equipo, Fecha) values('$nuevo','$equipo','$fecha')");
          echo Tabla();
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.planeacion set Nuevo= '$nuevo', Equipo= '$equipo', Fecha= '$fecha' where planeacion_id = '$planeacion_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.planeacion where planeacion_id= '$planeacion_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
    case 'buscar':
        echo Tabla_buscar();    
    break;
}
function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.planeacion");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
	
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_planeacion">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Planeaci&oacute;n ID</p></th>
							<th class="col-md-2"><p align="center">Nuevo</p></th>
							<th class="col-md-2"><p align="center">Equipo</p></th>
							<th class="col-md-2"><p align="center">Fecha</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
							     <th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
						  $regreso.='</tr>
					</thead>
			<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $planeacion_id = $fila['planeacion_id'];
				  $nuevo = $fila['Nuevo'];
				  $equipo = $fila['Equipo'];
				  $fecha = $fila['Fecha'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $planeacion_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$nuevo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$fecha.'</td>';
                          if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='
						  <td style="vertical-align:middle;" align="center"><button id="'.$planeacion_id.'" class="btn_modificar btn btn-success" accion="editplaneacion">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$planeacion_id.'" class="btn_eliminar btn btn-danger" accion="delplaneacion">Eliminar</button></td>';
                          }
						$regreso.='</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $planeacion_id = $_POST['planeacion_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.planeacion where planeacion_id= '$planeacion_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $planeacion_id = $fila['planeacion_id'];
    $nuevo = $fila['Nuevo'];
    $equipo = $fila['Equipo'];
	$fecha = $fila['Fecha'];
        
    $regreso= '<label class="col-md-2">Nuevo:</label>
	 			 <div class="col-md-3">
	      			<input id="inp_nuevo_modal" class="form-control" type="text" value= "'.$nuevo.'">
				 </div>	
				 <br><br><br>
			   <label class="col-md-2">Equipo:</label>
				  <div class="col-md-5">
					  <select class="form-control" id="inp_equipo" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($equipo == 'Colegio ingles'){
                          $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles">Colegio ingles blanco</option>';
                      } elseif($equipo == 'Colegio ingles verde'){
					 	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde" selected>Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
					  } elseif($equipo == 'Colegio ingles blanco'){
					  	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles</option>
									  <option value="Colegio ingles blanco" selected>Colegio ingles blanco</option>';	
					} else {
                          $regreso.= '<option value="Colegio ingles">Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
                    }
					$regreso.= '</select>
				  </div>
				  <br><br><br>
				<label class="col-sm-2">Fecha:</label>
					<div class="col-sm-2">
					 <input type="date" class="form-conrtrol" id="inp_fecha_modal" style="border-radius: 5px; border: 1px solid #39c; width:165px; height:35px;" placerholder="mm/dd/yyyy" value= "'.$fecha.'">
				</div>';
    return $regreso;
}

function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.planeacion where Nuevo like '%$busqueda%' or Equipo like '%$busqueda%' or Fecha like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso.= '
                         <table class="table table-striped table-bordered" id="tabla_planeacion">
                            <thead>
                              <tr>
                                <th class="col-md-1"><p align="center">#</p></th>
                                <th class="col-md-1"><p align="center">Planeaci&oacute;n ID</p></th>
                                <th class="col-md-2"><p align="center">Nuevo</p></th>
                                <th class="col-md-2"><p align="center">Equipo</p></th>
                                <th class="col-md-2"><p align="center">Fecha</p></th>';
                                if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
                                    <th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }

                              $regreso.='</tr>
                        </thead>
                <tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);

                      $planeacion_id = $fila['planeacion_id'];
                      $nuevo = $fila['Nuevo'];
                      $equipo = $fila['Equipo'];
                      $fecha = $fila['Fecha'];
                      $regreso.= '<tr>
                              <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
                              <td style="vertical-align:middle;" align="left">'. $planeacion_id .'</td>                 
                              <td style="vertical-align:middle;" align="center">'.$nuevo.'</td>
                              <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
                              <td style="vertical-align:middle;" align="center">'.$fecha.'</td>';
                        if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='
                              <td style="vertical-align:middle;" align="center"><button id="'.$planeacion_id.'" class="btn_modificar btn btn-success" accion="editplaneacion">Modificar		                          </button></td>
                              <td style="vertical-align:middle;" align="center"><button id="'.$planeacion_id.'" class="btn_eliminar btn btn-danger" accion="delplaneacion">Eliminar</button></td>';
                        }
                        $regreso.='</tr>'; 
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}
?>
<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Entrenador' || $_SESSION['usua_rol'] == 'Visitante') {
      header('Location: Menu.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Base de datos</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_BD.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textEestatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
  var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
  
	  var nombre_inp = $('#inp_nombre').val();
	  var foto_inp = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
	  var app_inp = $('#inp_app').val();
	  var apm_inp = $('#inp_apm').val();
	  var sexo_inp = $('input[name="inp_sexo"]:checked').val();
	  var fechan_inp = $('#inp_fechan').val();
	  var curp_inp = $('#inp_curp').val();
	  var matricula_inp = $('#inp_matricula').val();
	  var grado_inp = $('#inp_grado').val();
	  var seccion_inp = $('#inp_seccion').val();
	  var folio_inp = $('#inp_folio').val();
	  var enfermedad_inp = $('#inp_enfermedad').val();
	  var telefono_inp = $('#inp_telefono').val();
	  var email_inp = $('#inp_email').val();
	  var emailp_inp = $('#inp_emailp').val();
	  var deporte_inp = $('#inp_deporte option:selected').val();
	  var equipo_inp = $('#inp_equipo option:selected').val();
	  var rama_inp = $('#inp_rama option:selected').val();
	  var estatus_inp = $('#inp_estatus option:selected').val();
	  
	  var campos_insert = {nombre: nombre_inp, foto: foto_inp, app: app_inp, apm: apm_inp, sexo: sexo_inp, fechan: fechan_inp, curp: curp_inp, matricula: matricula_inp,
	  grado: grado_inp, seccion: seccion_inp, folio: folio_inp, enfermedad: enfermedad_inp, telefono: telefono_inp, email: email_inp, emailp: emailp_inp, 
	  deporte: deporte_inp, equipo: equipo_inp, rama: rama_inp, estatus: estatus_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_BD.php',

		  success: function(response){
			swal({   
                  type: "success",   
                  title: "¡Se inserto correctamente!", 
                });
				$('#div_pri').html(response);
				$("#form")[0].reset();
				$('#inp_nombre').val('');
				$('#inp_app').val('');
				$('#inp_apm').val(''); 
				$('input[name="inp_sexo"]').prop('checked', false);
				$('#inp_fechan').val(''); 
				$('#inp_curp').val('');
				$('#inp_matricula').val('');  
				$('#inp_grado').val(''); 
				$('#inp_seccion').val('');
				$('#inp_folio').val(''); 
				$('#inp_enfermedad').val('');
				$('#inp_telefono').val('');
				$('#inp_email').val(''); 
				$('#inp_emailp').val('');
				$('#inp_deporte').val(''); 
				$('#inp_equipo').val('');
				$('#inp_rama').val('');
				$('#inp_estatus').val('');
            	$('#file-status').html('No se ha seleccionado archivo').fadeIn();
		  },

		  error : function(XMLHttpRequest, textsestatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {BD_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_BD.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textsestatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
		var nombre_inp = $('#inp_nombre_modal').val();
	    var foto_inp = $('#upload2').attr('valor');
	    var app_inp = $('#inp_app_modal').val();
	    var apm_inp = $('#inp_apm_modal').val();
	    var sexo_inp = $('input[name="inp_sexo_modal"]:checked').val();
	    var fechan_inp = $('#inp_fechan_modal').val();
	    var curp_inp = $('#inp_curp_modal').val();
	    var matricula_inp = $('#inp_matricula_modal').val();
	    var grado_inp = $('#inp_grado_modal').val();
	    var seccion_inp = $('#inp_seccion_modal').val();
	    var folio_inp = $('#inp_folio_modal').val();
	    var enfermedad_inp = $('#inp_enfermedad_modal').val();
	    var telefono_inp = $('#inp_telefono_modal').val();
	    var email_inp = $('#inp_email_modal').val();
	    var emailp_inp = $('#inp_emailp_modal').val();
	    var deporte_inp = $('#inp_deporte_modal option:selected').val();
	    var equipo_inp = $('#inp_equipo_modal option:selected').val();
	    var rama_inp = $('#inp_rama_modal option:selected').val();
	    var estatus_inp = $('#inp_estatus_modal option:selected').val();
        
        var campos_modificar = {BD_id: id, nombre: nombre_inp, foto: foto_inp, app: app_inp, apm: apm_inp, sexo: sexo_inp, fechan: fechan_inp, curp: curp_inp, 
		matricula: matricula_inp, grado: grado_inp, seccion: seccion_inp, folio: folio_inp, enfermedad: enfermedad_inp, telefono: telefono_inp, email: email_inp, 
		emailp: emailp_inp, deporte: deporte_inp, equipo: equipo_inp, rama: rama_inp, estatus: estatus_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_BD.php',

              success: function(response){
                $('#div_pri').html(response);
				swal({   
                  type: "success",   
                  title: "¡Se actualizo la información con éxito!", 
                });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, texteestatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
			  
		var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar la base de datos con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {BD_id: id, act: 'eliminar'};
		
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_BD.php',

              success: function(response){
				swal({   
                  type: "success", 
                  title: "¡Se elimino con éxito!", 
                });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
                $("#form")[0].reset();
                $('#file-status').html('No se ha seleccionado archivo').fadeIn();
              },

              error : function(XMLHttpRequest, texteestatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_BD.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
	var status= $('#upload').val();
	if(!status){
        $('#file-status').html('No se ha seleccionado archivo');    
    }
    
    $(document).on('change', '#upload', function(){
        var status= $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload').removeAttr('disabled');
        }
    });
    
    $(document).on('click','#file-upload',(function(e) {
        var formData= new FormData('#form');
        var path = $('#upload[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','insert-img');
        formData.append('foto', path);
        formData.append('file', $('#upload[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_BD.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				  swal({   
                  	type: "error",   
                  	title: "Archivo no valido! Intente de nuevo.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				   swal({   
                  	type: "error",   
                  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
                  });
                  $("#form")[0].reset();
                  $('#file-status').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
                  // view uploaded file.
				   swal({   
                  	type: "success",   
                  	title: "El archivo se cargo correctamente!"+data, 
                  });
                }
              },
             error: function(e) 
              {
                $("#err").html(e);
              }          
        });
     }));
    
    $(document).on('change', '#upload2', function(){
        var status= $('#upload2[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('#file-status2').html('<span class="glyphicon glyphicon-file"></span><label>'+status+'</label>');
        if(status){
            $('#file-upload2').removeAttr('disabled');
        }
    });
    
    $(document).on('click','#file-upload2',(function(e) {
        var formData= new FormData(this);
        var path = $('#upload2[type=file]').val().replace(/C:\\fakepath\\/i, '');
        formData.append('act','modificar-img');
        formData.append('foto', path);
        formData.append('file', $('#upload2[type=file]')[0].files[0]);
        
      e.preventDefault();
      $.ajax({
           url: "tabla_BD.php",
           type: "POST",
           data:  formData,
           contentType: false,
                 cache: false,
           processData:false,
           beforeSend : function()
           {
              $("#err2").fadeOut();
           },
           success: function(data)
              {
                  
                if(data=='invalido')
                {
                  // invalid file format.
				  swal({   
                  	type: "error",   
                  	title: "Archivo no valido! Intente de nuevo.", 
                  });
                  $("#form2")[0].reset();
                  $('#file-status2').html('No se ha seleccionado archivo').fadeIn();
                }
                else if (data == 'repetido')
                {
				  swal({   
                  	type: "error",   
                  	title: "El archivo ya existe! Por favor agregue uno diferente.", 
                  });
                  $("#form2")[0].reset();
                  $('#file-status2').html('No se ha seleccionado archivo').fadeIn();
                }
                else
                {
                  // view uploaded file.
				   swal({   
                  	type: "success",   
                  	title: "El archivo se cargo correctamente!", 
                  });
                  $('#div-img').html(data);
                }
              },
             error: function(e) 
              {
                $("#err2").html(e);
              }          
        });
     }));
    
    $(document).on('click','#cambiar-img', function(e) {
        var path = $('#cambiar-img').attr('valor');
        var info = {act: 'cambio-imagen', path: path };
        
        $.ajax({
              data : info,
              type : 'POST',
              url : 'tabla_BD.php',

              success: function(response){
                $('#div-img').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
    
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_BD{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   
	   #inp_fechan {
   	    border-radius: 5px;
   		border: 1px solid #39c;
		width:263px; 
		height:35px;}	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br><h1 align="center"><span class="glyphicon glyphicon-book"></span>&nbsp; Base de datos</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  <br>
<div class="form-group row">
  <?php 
    if($_SESSION['usua_rol'] != 'Asistente') {
	echo '<label id="lbl_nombre" class="col-sm-2">Nombre(s):</label>
	<div class="col-sm-3">
		<input type="text" id="inp_nombre" class="form-control">
	</div>
	 <label id="lbl_foto" class="col-sm-2 col-form-label">Foto:</label>
		 <div class="col-md-3">
		     <form id="form" action="tabla_BD.php" method="post" enctype="multipart/form-data">
                   <label class="btn btn-primary btn-file">
                     Seleccionar Nuevo...<input id="upload" type="file" name="file" style="display:none;"/>
                  </label>
                 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload" disabled>
              </form>
              <div id="file-status"></div><div id="err"></div>
      </div>	
    </div>
	<div class="form-group row">
		<label id="lbl_app" class="col-sm-2">Apellido paterno:</label>
		<div class="col-sm-3">
			<input type="text" id="inp_app" class="form-control">
		</div>
		<label id="lbl_apm" class="col-sm-2">Apellido materno:</label>
		<div class="col-sm-3">
			<input type="text" id="inp_apm" class="form-control">
		</div>
	 </div>
		 <div class="form-group row">
			<label id="lbl_sexo" class="col-sm-2">Sexo:</label>
      		  <div class="form-check form-radio-inline col-sm-3">
  				<input type="radio" name="inp_sexo" value="Hombre"> Hombre
				&nbsp;
				<input type="radio" name= "inp_sexo" value="Mujer"> Mujer
	  		  </div>	 
		 	<label id="lbl_fechan" class="col-sm-2">Fecha de nacimiento:</label>
		  	 <div class="col-sm-3">
				<input type="date" name="bday" id="inp_fechan"  class="form-control" placerholder="mm/dd/yyyy">
			  </div>
		</div>	  
		 <div class="form-group row">
        	<label id="lbl_curp" class="col-sm-2">CURP:</label>
			 <div class="col-sm-3">
				<input type="text" id="inp_curp" class="form-control">
			 </div>
			 <label id="lbl_matricula" class="col-sm-2">Matr&iacute;cula:</label>
				 <div class="col-sm-3">
					<input type="text" id="inp_matricula" class="form-control">
				 </div>
    	 </div>
		  <div class="form-group row">
        	<label id="lbl_grado" class="col-sm-2">Grado:</label>
			 <div class="col-sm-1">
				<input type="text" id="inp_grado" placeholder="1o" class="form-control">
			 </div>
			 <label id="lbl_seccion" class="col-sm-1">Secci&oacute;n:</label>
				 <div class="col-sm-1">
					<input type="text" id="inp_seccion" class="form-control">
				 </div>
			 <label id="lbl_folio" class="col-sm-2">Folio del seguro:</label>
			 <div class="col-sm-3">
				<input type="text" id="inp_folio" class="form-control">
			 </div>
    	 </div>
		 <div class="form-group row"> 	
			 <label id="lbl_enfermedad" class="col-sm-2">Enfermedades:</label>
				 <div class="col-sm-3">
					<input type="text" id="inp_enfermedad" class="form-control" style="width:263px; height:80px">
				 </div>
			<label id="lbl_telefono" class="col-sm-2 ">Tel&eacute;fono:</label>
			 <div class="col-sm-3">
				<input type="text" id="inp_telefono" class="form-control">
			 </div>
    	 </div>
		 <div class="form-group row">
          <label id="lbl_email" class="col-sm-2">E-mail:</label>
            <div class="col-sm-3">
              <input type="text" pattern="^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" id="inp_email" placeholder="nombre@gmail.com" class="form-control">
           	 </div>		 
        	<label id="lbl_emailp" class="col-sm-2">E-mail de padre de familia:</label>
            	<div class="col-sm-3">
                	<input type="text" pattern="^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" id="inp_emailp" 
					placeholder="nombre@gmail.com" class="form-control">
           		 </div>
    	 </div>
		  <div class="form-group row">
			<label id="lbl_deporte" class="col-sm-2">Deporte:</label>
			 <div class="col-sm-3">
				<select class="form-control" id="inp_deporte" required>
				  <option selected disabled value="">Selecciona:</option>
				  <option value="F&uacute;tbol">F&uacute;tbol</option>
				  <option value="Basquetbol">Basquetbol</option>
          		  <option value="Voleibol">Voleibol</option>
          		  <option value="Atletismo">Atletismo</option>
				</select>
			 </div>
			<label id="lbl_equipo" class="col-sm-2">Equipo:</label>
			 <div class="col-sm-3">
				<select class="form-control" id="inp_equipo" required>
				  <option selected disabled value="">Selecciona:</option>
				  <option value="Colegio ingles">Colegio ingles</option>
		  		  <option value="Colegio ingles verde">Colegio ingles verde</option>
		  		  <option value="Colegio ingles blanco">Colegio ingles blanco</option>
				</select>
			 </div>
    	 </div>
		 <div class="form-group row">
			<label id="lbl_rama" class="col-sm-2">Rama:</label>
			 <div class="col-sm-3">
				<select class="form-control" id="inp_rama" required>
				  <option selected disabled value="">Selecciona:</option>
				  <option value="Varonil">Varonil</option>
				  <option value="Femenil">Femenil</option>
				  <option value="Mixto">Mixto</option>
				</select>
			 </div>
		 <!--Estatus: pre-inscrito, inscrito, no inscrito, a prueba-->
		 <label id="lbl_estatus" class="col-sm-2">Estatus:</label>
		   <div class="col-sm-3">
			<select class="form-control" id="inp_estatus" required>
			  <option selected disabled value="">Selecciona:</option>
			  <option value="Pre-inscrito">Pre-inscrito</option>
			  <option value="Inscrito">Inscrito</option>
			  <option value="No inscrito">No inscrito</option>
			  <option value="Aprueba">Aprueba</option>
			</select>
		   </div>
		</div>'; } ?>   
  <div align="center">
  	  <?php 
          if($_SESSION['usua_rol'] != 'Asistente') {
            echo '<button class="btn btn-primary" id="btn_nuevo">Nueva asistencia</button>';
          }
      ?>
  </div><br>
  <div class="form-group row">
    <label id="lbl_buscar" class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
  </div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar base de datos</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar base de datos</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['deporte'])) { $deporte = $_POST['deporte']; }
if(isset($_POST['nombre'])) { $nombre = $_POST['nombre']; }
if(isset($_POST['rama'])) { $rama = $_POST['rama']; }
if(isset($_POST['activo'])) { $activo = $_POST['activo']; }
if(isset($_POST['equipos_id'])) { $equipos_id = $_POST['equipos_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.equipos (Deporte, Nombre, Rama, Activo) values('$deporte','$nombre','$rama','$activo')");
          echo Tabla();
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.equipos set Deporte= '$deporte', Nombre= '$nombre', Rama= '$rama', Activo= '$activo' where equipos_id = '$equipos_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
		mysqli_query($con, "delete from Deportes.equipos where equipos_id= '$equipos_id'");
		echo Tabla();
    break;
          
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}
function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.equipos");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_equipos">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">Equipos ID</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Rama</p></th>
							<th class="col-md-2"><p align="center">Activo</p></th>';
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
							                 <th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
						  $regreso.='</tr>
						</thead>
					<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $equipos_id = $fila['equipos_id'];
				  $deporte = $fila['Deporte'];
				  $nombre = $fila['Nombre'];
				  $rama = $fila['Rama'];
				  $activo = $fila['Activo'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $equipos_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center">'.$rama.'</td>
						  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                          if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<td style="vertical-align:middle;" align="center"><button id="'.$equipos_id.'" class="btn_modificar btn btn-success" accion="editequipos">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$equipos_id.'" class="btn_eliminar btn btn-danger" accion="delequipos">Eliminar                          </button></td>';
                          }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $equipos_id = $_POST['equipos_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.equipos where equipos_id= '$equipos_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $equipos_id = $fila['equipos_id'];
    $deporte = $fila['Deporte'];
    $nombre = $fila['Nombre'];
	$rama = $fila['Rama'];
	$activo = $fila['Activo'];
        
    $regreso= '<label class="col-md-2">Deporte:</label>
	 			 <div class="col-md-3">
	      			<select class="form-control" id="inp_deporte_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($deporte == 'F&uacute;tbol'){
                          $regreso.= '<option value="F&uacute;tbol" selected>F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      } elseif($deporte == 'Basquetbol'){
                         $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                 <option value="Basquetbol" selected>Basquetbol</option>
									 <option value="Voleibol">Voleibol</option>
									 <option value="Atletismo">Atletismo</option>'; 
					 } elseif($deporte == 'Voleibol'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								    <option value="Basquetbol">Basquetbol</option>
									<option value="Voleibol" selected>Voleibol</option>
									<option value="Atletismo">Atletismo</option>';
					} elseif($deporte == 'Atletismo'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								    <option value="Basquetbol">Basquetbol</option>
									<option value="Voleibol">Voleibol</option>
									<option value="Atletismo" selected>Atletismo</option>';  			  
                      } else {
                          $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								      <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      }
               		$regreso.= '</select>
      			</div>
				<br><br><br>
			   <label class="col-md-2">Nombre:</label>
				  <div class="col-md-5">
					<select class="form-control" id="inp_nombre_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                       if($nombre == 'Colegio ingles'){
                          $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles">Colegio ingles blanco</option>';
                      } elseif($nombre == 'Colegio ingles verde'){
					 	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde" selected>Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
					  } elseif($nombre == 'Colegio ingles blanco'){
					  	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles</option>
									  <option value="Colegio ingles blanco" selected>Colegio ingles blanco</option>';	
					} else {
                          $regreso.= '<option value="Colegio ingles">Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
                    }
					$regreso.= '</select>
				  </div></div>
				  <br><br><br>
				<label class="col-sm-2">Rama:</label>
				  <div class="col-sm-3">
					 <select class="form-control" id="inp_rama_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($rama == 'Varonil'){
                          $regreso.= '<option value="Varonil" selected>Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      } elseif($rama == 'Femenil'){
                         $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil" selected>Femenil</option>
									  <option value="Mixto">Mixto</option>'; 
					 } elseif($rama == 'Mixto'){
					 	$regreso.= '<option value="Varonil">Varonil</option>
								  <option value="Femenil">Femenil</option>
								  <option value="Mixto" selected>Mixto</option>'; 			  
                      } else {
                          $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      }
               		$regreso.= '</select>
      			</div>
				<br><br><br>	  
				<label class="col-md-2">Activo:</label>
				  <div class="col-md-2">
					 <select class="form-control" id="inp_activo_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($activo == 'Si'){
                          $regreso.= '<option value="Si" selected>Si</option>
					                  <option value="No">No</option>';
                      } elseif($activo == 'No'){
                         $regreso.= '<option value="Si">Si</option>
					                  <option value="No" selected>No</option>'; 
                      } else {
                          $regreso.= '<option value="Si">Si</option>
					                  <option value="No">No</option>';
                      }
               		$regreso.= '</select>
      			</div>';
    return $regreso;
}
function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.equipos where Deporte like '%$busqueda%' or Nombre like '%$busqueda%' or Rama like '%$busqueda%' or 
	Activo like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_equipos">
							<thead>
							  <tr>
								<th class="col-md-1"><p align="center">#</p></th>
								<th class="col-md-1"><p align="center">Equipos ID</p></th>
								<th class="col-md-2"><p align="center">Deporte</p></th>
								<th class="col-md-2"><p align="center">Nombre</p></th>
								<th class="col-md-2"><p align="center">Rama</p></th>
								<th class="col-md-2"><p align="center">Activo</p></th>';
								if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Modificar</p></th>
								             <th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }
							  $regreso.='</tr>
							</thead>
						<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);

                      $equipos_id = $fila['equipos_id'];
				 	  $deporte = $fila['Deporte'];
				  	  $nombre = $fila['Nombre'];
				  	  $rama = $fila['Rama'];
				  	  $activo = $fila['Activo'];
				  	  $regreso.= '<tr>
								  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
								  <td style="vertical-align:middle;" align="left">'. $equipos_id .'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$deporte.'</td>
								  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
								  <td style="vertical-align:middle;" align="center">'.$rama.'</td>
								  <td style="vertical-align:middle;" align="center">'.$activo.'</td>';
                                  if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<td style="vertical-align:middle;" align="center"><button id="'.$equipos_id.'" class="btn_modificar btn btn-success" accion="editequipos">Modificar		                          </button></td>
								  <td style="vertical-align:middle;" align="center"><button id="'.$equipos_id.'" class="btn_eliminar btn btn-danger" accion="delequipos">Eliminar</button></td>';
                                  }
								  $regreso.='</tr>'; 
                            $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}

?>
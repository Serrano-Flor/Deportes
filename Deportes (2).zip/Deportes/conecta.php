<?php
function conectar(){
  $Servidor = "127.0.0.1";
  $User = "root";
  $Psw = "";
  $BaseDatos = "Deportes";

  $conecta = new mysqli($Servidor, $User, $Psw, $BaseDatos);
  
 if($conecta->connect_errno){
  	 return "No conectado";

   }else {
 	 return"Conectado";
	
  }
} 
?>
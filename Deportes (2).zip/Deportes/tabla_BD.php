<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['nombre'])) { $nombre = $_POST['nombre']; }
if(isset($_POST['foto'])) { $foto = $_POST['foto']; }
if(isset($_POST['app'])) { $app = $_POST['app']; }
if(isset($_POST['apm'])) { $apm = $_POST['apm']; }
if(isset($_POST['sexo'])) { $sexo = $_POST['sexo']; }
if(isset($_POST['fechan'])) { $fechan = $_POST['fechan']; }
if(isset($_POST['curp'])) { $curp = $_POST['curp']; }
if(isset($_POST['matricula'])) { $matricula = $_POST['matricula']; }
if(isset($_POST['grado'])) { $grado = $_POST['grado']; }
if(isset($_POST['seccion'])) { $seccion = $_POST['seccion']; }
if(isset($_POST['folio'])) { $folio = $_POST['folio']; }
if(isset($_POST['enfermedad'])) { $enfermedad = $_POST['enfermedad']; }
if(isset($_POST['telefono'])) { $telefono = $_POST['telefono']; }
if(isset($_POST['email'])) { $email = $_POST['email']; }
if(isset($_POST['emailp'])) { $emailp = $_POST['emailp']; }
if(isset($_POST['deporte'])) { $deporte = $_POST['deporte']; }
if(isset($_POST['equipo'])) { $equipo = $_POST['equipo']; }
if(isset($_POST['rama'])) { $rama = $_POST['rama']; }
if(isset($_POST['estatus'])) { $estatus = $_POST['estatus']; }
if(isset($_POST['BD_id'])) { $BD_id = $_POST['BD_id']; }
if(isset($_POST['busqueda'])) { $busqueda = $_POST['busqueda']; }

  switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
          mysqli_query($con, "insert into Deportes.basededatos (Nombre, Foto, App, Apm, Sexo, Fechan, CURP, Matricula, Grado, Seccion, Folio, Enfermedades, Telefono, Email, Emailpadre, Deporte, Equipo, Rama, Estatus) values('$nombre', '$foto', '$app', '$apm', '$sexo', '$fechan', '$curp', '$matricula', '$grado', '$seccion', '$folio', '$enfermedad', '$telefono', '$email','$emailp', '$deporte', '$equipo', '$rama', '$estatus')");
          echo Tabla();
          
    break;
	
	case 'insert-img':
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'img/fotos/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select Foto from Deportes.basededatos where Foto like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
                
            }
    break;
    
	case 'modificar-img':
          $foto = $_POST['foto'];
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'img/fotos/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = 0;//mysqli_num_rows(mysqli_query($con, "select Foto from Deportes.nuevo where Foto like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                        echo '<img alt="'.$foto.'" src="'.$path.'" style="height:100px;width:150px;">
                            <br><button class="btn btn-warning" id="cambiar-img" valor="img/fotos/'.$foto.'">Cambiar</button>
                            <input id="upload2" type="file" name="file" valor="'.$foto.'" style="display:none;"/>';
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
            }
    break;
	
	case 'modificar':
		  mysqli_query($con, "update Deportes.basededatos set Nombre= '$nombre', Foto= '$foto', App= '$app', Apm= '$apm', Sexo= '$sexo', Fechan= '$fechan', CURP= '$curp', Matricula= '$matricula', Grado= '$grado', Seccion= '$seccion', Folio= '$folio', Enfermedades= '$enfermedad', Telefono= '$telefono', Email= '$email', Emailpadre= '$emailp', Deporte= '$deporte', Equipo= '$equipo', Rama= '$rama', Estatus= '$estatus' where BD_id = '$BD_id'");
		  echo Tabla();
    break;
	
	case 'eliminar':
          $query = mysqli_query($con, "select * from Deportes.basededatos where BD_id= '$BD_id'");
          if($query) {
              while($fila = mysqli_fetch_array($query)) {
                  extract($fila);
                  $img = $fila['Foto'];
                  
                  $filePath = 'img/fotos/'.$img;
                  if (file_exists($filePath) && $filePath != 'img/fotos/') {
                    unlink($filePath);
                  }
              }
          }

		  mysqli_query($con, "delete from Deportes.basededatos where BD_id= '$BD_id'");
		  echo Tabla();
          
    break;
    
    case 'cambio-imagen':
        $filePath = $_POST['path'];
        if (file_exists($filePath)) 
        {
            unlink($filePath);
        }
		echo '<form id="form2" action="tabla_BD.php" method="post" enctype="multipart/form-data">
                   <label class="btn btn-primary btn-file">
                     Seleccionar Nuevo...<input id="upload2" type="file" name="file" style="display:none;"/>
                  </label>
                 <input class="btn btn-success" type="submit" value="Cargar" id="file-upload2" disabled>
              </form>';
    break;
	
    case 'modificar_modal':
		echo modal_editar();
    break;
	
	case 'buscar':
        echo Tabla_buscar();    
    break;
}

function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.basededatos");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = (isset($_POST['regreso']));
		
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_BD">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">BD ID</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Foto</p></th>
							<th class="col-md-2"><p align="center">Apellido paterno</p></th>
							<th class="col-md-2"><p align="center">Apellido materno</p></th>
							<th class="col-md-2"><p align="center">Sexo</p></th>
							<th class="col-md-2"><p align="center">Fecha de nacimiento</p></th>
							<th class="col-md-2"><p align="center">CURP</p></th>
							<th class="col-md-2"><p align="center">Matricula</p></th>
							<th class="col-md-2"><p align="center">Grado</p></th>
							<th class="col-md-2"><p align="center">Secci&oacute;n</p></th>
							<th class="col-md-2"><p align="center">Folio</p></th>
							<th class="col-md-2"><p align="center">Enfermedades</p></th>
							<th class="col-md-2"><p align="center">Tel&eacute;fono</p></th>
							<th class="col-md-2"><p align="center">Email</p></th>
							<th class="col-md-2"><p align="center">Email del padre</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Equipo</p></th>
							<th class="col-md-2"><p align="center">Rama</p></th>
							<th class="col-md-2"><p align="center">Estatus</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>
                                    ';
                                }
	
						  $regreso.= '</tr>
					</thead>
			<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
				  $BD_id = $fila['BD_id'];
				  $nombre = $fila['Nombre'];
				  $foto = $fila['Foto'];
				  $app = $fila['App'];
				  $apm = $fila['Apm'];
				  $sexo = $fila['Sexo'];
				  $fechan = $fila['Fechan'];
				  $curp = $fila['CURP'];
				  $matricula = $fila['Matricula'];
				  $grado = $fila['Grado'];
				  $seccion = $fila['Seccion'];
				  $folio = $fila['Folio'];
				  $enfermedad = $fila['Enfermedades'];
				  $telefono = $fila['Telefono'];
				  $email = $fila['Email'];
				  $emailp = $fila['Emailpadre'];
				  $deporte = $fila['Deporte'];
				  $equipo = $fila['Equipo'];
				  $rama = $fila['Rama'];
				  $estatus = $fila['Estatus'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="left">'. $BD_id .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
						  <td style="vertical-align:middle;" align="center"><img src="img/fotos/'.$foto.'" alt="'.$foto.'" style="height: 80px; width:80px;">'.$foto.'</td>
						  <td style="vertical-align:middle;" align="center">'.$app.'</td>
						  <td style="vertical-align:middle;" align="left">'. $apm .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$sexo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$fechan.'</td>
						  <td style="vertical-align:middle;" align="center">'.$curp.'</td>
						  <td style="vertical-align:middle;" align="left">'. $matricula .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$grado.'</td>
						  <td style="vertical-align:middle;" align="center">'.$seccion.'</td>
						  <td style="vertical-align:middle;" align="center">'.$folio.'</td>
						  <td style="vertical-align:middle;" align="left">'.$enfermedad.'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$telefono.'</td>
						  <td style="vertical-align:middle;" align="center">'.$email.'</td>
						  <td style="vertical-align:middle;" align="center">'.$emailp.'</td>
						  <td style="vertical-align:middle;" align="left">'. $deporte .'</td>                 
						  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
						  <td style="vertical-align:middle;" align="center">'.$rama.'</td>
						  <td style="vertical-align:middle;" align="center">'.$estatus.'</td>';
						  if($_SESSION['usua_rol'] != 'Asistente') {
						  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$BD_id.'" class="btn_modificar btn btn-success" accion="editBD">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$BD_id.'" class="btn_eliminar btn btn-danger" accion="delBD">Eliminar                          </button></td>';     
						  }
						$regreso.= '</tr>'; 		
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function modal_editar(){
    $BD_id = $_POST['BD_id'];
    $con=mysqli_connect("localhost","root","","Deportes");
    
    $query = mysqli_query($con, "select * from Deportes.basededatos where BD_id= '$BD_id'");
    $fila = mysqli_fetch_array($query);
    extract($fila);
    $BD_id = $fila['BD_id'];
	$nombre = $fila['Nombre'];
    $foto = $fila['Foto'];
    $app = $fila['App'];
    $apm = $fila['Apm'];
    $sexo = $fila['Sexo'];
    $fechan = $fila['Fechan'];
    $curp = $fila['CURP'];
    $matricula = $fila['Matricula'];
    $grado = $fila['Grado'];
    $seccion = $fila['Seccion'];
    $folio = $fila['Folio'];
    $enfermedad = $fila['Enfermedades'];
    $telefono = $fila['Telefono'];
    $email = $fila['Email'];
    $emailp = $fila['Emailpadre'];
    $deporte = $fila['Deporte'];
    $equipo = $fila['Equipo'];
    $rama = $fila['Rama'];
    $estatus = $fila['Estatus'];

    $regreso= '
               <div><label class="col-md-2">Nombre:</label></div>
		 		 <div class="col-md-4">
				  <input id="inp_nombre_modal" class="form-control" type="text" value= "'.$nombre.'">
				  </div>
				  <label class="col-md-2 col-form-label">Foto:</label>
                      <div class="col-md-4" id="div-img">';
                        if($foto){
                            $regreso.= '<img alt="'.$foto.'" src="img/fotos/'.$foto.'" style="height:100px;width:150px;">
                            <br><button class="btn btn-warning" id="cambiar-img" valor="img/fotos/'.$foto.'">Cambiar</button>
                            <input id="upload2" type="file" name="file" valor="'.$foto.'" style="display:none;"/>
                            ';
                        }
                        else {
                            $regreso.= '<form id="form2" action="tabla_BD.php" method="post" enctype="multipart/form-data">
                               <label class="btn btn-primary btn-file">
                                 Seleccionar Nuevo...<input id="upload2" type="file" name="file" style="display:none;"/>
                              </label>
                             <input class="btn btn-success" type="submit" value="Cargar" id="file-upload2" disabled>
                          </form>';
                        }
                   $regreso.= '</div><br><br><br>
				   <div class="col-md-7"></div>
                   <div class="col-md-5"><div id="file-status2"></div><div id="err2"></div></div>
				   </div><br><br><br>
				  <label class="col-md-2">Apellido paterno:</label>
		 		 <div class="col-md-4">
				  <input id="inp_app_modal" class="form-control" type="text" value= "'.$app.'">
				  </div>
				  <label class="col-md-2">Apellido materno:</label>
		 		 <div class="col-md-4">
				  <input id="inp_apm_modal" class="form-control" type="text" value= "'.$apm.'">
				  </div></div><br><br><br>
				  <label class="col-md-2">Sexo:</label>
				  <div class="form-check form-radio-inline col-md-4">';
                   if($sexo == 'Hombre'){
                       $regreso .= '<input type="radio" name="inp_sexo_modal" value="Hombre" checked>Hombre
					<input type="radio" name="inp_sexo_modal" value="Mujer">Mujer';
                   }
                   elseif ($sexo == 'Mujer') {
                       $regreso .= '<input type="radio" name="inp_sexo_modal" value="Hombre">Hombre
					<input type="radio" name="inp_sexo_modal" value="Mujer" checked>Mujer';
                   }
                   else{
                       $regreso .= '<input type="radio" name="inp_sexo_modal" value="Hombre">Hombre
					<input type="radio" name="inp_sexo_modal" value="Mujer">Mujer';
                   }
					$regreso .= '
				 </div>
				 <label class="col-md-2">Fecha de nacimiento:</label>
		 		 <div class="col-md-4">
				  <input id="inp_fechan_modal" class="form-control" type="text" value= "'.$fechan.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">CURP:</label>
		 		 <div class="col-md-4">
				  <input id="inp_curp_modal" class="form-control" type="text" value= "'.$curp.'">
				  </div>
				  <label class="col-md-2">Matricula:</label>
		 		 <div class="col-md-4">
				  <input id="inp_matricula_modal" class="form-control" type="text" value= "'.$matricula.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">Grado:</label>
		 		 <div class="col-md-4">
				  <input id="inp_grado_modal" class="form-control" type="text" value= "'.$grado.'">
				  </div>
				  <label class="col-md-2">Secci&oacute;n:</label>
		 		 <div class="col-md-4">
				  <input id="inp_seccion_modal" class="form-control" type="text" value= "'.$seccion.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">Folio:</label>
		 		 <div class="col-md-4">
				  <input id="inp_folio_modal" class="form-control" type="text" value= "'.$folio.'">
				  </div>
				  <label class="col-md-2">Enfermedades:</label>
		 		 <div class="col-md-4">
				  <input id="inp_enfermedad_modal" class="form-control" type="text" value= "'.$enfermedad.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">Tel&eacute;fono:</label>
		 		 <div class="col-md-4">
				  <input id="inp_telefono_modal" class="form-control" type="text" value= "'.$telefono.'">
				  </div>
				  <label class="col-md-2">Email:</label>
		 		 <div class="col-md-4">
				  <input id="inp_email_modal" class="form-control" type="text" value= "'.$email.'">
				  </div>
				  <br><br><br>
				  <label class="col-md-2">Email del padre:</label>
		 		 <div class="col-md-4">
				  <input id="inp_emailp_modal" class="form-control" type="text" value= "'.$emailp.'">
				  </div>
				  <label class="col-md-2">Deporte:</label>
		 		 <div class="col-md-4">
				  <select class="form-control" id="inp_deporte_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                     if($deporte == 'F&uacute;tbol'){
                          $regreso.= '<option value="F&uacute;tbol" selected>F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      } elseif($deporte == 'Basquetbol'){
                         $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol" selected>Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>'; 
					 } elseif($deporte == 'Voleibol'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol" selected>Voleibol</option>
								   	<option value="Atletismo">Atletismo</option>'; 
					} elseif($deporte == 'Atletismo'){
					 	$regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
								  	<option value="Basquetbol">Basquetbol</option>
								  	<option value="Voleibol">Voleibol</option>
								   	<option value="Atletismo" selected>Atletismo</option>';				
												  
                      } else {
                          $regreso.= '<option value="F&uacute;tbol">F&uacute;tbol</option>
					                  <option value="Basquetbol">Basquetbol</option>
									  <option value="Voleibol">Voleibol</option>
									  <option value="Atletismo">Atletismo</option>';
                      }
               		$regreso.= '</select>
				  </div></div>
				  <br><br><br><br>
				  <label class="col-md-2">Equipo:</label>
		 		 <div class="col-md-4">
				  <select class="form-control" id="inp_equipo_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($equipo == 'Colegio ingles'){
                          $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles">Colegio ingles blanco</option>';
                      } elseif($equipo == 'Colegio ingles verde'){
					 	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde" selected>Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
					  } elseif($equipo == 'Colegio ingles blanco'){
					  	  $regreso.= '<option value="Colegio ingles" selected>Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles</option>
									  <option value="Colegio ingles blanco" selected>Colegio ingles blanco</option>';	
					} else {
                          $regreso.= '<option value="Colegio ingles">Colegio ingles</option>
					                  <option value="Colegio ingles verde">Colegio ingles verde</option>
									  <option value="Colegio ingles blanco">Colegio ingles blanco</option>';
                    }
					$regreso.= '</select>
      			</div>
				<label class="col-md-2">Rama:</label>
		 		 <div class="col-md-4">
				  <select class="form-control" id="inp_rama_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($rama == 'Varonil'){
                          $regreso.= '<option value="Varonil" selected>Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      } elseif($rama == 'Femenil'){
                         $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil" selected>Femenil</option>
									  <option value="Mixto">Mixto</option>'; 
					 } elseif($rama == 'Mixto'){
					 	$regreso.= '<option value="Varonil">Varonil</option>
								  <option value="Femenil">Femenil</option>
								  <option value="Mixto" selected>Mixto</option>'; 			  
                      } else {
                          $regreso.= '<option value="Varonil">Varonil</option>
					                  <option value="Femenil">Femenil</option>
									  <option value="Mixto">Mixto</option>';
                      }
               		$regreso.= '</select>
      			</div></div>
				<br><br><br>
				  <label class="col-md-2">Estatus:</label>
		 		 <div class="col-md-4">
				 	<select class="form-control" id="inp_estatus_modal" required>
					  <option selected disabled value = "">Selecciona:</option>';
                      if($estatus == 'Pre-inscrito'){
                          $regreso.= '<option value="Pre-inscrito" selected>Pre-inscrito</option>
					                  <option value="Inscrito">Inscrito</option>
									  <option value="No inscrito">No inscrito</option>
									  <option value="Aprueba">Aprueba</option>';
                      } elseif($estatus == 'Inscrito'){
                         $regreso.= '<option value="Pre-inscrito">Pre-inscrito</option>
					                  <option value="Inscrito" selected>Inscrito</option>
									  <option value="No inscrito">No inscrito</option>
									  <option value="Aprueba">Aprueba</option>'; 
					 } elseif($estatus == 'No inscrito'){
					 	$regreso.= '<option value="Pre-inscrito">Pre-inscrito</option>
								  <option value="Inscrito" selected>Inscrito</option>
								  <option value="Mixto">Mixto</option>
								  <option value="Aprueba">Aprueba</option>'; 
					} elseif($estatus == 'No inscrito'){
					 	$regreso.= '<option value="Pre-inscrito">Pre-inscrito</option>
								  <option value="Inscrito">Inscrito</option>
								  <option value="Mixto">Mixto</option>
								  <option value="Aprueba" selected>Aprueba</option>'; 			  
                      } else {
                          $regreso.= '<option value="Pre-inscrito">Pre-inscrito</option>
					                  <option value="Inscrito">Inscrito</option>
									  <option value="No inscrito">No inscrito</option>
									  <option value="Aprueba">Aprueba</option>';
                      }
               		$regreso.= '</select>
      			</div>';
    return $regreso;
}

function Tabla_buscar(){
    $busqueda = $_POST['busqueda'];
    $con=mysqli_connect("localhost","root","","Deportes");
    $query = mysqli_query($con, "select * from Deportes.basededatos where Nombre like '%$busqueda%' or App like '%$busqueda%' or Apm like '%$busqueda%' or Sexo like '%$busqueda%' or Fechan like '%$busqueda%' or CURP like '%$busqueda%' or Matricula like '%$busqueda%' or Grado like '%$busqueda%' or Seccion like '%$busqueda%' or Folio like '%$busqueda%' or Enfermedades like '%$busqueda%' or Telefono like '%$busqueda%' or Email like '%$busqueda%' or Emailpadre like '%$busqueda%' or Deporte like '%$busqueda%' or 
Equipo like '%$busqueda%' or Rama like '%$busqueda%' or Estatus like '%$busqueda%'");

        if (!$query)
        {
            $regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
        }
        else
        {
			$regreso = (isset($_POST['regreso']));
		
            $regreso.= '<table class="table table-striped table-bordered" id="tabla_BD">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-1"><p align="center">BD ID</p></th>
							<th class="col-md-2"><p align="center">Nombre</p></th>
							<th class="col-md-2"><p align="center">Foto</p></th>
							<th class="col-md-2"><p align="center">Apellido paterno</p></th>
							<th class="col-md-2"><p align="center">Apellido materno</p></th>
							<th class="col-md-2"><p align="center">Sexo</p></th>
							<th class="col-md-2"><p align="center">Fecha de nacimiento</p></th>
							<th class="col-md-2"><p align="center">CURP</p></th>
							<th class="col-md-2"><p align="center">Matricula</p></th>
							<th class="col-md-2"><p align="center">Grado</p></th>
							<th class="col-md-2"><p align="center">Secci&oacute;n</p></th>
							<th class="col-md-2"><p align="center">Folio</p></th>
							<th class="col-md-2"><p align="center">Enfermedades</p></th>
							<th class="col-md-2"><p align="center">Tel&eacute;fono</p></th>
							<th class="col-md-2"><p align="center">Email</p></th>
							<th class="col-md-2"><p align="center">Email del padre</p></th>
							<th class="col-md-2"><p align="center">Deporte</p></th>
							<th class="col-md-2"><p align="center">Equipo</p></th>
							<th class="col-md-2"><p align="center">Rama</p></th>
							<th class="col-md-2"><p align="center">Estatus</p></th>';
							
							if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<th class="col-md-2"><p align="center">Modificar</p></th>
								              <th class="col-md-2"><p align="center">Eliminar</p></th>';
                                }
	
						  $regreso.= '</tr>
					</thead>
				<tbody>'; 
                $consecutivo = 1;
                    while($fila = mysqli_fetch_array($query))
                    {
                      extract($fila);
                      $BD_id = $fila['BD_id'];
				  	  $nombre = $fila['Nombre'];
				      $foto = $fila['Foto'];
				      $app = $fila['App'];
				  	  $apm = $fila['Apm'];
				  	  $sexo = $fila['Sexo'];
				  	  $fechan = $fila['Fechan'];
				  	  $curp = $fila['CURP'];
				  	  $matricula = $fila['Matricula'];
				  	  $grado = $fila['Grado'];
				  	  $seccion = $fila['Seccion'];
				  	  $folio = $fila['Folio'];
				  	  $enfermedad = $fila['Enfermedades'];
				  	  $telefono = $fila['Telefono'];
				  	  $email = $fila['Email'];
				  	  $emailp = $fila['Emailpadre'];
				  	  $deporte = $fila['Deporte'];
				  	  $equipo = $fila['Equipo'];
				  	  $rama = $fila['Rama'];
				  	  $estatus = $fila['Estatus'];
				  	  $regreso.= '<tr>
								  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
								  <td style="vertical-align:middle;" align="left">'. $BD_id .'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$nombre.'</td>
								  <td style="vertical-align:middle;" align="center"><img src="img/fotos/'.$foto.'" alt="'.$foto.'" style="height: 80px; width:80px;">'.$foto.'</td>
								  <td style="vertical-align:middle;" align="center">'.$app.'</td>
								  <td style="vertical-align:middle;" align="left">'. $apm .'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$sexo.'</td>
								  <td style="vertical-align:middle;" align="center">'.$fechan.'</td>
								  <td style="vertical-align:middle;" align="center">'.$curp.'</td>
								  <td style="vertical-align:middle;" align="left">'. $matricula .'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$grado.'</td>
								  <td style="vertical-align:middle;" align="center">'.$seccion.'</td>
								  <td style="vertical-align:middle;" align="center">'.$folio.'</td>
								  <td style="vertical-align:middle;" align="left">'.$enfermedad.'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$telefono.'</td>
								  <td style="vertical-align:middle;" align="center">'.$email.'</td>
								  <td style="vertical-align:middle;" align="center">'.$emailp.'</td>
								  <td style="vertical-align:middle;" align="left">'. $deporte .'</td>                 
								  <td style="vertical-align:middle;" align="center">'.$equipo.'</td>
								  <td style="vertical-align:middle;" align="center">'.$rama.'</td>
								  <td style="vertical-align:middle;" align="center">'.$estatus.'</td>';
								  if($_SESSION['usua_rol'] != 'Asistente') {
								$regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$BD_id.'" class="btn_modificar btn btn-success" accion="editBD">Modificar		                          </button></td>
						  <td style="vertical-align:middle;" align="center"><button id="'.$BD_id.'" class="btn_eliminar btn btn-danger" accion="delBD">Eliminar                          </button></td>
						</tr>';
                                }
						$regreso.= '</tr>';
                       $consecutivo++;          
                    }
                $regreso.=  '</tbody></table><div style="text-align:center;font-weight:bold;">Resultados= '.--$consecutivo.'</div>';  
              }
    return $regreso;
}
?>
<?php
include("conecta.php");
session_start();

 if(!$_SESSION['iniciada'])
 {
  	header('Location: error.php');
 }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Men&uacute; principal</title>	
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function(){
	var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	  .Contenedor img {
	  width: 100%; position: relative;}
	  
	  a{
		 color:#003300;}
</style>
</head>
<body style="background-color:#86a286">
  <div class="Contenedor encabezado">
	<img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
  </div> <br>
<div class="container" style="font-size: 16px;">
    <div class="row" align="center">
       <div class="col-md-12" style="color:black; font-size:35px;"><b><span class="glyphicon glyphicon-home"></span> &nbsp;<label id="objetivo">Menú <?php echo $_SESSION['usua_rol']; ?></label></b></div>
    </div>
    <div class="row" align="right">
       <div class="col-md-12" style="color:#003300; font-size:18px;"><b><span class="glyphicon glyphicon-user"></span> &nbsp;<a href="Usuario.php" style="color:#003300; text-decoration:underline;" id="objetivo"><?php echo $_SESSION['usua_nombre']; ?>  </a></b> - 
       <strong><a href="index.php" style="color:#FFF; text-decoration:underline;"> Cerrar Sesi&oacute;n</a></strong>
           </div>
    </div>
    <div class="col-md-12" id="lista"> <!--style="display:none;">-->
	 		<strong><ul style="color:#FFFFFF" id="desplegar">
                <?php 
                    if ($_SESSION['usua_rol'] == 'Administrador'){
                       echo'<li><a href="Usuarios.php">Usuarios</a></li>
                            <li><a href="Temporada.php">Temporada</a></li>
                            <li><a href="Equipos.php">Equipos</a></li>
                            <li><a href="Basededatos.php">Base de datos</a></li>
                            <li><a href="Reportes.php">Reportes de Juego</a></li>
                            <li><a href="Planeacion.php">Planeaci&oacute;n</a></li>
                            <li><a href="Documentos.php">Documentos</a></li>
                            <li><a href="Asistencia.php">Asistencia</a></li>
                            <li><a href="Popup.php">Pop up</a></li>
                            ';
                    } elseif($_SESSION['usua_rol'] == 'Asistente'){
                        echo '<li><a href="Usuarios.php">Usuarios</a></li>
                            <li><a href="Temporada.php">Temporada</a></li>
                            <li><a href="Equipos.php">Equipos</a></li>
                            <li><a href="Basededatos.php">Base de datos</a></li>
                            <li><a href="Reportes.php">Reportes de Juego</a></li>
                            <li><a href="Planeacion.php">Planeaci&oacute;n</a></li>
                            <li><a href="Documentos.php">Documentos</a></li>
                            <li><a href="Asistencia.php">Asistencia</a></li>
                            <li><a href="Popup.php">Pop up</a></li>
                              ';
                    } elseif($_SESSION['usua_rol'] == 'Entrenador'){
                        echo '<li><a href="Temporada.php">Temporada</a></li>
                              <li><a href="Equipos.php">Equipos</a></li>
                              <li><a href="Reportes.php">Reportes de Juego</a></li>
                              <li><a href="Planeacion.php">Planeaci&oacute;n</a></li>
                              <li><a href="Documentos.php">Documentos</a></li>
                              <li><a href="Asistencia.php">Asistencia</a></li>
                              ';
                    } elseif($_SESSION['usua_rol'] == 'Visitante'){
                        echo '<li><a href="Temporada.php">Temporada</a></li>
                              <li><a href="Reportes.php">Reportes de Juego</a></li>
                            ';
                    }
                ?>
			
		</ul></strong>
		</div>
        <?php
          if($_SESSION['usua_rol'] == 'Administrador'){
            echo '<div class="row img-header" align="right">
                 <div class="col-md-12">
                     <strong><a href="encabezado.php" style="text-decoration:underline;">Cambiar Encabezado</a></strong>
                  </div>
              </div>
            ';
          }
        ?>
    
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->

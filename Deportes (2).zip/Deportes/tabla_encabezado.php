<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

if(isset($_POST['act'])) { $act = $_POST['act']; }
if(isset($_POST['foto'])) { $foto = $_POST['foto']; }

  switch($act){
	
	case 'insert-img':
          $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp');
            $path = 'img/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                //$query_count = mysqli_num_rows(mysqli_query($con, "select foto from Deportes.encabezado"));
                $query = mysqli_query($con, "select foto from Deportes.encabezado where foto_id=1");
                
                if ($query){
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        while($fila = mysqli_fetch_array($query)) {
                            extract($fila);
                            $imagen = $fila['foto'];
                            $filePath = 'img/'.$imagen;
                            if (file_exists($filePath) && $filePath != 'img/') {
                              unlink($filePath);
                            }
                        }
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                        mysqli_query($con, "update Deportes.encabezado set foto= '$img' where foto_id = 1");
                    } 
                    else 
                    {
                        echo 'invalido';
                    }  
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                        $path = $path.strtolower($img); 
                        move_uploaded_file($tmp,$path);
                        mysqli_query($con, "insert into Deportes.encabezado (foto) values('$foto')");
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
                
            }
    break;
    
    case 'set-imagen':
        //$query_count = mysqli_num_rows(mysqli_query($con, "select foto from Deportes.encabezado where foto_id=1"));
        $query = mysqli_query($con, "select foto from Deportes.encabezado where foto_id=1");
		//$query_count = mysqli_num_rows($query);
                
        if ($query){
            while($fila = mysqli_fetch_array($query)) {
                  extract($fila);
                  $img = $fila['foto'];
                  
                  $filePath = 'img/'.$img;
                  echo '
                  <div class="Contenedor encabezado">
	                <img src="'.$filePath.'" alt="'.$img.'">
                  </div>';
              }
        }
        else{
            echo'
              <div class="Contenedor encabezado">
                 <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg" alt="encabezado">
              </div>
            ';    
        }
    break;
}

?>
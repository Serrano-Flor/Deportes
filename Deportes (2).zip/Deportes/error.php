<?php
  include("conecta.php");
  session_start(); 
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Acceso</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar {
		width: 40px;
		height: 40px;
    }
		
    #tabla_acceso {
        font-size: 14;
        font-style: arial;
    }
	
    .Contenedor img {
	   width: 100%; 
       position: relative;
    }
    body{
       background-color:#86a286;   
       background-position:right; 
       background-repeat: no-repeat;
    }
    .error-msg {
       max-width: 450px;
       color: #DC262D; 
       background-color: #abbdab;
       text-align: center;
    }
</style>
<script type="text/javascript">
$(document).ready(function()
{
   var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
});
</script>
</head>
<body method="post"> 
	<div class="Contenedor encabezado">
		<img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
	</div>
	<br>	
		<h1 align="center">Acceso</h1>
	<br>
    <div class="container">
      <div class="well center-block error-msg">
              <h3><span class="glyphicon glyphicon-exclamation-sign"></span> ERROR AL INICIAR SESIÓN</h3>
              <p style="font-size: 16px;">La Contraseña o el Usuario no son validos</p>
              <a class="btn btn-lg btn-danger" href="index.php">Regresar</a>
            
      </div>    
    </div>
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
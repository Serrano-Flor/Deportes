<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Reportes de juego</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_reportes.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
	  var deporte_inp = $('#inp_deporte option:selected').val();
	  var equipo_inp = $('#inp_equipo option:selected').val();
	  var rama_inp = $('#inp_rama option:selected').val();

	  var campos_insert = {deporte: deporte_inp, equipo: equipo_inp, rama: rama_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_reportes.php',

		  success: function(response){
			swal({   
					type: "success",   
					title: "¡Se inserto correctamente!", 
			    });
			$('#div_pri').html(response);
			$('#inp_deporte').val(''); 
			$('#inp_equipo').val('');
			$('#inp_rama').val('');
		  },

		  error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {reportes_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_reportes.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
        var deporte_inp = $('#inp_deporte_modal option:selected').val();
	    var equipo_inp = $('#inp_equipo_modal option:selected').val();
	    var rama_inp = $('#inp_rama_modal option:selected').val();
        
        var campos_modificar = {reportes_id: id, deporte: deporte_inp, equipo: equipo_inp, rama: rama_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_reportes.php',

              success: function(response){
                $('#div_pri').html(response);
				swal({   
					type: "success",   
					title: "¡Se actualizo la información con éxito!", 
			    });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar el reporte con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {reportes_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_reportes.php',

              success: function(response){
				swal({   
					type: "success",   
					title: "¡Se elimino con éxito!", 
			    })
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
     
    $('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_reportes.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
	  $(function(){
        $("#imprimir").click(function(){
			$(".glyphicon").hide();
			$("#menu").hide();
			$("#reporte").hide();
            $("#lbl_deporte").hide();
			$("#inp_deporte").hide();
			$("#lbl_equipo").hide();
			$("#inp_equipo").hide();
			$("#lbl_rama").hide();
			$("#inp_rama").hide();
			$("#btn_nuevo").hide();
		    $("#lbl_buscar").hide();
			$("#inp_buscar").hide();
			window.print();
        });
    });
    
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_reportes{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	   
	   #inp_fecha {
   	    border-radius: 5px;
   		border: 1px solid #39c;
		width:263px; 
		height:35px;}	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-duplicate"></span>&nbsp; Reportes de juego</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" id="menu" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  <div align="left">
	  <strong><p style="text-decoration:underline"><a href="Reporte.php" id="reporte" style="color:#FFFFFF">Reporte semanal</a></p></strong>
  </div>
  <br>
	 <div align="right"> 
		<span class="glyphicon glyphicon-print" style="color:#FFFFFF"></span>
		<input type="button" value="Imprimir" id="imprimir" class="btn btn-link" style="color:#003300; font-size:18px" onClick="window.print();">	 
	 </div>	 
  <br>
  <div class="form-group row">
  <?php 
  if($_SESSION['usua_rol'] != 'Asistente' && $_SESSION['usua_rol'] != 'Visitante' ) {
	echo '<label id="lbl_deporte" class="col-md-2">Deporte:</label>
	  <div class="col-md-3">
		<select class="form-control" id="inp_deporte" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="F&uacute;tbol">F&uacute;tbol</option>
		 <option value="Basquetbol">Basquetbol</option>
          <option value="Voleibol">Voleibol</option>
          <option value="Atletismo">Atletismo</option>
		</select>
	  </div>
	  <label id="lbl_equipo" class="col-md-2">Equipo:</label>
	  <div class="col-md-3">
		<select class="form-control" id="inp_equipo" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Colegio ingles">Colegio ingles</option>
		  <option value="Colegio ingles verde">Colegio ingles verde</option>
		  <option value="Colegio ingles blanco">Colegio ingles blanco</option>
		</select>
	  </div>
   </div>
  <div class="form-group row">
	  <label id="lbl_rama" class="col-md-2">Rama:</label>
	  <div class="col-md-3">
		<select class="form-control" id="inp_rama" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Varonil">Varonil</option>
		  <option value="Femenil">Femenil</option>
          <option value="Mixto">Mixto</option>
		</select>
	  </div> 
  </div>
  <div align="center">
  	 <button class="btn btn-primary" id="btn_nuevo">Nueva asistencia</button>
  </div>'; } ?>
  <br>
  <div class="form-group row">
    <label id="lbl_buscar" class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar reporte</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar reporte</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>
<?php
session_start();   
include('conecta.php');

$con=mysqli_connect("localhost","root","","Deportes");

$act = $_POST['act'];
if(isset($_POST['documento'])){$documento = $_POST['documento'];}
if(isset($_POST['documentos_id'])){ $documentos_id = $_POST['documentos_id'];}//toma del ajax

   switch($act){
  
    case 'tab':
         echo Tabla();
    break;
	
    case 'insert':
            $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt', 'xls', 'xml', 'txt');
            $path = 'uploads/'; // upload directory
            
            if($_FILES['file'])
            {
                $img = $_FILES['file']['name'];
                $tmp = $_FILES['file']['tmp_name'];
                
                // get uploaded file's extension
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            
                $query = mysqli_num_rows(mysqli_query($con, "select * from Deportes.documentos where Documento like '$img'"));
                
                if ($query > 0){
                    echo 'repetido';
                }
                else{
                    // check's valid format
                    if(in_array($ext, $valid_extensions)) 
                    { 
                    $path = $path.strtolower($img); 

                        if(move_uploaded_file($tmp,$path)) 
                        {
                            mysqli_query($con, "insert into Deportes.documentos (Documento) values('$documento')");
                            echo Tabla();
                        }
                    } 
                    else 
                    {
                        echo 'invalido';
                    }    
                }
                
            }
    break;
          
    case 'buscar':
       echo Tabla_buscar();
    break;      
	
	case 'eliminar':
        $output_dir= 'uploads/';
        $fileName=str_replace("..",".",$documento); //required. if somebody is trying parent folder files	
        $filePath = $output_dir. $fileName;
        if (file_exists($filePath)) 
        {
            unlink($filePath);
        }
          
		mysqli_query($con, "delete from Deportes.documentos where Documento like '$documento'");
		echo Tabla();
    break;
          
}
function Tabla(){

$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.documentos");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso = '<table class="table table-striped table-bordered" id="tabla_documentos">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-2"><p align="center">Documento</p></th>
                            <th class="col-md-2"><p align="center">Visualizar</p></th>';
                            if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	                   $regreso.='
						  </tr>
					</thead>
			<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $documentos_id = $fila['documentos_id'];
				  $documento = $fila['Documento'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="center"><span class="glyphicon glyphicon-file"></span>  '.$documento.'</td>
                          <td style="vertical-align:middle;" align="center"><a class="btn btn-success" href="uploads/'.$documento.'" rel="nofollow">Visualizar</a></td>';
                      if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.= '<td style="vertical-align:middle;" align="center"><button id="'.$documento.'" class="btn_eliminar btn btn-danger" accion="deldocumentos">Eliminar                          </button></td>';
                      }
						$regreso.= '</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}

function Tabla_buscar(){
$busqueda = $_POST['busqueda'];
$con=mysqli_connect("localhost","root","","Deportes");
$query = mysqli_query($con, "select * from Deportes.documentos where Documento like '%$busqueda%'");
	  
	if (!$query)
	{
		$regreso = '<p align="center"><strong><font size=4>No se encontraron resultados</font></strong></p>';
	}
	else
	{
		$regreso.= '<table class="table table-striped table-bordered" id="tabla_documentos">
						<thead>
						  <tr>
							<th class="col-md-1"><p align="center">#</p></th>
							<th class="col-md-2"><p align="center">Documento</p></th>
                            <th class="col-md-2"><p align="center">Visualizar</p></th>';
                            if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='<th class="col-md-2"><p align="center">Eliminar</p></th>';
                            }
	
						  $regreso.='</tr>
					</thead>
			<tbody>'; 
			$consecutivo = 1;
				while($fila = mysqli_fetch_array($query))
				{
				  extract($fila);
					
				  $documentos_id = $fila['documentos_id'];
				  $documento = $fila['Documento'];
				  $regreso.= '<tr>
						  <td style="vertical-align:middle;" align="center"> '. $consecutivo .'</td>
						  <td style="vertical-align:middle;" align="center"><span class="glyphicon glyphicon-file"></span>  '.$documento.'</td>
                          <td style="vertical-align:middle;" align="center"><a class="btn btn-success" href="uploads/'.$documento.'" rel="nofollow">Visualizar</a></td>';
                          if($_SESSION['usua_rol'] != 'Asistente') {
                                  $regreso.='
						  <td style="vertical-align:middle;" align="center"><button id="'.$documento.'" class="btn_eliminar btn btn-danger" accion="deldocumentos">Eliminar</button></td>';
                          }
						$regreso.='</tr>'; 
                        $consecutivo++;          
                }
            $regreso.=  '</tbody></table>';  
          }
    return $regreso;
}
?>
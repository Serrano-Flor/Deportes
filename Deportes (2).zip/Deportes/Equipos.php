<?php
  include("conecta.php");
  session_start();
  
  if(!$_SESSION['iniciada'])
  {
  	header('Location: error.php');
  }
  if($_SESSION['usua_rol'] == 'Visitante') {
      header('Location: Menu.php');
  }
?>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!DOCTYPE html>
<head>
<!--links-->
<meta charset='UTF-8' />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/sweetalert2.css" rel="stylesheet">
<script src="js/sweetalert2.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="icon" type="image/png" href="glyphicons_free/glyphicons/png/glyphicons-330-soccer-ball.png" />
<title>Equipos</title>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<script type="text/javascript">
$(document).ready(function()
{

  var parametros = {act: 'tab'};

  $.ajax({
	  data : parametros,
	  type : 'POST',
	  url : 'tabla_equipos.php',

	  beforeSend: function(){
		$('#div_pri').html('<h4><b>Procesando, Espere por Favor...</b></h4>');
	  },
	  success: function(response){
		$('#div_pri').html(response);
	  },

	  error : function(XMLHttpRequest, textStatus, errorThrown) {
		$('#').show(500).text('Error al realizar la transferencia.');
	  }
  });
    
    var enc = {act: 'set-imagen'};

    $.ajax({
        data : enc,
        type : 'POST',
        url : 'tabla_encabezado.php',

        success: function(response){
          $('.encabezado').html(response);
        },

        error : function(XMLHttpRequest, textEestatus, errorThrown) {
          $('.encabezado').html('<div class="Contenedor encabezado"><img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg"></div>');
        }
    });
  
  $('#btn_nuevo').click(function(){
	  var deporte_inp = $('#inp_deporte option:selected').val();
	  var nombre_inp = $('#inp_nombre option:selected').val();
	  var rama_inp = $('#inp_rama option:selected').val();
	  var activo_inp = $('#inp_activo option:selected').val();

	  var campos_insert = {deporte: deporte_inp, nombre: nombre_inp, rama: rama_inp, activo: activo_inp, act: 'insert'};

	  $.ajax({
		  data : campos_insert,
		  type : 'POST',
		  url : 'tabla_equipos.php',

		  success: function(response){
			 swal({   
                  	type: "success",   
                  	title: "Se inserto correctamente!", 
                  });
			$('#div_pri').html(response);
			$('#inp_deporte').val('');
			$('#inp_nombre').val('');
			$('#inp_rama').val('');
			$('#inp_activo').val('');
		  },

		  error : function(XMLHttpRequest, textStatus, errorThrown) {
			$('#').show(500).text('Error al realizar la transferencia.');
		  }
  	  });
   }); 
   
    $(document).on('click','.btn_modificar', function(){
        var id = $(this).attr('id');
        var campos_modificar = {equipos_id: id, act: 'modificar_modal'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_equipos.php',

              success: function(response){
                $('#div_modal').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
        $('.btn-modificar-def').attr('id',id);
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn-modificar-def', function(){
        var id = $(this).attr('id');
        var deporte_inp = $('#inp_deporte_modal option:selected').val();
	    var nombre_inp = $('#inp_nombre_modal option:selected').val();
	    var rama_inp = $('#inp_rama_modal option:selected').val();
		var activo_inp = $('#inp_activo_modal option:selected').val();
        
        var campos_modificar = {equipos_id: id, deporte: deporte_inp, nombre: nombre_inp, rama: rama_inp, activo: activo_inp, act: 'modificar'};
        
        $.ajax({
              data : campos_modificar,
              type : 'POST',
              url : 'tabla_equipos.php',

              success: function(response){
                $('#div_pri').html(response);
				 swal({   
                  	type: "success",   
                  	title: "¡Se actualizo la información con éxito!", 
                  });
                $('#modal_editar').modal('hide');
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
       
        $('#modal_editar').modal('show');
    });
    
    $(document).on('click','.btn_eliminar', function(){
        var id = $(this).attr('id');
        
        $('.mod-eliminar').html('<p class="mod-eliminar" style="padding-left: 15px;">¿Seguro que desea eliminar el equipo con ID: '+id+' ?</p>');
        $('.btn-eliminar-def').attr('id',id);
        $('#modal_eliminar').modal('show');
    });
    
    $(document).on('click','.btn-eliminar-def', function(){
        var id = $(this).attr('id');
        var campos_eliminar = {equipos_id: id, act: 'eliminar'};
        
        $.ajax({
              data : campos_eliminar,
              type : 'POST',
              url : 'tabla_equipos.php',

              success: function(response){
				swal({   
                  	type: "success",   
                  	title: "¡Se elimino con éxito!", 
                  });
                $('#modal_eliminar').modal('hide');
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
	
	$('#inp_buscar').keyup(function(){
        var busqueda = $("#inp_buscar").val();
        var campos_busqueda = {busqueda: busqueda, act: 'buscar'};
        
        $.ajax({
              data : campos_busqueda,
              type : 'POST',
              url : 'tabla_equipos.php',

              success: function(response){
                $('#div_pri').html(response);
              },

              error : function(XMLHttpRequest, textStatus, errorThrown) {
                $('#').show(500).text('Error al realizar la transferencia.');
              }
  	     });
    });
    
	$(function(){
        $("#imprimir").click(function(){
			$(".glyphicon").hide();
			$("#menu").hide();
            $("#lbl_deporte").hide();
			$("#inp_deporte").hide();
			$("#lbl_nombre").hide();
			$("#inp_nombre").hide();
			$("#lbl_rama").hide();
			$("#inp_rama").hide();
			$("#lbl_activo").hide();
			$("#inp_activo").hide();
			$("#emailHelp").hide();
			$("#btn_nuevo").hide();
		    $("#lbl_buscar").hide();
			$("#inp_buscar").hide();
			window.print();
        });
    });
});   
</script>
<!-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<style>
	.btn-editar{
		width: 40px;
		height: 40px;}
		
	  body{
        color: #100719;}
		
	  #tabla_equipos{
	  font-size: 14;
	  font-style: arial;}
	
	  .Contenedor img {
	   width: 100%; position: relative;}
	  	
</style>
</head>
<body style="background-color:#86a286" action="" method="post">
<div class="Contenedor encabezado">
    <img src="img/c.-DR.-OSCAR-PLASCENCIA.jpeg">
</div>
<br>
<h1 align="center"><span class="glyphicon glyphicon-bullhorn"></span>&nbsp; Equipos</h1>	
<br>
<div class="container" style="font-size: 16px; color:#006600">
  <div align="right">
		<strong><p style="text-decoration:underline"><a href="Menu.php" id="menu" style="color:#FFFFFF">Men&uacute; Principal</a></p></strong>
  </div>
  	<div align="left">
		<span class="glyphicon glyphicon-print" style="color:#FFFFFF"></span>
		<input type="button" value="Imprimir" id="imprimir" class="btn btn-link" style="color:#003300; font-size:18px" onClick="window.print();">
	</div>
  <br>
  <div class="form-group row">
  <?php 
  	if($_SESSION['usua_rol'] != 'Asistente') {
		echo '<label id="lbl_deporte" class="col-md-1">Deporte:</label>
	  <div class="col-md-2">
	   <select class="form-control" id="inp_deporte" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="F&uacute;tbol">F&uacute;tbol</option>
		  <option value="Basquetbol">Basquetbol</option>
          <option value="Voleibol">Voleibol</option>
          <option value="Atletismo">Atletismo</option>
		</select>
      </div>
	   <label id="lbl_nombre" class="col-md-2">Nombre del equipo:</label>
	   <div class="col-md-2">
	  	 <select class="form-control" id="inp_nombre" required>
		  <option selected disabled value="">Selecciona:</option>
		  <option value="Biberones">Biberones</option>
		  <option value="Dientes de leche">Dientes de leche</option>
          <option value="Asqueles">Voleibol</option>
          <option value="Convivencia">Convivencia</option>
		  <option value="Juvenil A">Juvenil A</option>
		  <option value="Juvenil B">Juvenil B</option>
          <option value="Juvenil C">Juvenil C</option>
          <option value="Infantil Menor">Infantil Menor</option>
		  <option value="Infantil Mayor">Infantil Mayor</option>
		  <option value="Infantil Menor">Basquetbol</option>
          <option value="Infantil Mayor">Infantil Mayor</option>
		  <!-----Basquetbol--->
          <option value="BabyBasquet">BabyBasquet</option>
		  <option value="Promocional">Promocional</option>
		  <option value="Minibasquet">Minibasquet</option>
          <option value="Pasarela">Pasarela</option>
          <option value="Cadetes">Cadetes</option>
		  <option value="Elite">Elite</option>
		  <!-----Voleibol--->
		  <option value="Primaria">Atletismo</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		  <!-----Atletismo--->
           <option value="Primaria">Primaria</option>
		  <option value="Secundaria">Secundaria</option>
		  <option value="Preparatoria">Preparatoria</option>
		</select>
       </div>
	   <label id="lbl_rama" class="col-md-1">Rama:</label>
	  <div class="col-md-2">
		<select class="form-control" id="inp_rama" style="width:122px" required>
			  <option selected disabled value = "">Selecciona:</option>
			  <option value="Varonil">Varonil</option>
			  <option value="Femenil">Femenil</option>
			  <option value="Mixto">Mixto</option>
		</select>
      </div>
	</div>  
	<div class="form-group row">  
      <label id="lbl_activo" class="col-md-1">Activo:</label>
	  <div class="col-md-2">
              <select class="form-control" id="inp_activo" style="width:122px" required>
                  <option selected disabled value = "">Selecciona:</option>
                  <option value="Si">Si</option>
                  <option value="No">No</option>
               </select>
      </div>
   </div>  
  <div align="center">
      <button class="btn btn-primary" id="btn_nuevo">Nueva equipos</button>
  </div>'; } ?>
  <br>
  <div class="form-group row">
    <label id="lbl_buscar" class="col-md-2">Buscar:</label>
    <div class="col-md-6">
        <input type="text" id="inp_buscar" class="form-control" placeholder="Escriba para buscar...">
    </div>
  </div>
  <div id="div_pri">
  
  </div>
</div>	
</body>
</html>
<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!-------MODALES------------>
<!------Modal editar------>
<div class="modal fade" id="modal_editar" tabindex="-1" role="dialog" aria-labelledby="ModalEditar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEdiarTitle">Editar equipo</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
          <div id="div_modal"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success btn-modificar-def">Guardar</button>
      </div>
    </div>
  </div>
</div>
<!-------modal eliminar -------------->
<div class="modal fade" id="modal_eliminar" tabindex="-1" role="dialog" aria-labelledby="ModalEliminar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="ModalEliminarTitle">Eliminar equipo</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group row">
            <p class="mod-eliminar" style="padding-left: 15px;"></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary btn-eliminar-def">Eliminar</button>
      </div>
    </div>
  </div>
</div>